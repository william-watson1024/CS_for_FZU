package com.hang.service.impl;


import com.hang.entity.UserBilling;
import com.hang.mapper.UserBillingMapper;
import com.hang.service.UserBillingService;
import com.hang.utils.SqlSessionFactoryUtil;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.List;

public class UserBillingServiceImpl implements UserBillingService {
    private SqlSessionFactory sqlSessionFactory = SqlSessionFactoryUtil.getSqlSessionFactory();

    @Override
    public List<UserBilling> selectAll() {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserBillingMapper mapper = sqlSession.getMapper(UserBillingMapper.class);

        List<UserBilling> userBillings = mapper.selectAll();
        sqlSession.close();

        return userBillings;
    }

    @Override
    public UserBilling selectById(Integer id) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserBillingMapper mapper = sqlSession.getMapper(UserBillingMapper.class);

        UserBilling userBilling = mapper.selectById(id);
        sqlSession.close();
        return userBilling;
    }

    @Override
    public List<UserBilling> selectByUserId(String userId) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserBillingMapper mapper = sqlSession.getMapper(UserBillingMapper.class);

        List<UserBilling> userBillings = mapper.selectByUserId(userId);
        sqlSession.close();

        return userBillings;
    }

    @Override
    public void insert(UserBilling userBilling) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserBillingMapper mapper = sqlSession.getMapper(UserBillingMapper.class);

        mapper.insert(userBilling);
        sqlSession.commit();

        sqlSession.close();
    }

    @Override
    public void updateById(UserBilling userBilling) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserBillingMapper mapper = sqlSession.getMapper(UserBillingMapper.class);

        mapper.updateById(userBilling);
        sqlSession.commit();

        sqlSession.close();
    }

    @Override
    public void deleteById(Integer id) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserBillingMapper mapper = sqlSession.getMapper(UserBillingMapper.class);

        mapper.deleteById(id);
        sqlSession.commit();
        sqlSession.close();
    }
}
