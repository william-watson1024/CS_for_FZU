package com.hang.gui.shopframe.tabbedpanels;

import com.hang.entity.Product;
import com.hang.entity.SaleVolumn;
import com.hang.entity.Shop;
import com.hang.gui.shopframe.ShopFrame;
import com.hang.service.SaleVolumnService;
import com.hang.service.ShopBillingService;
import com.hang.service.impl.SaleVolumnServiceImpl;
import com.hang.service.impl.ShopBillingServiceImpl;
import com.hang.utils.TableUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import com.hang.service.ShopService;
import com.hang.service.impl.ShopServiceImpl;
import com.hang.service.ProductService;
import com.hang.service.impl.ProductServiceImpl;

public class SalesVolumeManagement extends JPanel {

    ShopBillingService shopBillingService = new ShopBillingServiceImpl();
    ProductService productService = new ProductServiceImpl();
    ShopService shopService = new ShopServiceImpl();
    SaleVolumnService saleVolumnService = new SaleVolumnServiceImpl();

    private List<SaleVolumn> saleVolumes;
    private JComboBox<String> yearComboBox;
    private JComboBox<String> monthComboBox;
    private JComboBox<String> dayComboBox;
    private LocalDate targetDateBegin;
    private LocalDate targetDateEnd;
    private JTable table = new JTable();
    private JLabel totalSalesLabel = new JLabel();
    private JButton detailButton = new JButton("查看详情");
    private JTextField productSearchField = new JTextField(15);
    private JButton searchProductButton = new JButton("搜索产品");
    private JCheckBox sortByVolumeCheckBox = new JCheckBox("按销售量排序");

    public SalesVolumeManagement(Shop shop, ShopFrame shopFrame) {
        setLayout(new BorderLayout());

        // 添加测试数据
        saleVolumes = saleVolumnService.selectByShopId(shop.getShopId());
//          根据店铺查找销售数据
        //

        JPanel selectPanel = new JPanel();
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        yearComboBox = new JComboBox<>();
        for (int i = currentYear; i >= currentYear - 100; i--) {
            yearComboBox.addItem(String.valueOf(i));
        }

        monthComboBox = new JComboBox<>();
        monthComboBox.addItem("-");
        for (int i = 1; i <= 12; i++) {
            monthComboBox.addItem(String.valueOf(i));
        }
        monthComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateDays();
            }
        });

        dayComboBox = new JComboBox<>();
        dayComboBox.addItem("-");
        for (int i = 1; i <= 31; i++) {
            dayComboBox.addItem(String.valueOf(i));
        }
        dayComboBox.setEnabled(false);

        selectPanel.add(new JLabel("年份："));
        selectPanel.add(yearComboBox);
        selectPanel.add(new JLabel("月份："));
        selectPanel.add(monthComboBox);
        selectPanel.add(new JLabel("日期："));
        selectPanel.add(dayComboBox);

        JButton searchButton = new JButton("搜索");
        selectPanel.add(searchButton);
        selectPanel.add(new JLabel("产品名称："));
        selectPanel.add(productSearchField);
        selectPanel.add(searchProductButton);
        selectPanel.add(sortByVolumeCheckBox);
        selectPanel.add(detailButton);
        totalSalesLabel.setText("总销售量：0");
        selectPanel.add(totalSalesLabel);

        add(selectPanel, BorderLayout.NORTH);

        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                filterAndDisplaySales();
            }
        });

        searchProductButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                filterAndDisplaySales();
            }
        });

        sortByVolumeCheckBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                filterAndDisplaySales();
            }
        });

        detailButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showSaleVolumeDetail();
            }
        });

        LocalDate now = LocalDate.now();
        showSaleVolumeTable(String.valueOf(now.getYear()), String.valueOf(now.getMonthValue()), String.valueOf(now.getDayOfMonth()));
    }

    private void filterAndDisplaySales() {
        String selectedYear = (String) yearComboBox.getSelectedItem();
        String selectedMonth = (String) monthComboBox.getSelectedItem();
        String selectedDay = (String) dayComboBox.getSelectedItem();
        String productName = productSearchField.getText();

        LocalDate startDate;
        LocalDate endDate;

        if (!selectedMonth.equals("-") && selectedDay.equals("-")) {
            startDate = LocalDate.of(Integer.parseInt(selectedYear), Integer.parseInt(selectedMonth), 1);
            endDate = startDate.plusMonths(1);
        } else if (selectedMonth.equals("-")) {
            startDate = LocalDate.of(Integer.parseInt(selectedYear), 1, 1);
            endDate = startDate.plusYears(1);
        } else {
            startDate = LocalDate.of(Integer.parseInt(selectedYear), Integer.parseInt(selectedMonth), Integer.parseInt(selectedDay));
            endDate = startDate.plusDays(1);
        }

        List<SaleVolumn> filteredSaleVolumes = saleVolumes.stream()
                .filter(saleVolumn -> !saleVolumn.getSaleDate().isBefore(startDate) && saleVolumn.getSaleDate().isBefore(endDate))
                .filter(saleVolumn -> {
                    Product product = productService.selectById(saleVolumn.getProductId());
                    return product.getName().contains(productName);
                })
                .collect(Collectors.toList());

        if (sortByVolumeCheckBox.isSelected()) {
            filteredSaleVolumes.sort(Comparator.comparingInt(SaleVolumn::getCount).reversed());
        }

        displaySaleVolumes(filteredSaleVolumes);
    }

    private void showSaleVolumeTable(String selectedYear, String selectedMonth, String selectedDay) {
        filterAndDisplaySales();
    }

    private void displaySaleVolumes(List<SaleVolumn> saleVolumesToDisplay) {
        int totalSales = 0;
        String[][] data = new String[saleVolumesToDisplay.size()][4];
        String[] columnNames = {"产品", "品牌", "销售日期", "销售数量"};
        TableUtils.setTableStyle(table);

        for (int i = 0; i < saleVolumesToDisplay.size(); i++) {
            SaleVolumn saleVolumn = saleVolumesToDisplay.get(i);
            Product product = productService.selectById(saleVolumn.getProductId());

            data[i][0] = product.getName();
            data[i][1] = product.getBrand();
            data[i][2] = String.valueOf(saleVolumn.getSaleDate());
            data[i][3] = String.valueOf(saleVolumn.getCount());
            totalSales += saleVolumn.getCount();
        }

        totalSalesLabel.setText("总销售量：" + totalSales);

        DefaultTableModel model = new DefaultTableModel(data, columnNames) {
            @Override
            public Class<?> getColumnClass(int column) {
                return String.class;
            }
        };

        table.setModel(model);

        TableColumnModel columnModel = table.getColumnModel();
        TableColumn firstColumn = columnModel.getColumn(0);
        firstColumn.setPreferredWidth(100);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        table.setVisible(true);
    }

    private void showSaleVolumeDetail() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "未选择任何销售记录！");
        } else {
            SaleVolumn saleVolumn = saleVolumes.get(selectedRow);
            JDialog detailDialog = new JDialog((Frame) null, "销售详情", true);
            detailDialog.setSize(500, 400);
            JPanel detailPanel = new JPanel();
            detailDialog.add(detailPanel);
            detailPanel.setLayout(new GridLayout(5, 2));

            JLabel saleDateLabel = new JLabel("销售日期：");
            JLabel saleDateValueLabel = new JLabel(String.valueOf(saleVolumn.getSaleDate()));
            JLabel countLabel = new JLabel("销售数量：");
            JLabel countValueLabel = new JLabel(String.valueOf(saleVolumn.getCount()));
            JLabel productIdLabel = new JLabel("产品ID：");
            JLabel productIdValueLabel = new JLabel(String.valueOf(saleVolumn.getProductId()));
            JLabel saleVolumnIdLabel = new JLabel("销售ID：");
            JLabel saleVolumnIdValueLabel = new JLabel(String.valueOf(saleVolumn.getSaleVolumnId()));

            detailPanel.add(saleDateLabel);
            detailPanel.add(saleDateValueLabel);
            detailPanel.add(countLabel);
            detailPanel.add(countValueLabel);
            detailPanel.add(productIdLabel);
            detailPanel.add(productIdValueLabel);
            detailPanel.add(saleVolumnIdLabel);
            detailPanel.add(saleVolumnIdValueLabel);

            detailDialog.setVisible(true);
        }
    }

    private void updateDays() {
        String selectedMonth = (String) monthComboBox.getSelectedItem();
        if (selectedMonth != null && selectedMonth.equals("-")) {
            dayComboBox.setSelectedItem("-");
            dayComboBox.setEnabled(false);
        } else {
            dayComboBox.setEnabled(true);
            int month = Integer.parseInt(selectedMonth);
            int daysInMonth = getDaysInMonth(month);
            dayComboBox.removeAllItems();
            dayComboBox.addItem("-");
            for (int i = 1; i <= daysInMonth; i++) {
                dayComboBox.addItem(String.valueOf(i));
            }
        }
    }

    private int getDaysInMonth(int month) {
        int year = Integer.parseInt((String) yearComboBox.getSelectedItem());
        switch (month) {
            case 2:
                if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) {
                    return 29;
                } else {
                    return 28;
                }
            case 4:
            case 6:
            case 9:
            case 11:
                return 30;
            default:
                return 31;
        }
    }

    private List<SaleVolumn> generateTestData() {
        List<SaleVolumn> testData = new ArrayList<>();
        SaleVolumn sale1 = new SaleVolumn();
        sale1.setSaleDate(LocalDate.of(2024, 6, 1));
        sale1.setCount(10);
        sale1.setProductId(1);
        sale1.setSaleVolumnId(1);
        testData.add(sale1);

        SaleVolumn sale2 = new SaleVolumn();
        sale2.setSaleDate(LocalDate.of(2024, 6, 2));
        sale2.setCount(20);
        sale2.setProductId(2);
        sale2.setSaleVolumnId(2);
        testData.add(sale2);

        SaleVolumn sale3 = new SaleVolumn();
        sale3.setSaleDate(LocalDate.of(2024, 6, 3));
        sale3.setCount(30);
        sale3.setProductId(3);
        sale3.setSaleVolumnId(3);
        testData.add(sale3);

        return testData;
    }
}
