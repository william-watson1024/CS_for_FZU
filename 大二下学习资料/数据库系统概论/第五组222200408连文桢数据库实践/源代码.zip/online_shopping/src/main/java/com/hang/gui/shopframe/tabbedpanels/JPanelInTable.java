package com.hang.gui.shopframe.tabbedpanels;

import com.hang.entity.Comment;
import com.hang.entity.Product;
import com.hang.service.CommentService;
import com.hang.service.ProductService;
import com.hang.service.UserService;
import com.hang.service.impl.CommentServiceImpl;
import com.hang.service.impl.ProductServiceImpl;
import com.hang.service.impl.UserServiceImpl;


import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class JPanelInTable {

    private static ProductService productService = new ProductServiceImpl();
    private static UserService userService = new UserServiceImpl();

    private static CommentService commentService = new CommentServiceImpl();
    public  static void createComment(Product product){
        SwingUtilities.invokeLater(() -> {
            List<Comment> comments = commentService.selectByProductId(product.getProductId());
            JFrame frame = new JFrame("评论");
            DefaultTableModel model = new DefaultTableModel() {
                @Override
                public Class<?> getColumnClass(int columnIndex) {
                    return columnIndex == 0 ? JPanel.class : String.class;
                }
            };

            model.addColumn("评论详情");
            for(Comment comment : comments){
                model.addRow(new Object[]{ createCommentPanel(
                        (userService.selectById(comment.getUserId())).getNickname(),
                        //"用户",
                        "橘子",
                        //productService.selectById(comment.getProductId()).getProductName(),
                        comment.getContent(),
                        String.valueOf(comment.getPostTime()),
                        comment.getLikes()
                )});
            }

            JTable table = new JTable(model);
            table.setRowHeight(300);
            table.getColumnModel().getColumn(0).setCellRenderer(new PanelRenderer());

            frame.add(new JScrollPane(table));
            frame.pack();
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }

    private static JPanel createCommentPanel(String userId, String productId, String commentText, String commentTime, int likeCount) {
        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        // Create components for each data
        JLabel userIdLabel = new JLabel("用户ID: " + userId);
        JLabel productIdLabel = new JLabel("产品ID: " + productId);
        JTextArea commentTextArea = new JTextArea(commentText);
        JLabel commentTimeLabel = new JLabel("评论时间: " + commentTime);
        JLabel likeCountLabel = new JLabel("点赞数: " + likeCount);

        // Configure JTextArea
        commentTextArea.setWrapStyleWord(true);
        commentTextArea.setLineWrap(true);
        commentTextArea.setEditable(false);
        commentTextArea.setOpaque(false);

        // 用户ID - Left Top
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        gbc.insets = new Insets(5, 5, 5, 5);
        panel.add(userIdLabel, gbc);

        // 评论时间 - Right Top
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.NORTHEAST;
        panel.add(commentTimeLabel, gbc);

        // 评论内容 - Center
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        panel.add(new JScrollPane(commentTextArea), gbc);

        // 产品ID - Left Bottom
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        gbc.weightx = 0;
        gbc.weighty = 0;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.SOUTHWEST;
        panel.add(productIdLabel, gbc);

        // 点赞数 - Right Bottom
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.SOUTHEAST;
        panel.add(likeCountLabel, gbc);

        return panel;
    }

    // Custom renderer for JPanel in JTable cell
    static class PanelRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            if (value instanceof JPanel) {
                return (JPanel) value;
            } else {
                return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            }
        }
    }
}
