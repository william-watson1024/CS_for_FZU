package com.hang.gui.shopframe.tabbedpanels;

import com.hang.entity.AfterSale;
import com.hang.gui.shopframe.ShopFrame;
import com.hang.service.AfterSaleService;
import com.hang.service.impl.AfterSaleServiceImpl;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;

public class AfterSaleDialog extends JDialog {
    private AfterSaleService afterSaleService = new AfterSaleServiceImpl();
    private JTextField afterSaleIdField;
    private JTextField orderIdField;
    private JTextField requestTypeField;
    private JTextField reasonField;
    private JComboBox<String> statusComboBox;
    private JTextArea replyArea;
    private JTextField requestTimeField;
    private JTextField solvedTimeField;

    private String[] statuses = {"待处理", "同意", "拒绝"};

    public AfterSaleDialog(ShopFrame shopFrame, AfterSale afterSale) {
        super(shopFrame, "售后处理", true);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        afterSaleIdField = new JTextField(20);
        afterSaleIdField.setEditable(false);
        orderIdField = new JTextField(20);
        orderIdField.setEditable(false);
        requestTypeField = new JTextField(20);
        requestTypeField.setEditable(false);
        reasonField = new JTextField(20);
        reasonField.setEditable(false);
        statusComboBox = new JComboBox<>(statuses);
        replyArea = new JTextArea(3, 20);
        requestTimeField = new JTextField(20);
        requestTimeField.setEditable(false);
        solvedTimeField = new JTextField(20);
        solvedTimeField.setEditable(false);

        setAfterSaleInfo(afterSale.getAfterSaleId(),
                afterSale.getOrderId(),
                afterSale.getRequestType(),
                afterSale.getReason(),
                afterSale.getStatus(),
                afterSale.getReply(),
                afterSale.getRequestTime(),
                afterSale.getSolvedTime());

        gbc.gridx = 0;
        gbc.gridy = 0;
        add(new JLabel("售后ID:"), gbc);
        gbc.gridx = 1;
        add(afterSaleIdField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        add(new JLabel("订单号:"), gbc);
        gbc.gridx = 1;
        add(orderIdField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        add(new JLabel("请求类型:"), gbc);
        gbc.gridx = 1;
        add(requestTypeField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        add(new JLabel("原因:"), gbc);
        gbc.gridx = 1;
        add(reasonField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        add(new JLabel("处理状态:"), gbc);
        gbc.gridx = 1;
        add(statusComboBox, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        add(new JLabel("回复信息:"), gbc);
        gbc.gridx = 1;
        gbc.gridwidth = 2;
        add(new JScrollPane(replyArea), gbc);
        gbc.gridwidth = 1;

        gbc.gridx = 0;
        gbc.gridy = 6;
        add(new JLabel("请求时间:"), gbc);
        gbc.gridx = 1;
        add(requestTimeField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 7;
        add(new JLabel("完成时间:"), gbc);
        gbc.gridx = 1;
        add(solvedTimeField, gbc);

        JButton confirmButton = new JButton("确认");
        JButton cancelButton = new JButton("取消");

        if (afterSale.getStatus().equals("待处理")) {
            gbc.gridx = 0;
            gbc.gridy = 8;
            add(confirmButton, gbc);
            confirmButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (statusComboBox.getSelectedItem().equals("同意")) {
                        afterSale.setStatus("已同意");
                        afterSale.setSolvedTime(LocalDateTime.now());
                        afterSaleService.updateById(afterSale);

                    } else if (statusComboBox.getSelectedItem().equals("拒绝")) {
                        afterSale.setStatus("已拒绝");
                        afterSale.setSolvedTime(LocalDateTime.now());
                        afterSaleService.updateById(afterSale);
                    }
                    dispose();
                }
            });
        } else {
            statusComboBox.addItem(afterSale.getStatus());
            statusComboBox.setSelectedItem(afterSale.getStatus());
            statusComboBox.setEnabled(false);
            replyArea.setEnabled(false);
            gbc.gridx = 0;
            gbc.gridy = 8;
            add(cancelButton, gbc);
            confirmButton.setVisible(false);
            cancelButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    dispose();
                }
            });

        }



        Dimension buttonSize = confirmButton.getPreferredSize();
        cancelButton.setPreferredSize(buttonSize);

        pack();
        setLocationRelativeTo(shopFrame);
    }

    public void setAfterSaleInfo(Integer afterSaleId, Integer orderId, String requestType, String reason, String status, String reply, LocalDateTime requestTime, LocalDateTime solvedTime) {
        afterSaleIdField.setText(afterSaleId.toString());
        orderIdField.setText(orderId.toString());
        requestTypeField.setText(requestType);
        reasonField.setText(reason);
        statusComboBox.setSelectedItem(status);
        replyArea.setText(reply);
        requestTimeField.setText(requestTime.toString());
        if (solvedTime != null) {
            solvedTimeField.setText(solvedTime.toString());
        }
    }

    public String getStatus() {
        return (String) statusComboBox.getSelectedItem();
    }

    public String getReply() {
        return replyArea.getText();
    }

    public LocalDateTime getSolvedTime() {
        return LocalDateTime.parse(solvedTimeField.getText());
    }
}
