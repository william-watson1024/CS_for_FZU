package com.hang.gui.adminframe.tabbedpanels.frames;

import com.hang.entity.Admin;
import com.hang.service.AdminService;
import com.hang.service.impl.AdminServiceImpl;
import com.hang.utils.PasswordUtil;

import javax.swing.*;
import java.awt.*;

public class AddAdminFrame extends JFrame{
    private AdminService adminService = new AdminServiceImpl();

    JPanel contentPanel = new JPanel(new GridBagLayout());

    JLabel adminIdLabel = new JLabel("账号: ");
    JTextField adminIdField = new JTextField(12);

    JLabel passwordLabel = new JLabel("密码: ");
    JPasswordField passwordField = new JPasswordField(12);

    JLabel checkPasswordLabel = new JLabel("确认密码: ");
    JPasswordField checkPasswordField = new JPasswordField(12);

    JLabel nameLabel = new JLabel("姓名: ");
    JTextField nameField = new JTextField(12);

    JLabel phoneLabel = new JLabel("手机号: ");
    JTextField phoneField = new JTextField(12);

    JLabel emailLabel = new JLabel("邮箱: ");
    JTextField emailField = new JTextField(12);

    JPanel checkButtonPanel = new JPanel();
    JButton checkButton = new JButton("确定");

    public AddAdminFrame(){
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5, 5, 5, 5);

        // 第1行：账号
        c.gridy = 0;

        c.gridx = 0;
        contentPanel.add(adminIdLabel,c);

        c.gridx = 1;
        contentPanel.add(adminIdField,c);


        // 第2行：密码
        c.gridy = 1;

        c.gridx = 0;
        contentPanel.add(passwordLabel,c);

        c.gridx = 1;
        contentPanel.add(passwordField,c);


        // 第3行：确认密码
        c.gridy = 2;

        c.gridx = 0;
        contentPanel.add(checkPasswordLabel,c);

        c.gridx = 1;
        contentPanel.add(checkPasswordField,c);


        // 第4行：姓名
        c.gridy = 3;

        c.gridx = 0;
        contentPanel.add(nameLabel,c);

        c.gridx = 1;
        contentPanel.add(nameField,c);

        // 第5行：手机号
        c.gridy = 4;

        c.gridx = 0;
        contentPanel.add(phoneLabel,c);

        c.gridx = 1;
        contentPanel.add(phoneField,c);

        // 第6行：邮箱
        c.gridy = 5;

        c.gridx = 0;
        contentPanel.add(emailLabel,c);

        c.gridx = 1;
        contentPanel.add(emailField,c);


        // 第7行：确认按钮panel
        c.gridy = 6;
        checkButtonPanel.add(checkButton);

        c.gridx = 0;
        c.gridwidth = 2;
        contentPanel.add(checkButtonPanel,c);

        checkButton.addActionListener(e->{
            Admin admin = null;
            try {
                admin = adminService.selectById(adminIdField.getText());
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this,"请检查配置文件中密码是否正确\n或者数据库是否能正常连接","数据库连接异常",JOptionPane.ERROR_MESSAGE);
            }

            if(adminIdField.getText().isEmpty()){
                JOptionPane.showMessageDialog(this,"账号不能为空");
            }else if(admin!=null){
                JOptionPane.showMessageDialog(this,"账号已存在");
            }else if(passwordField.getText().length()<6){
                JOptionPane.showMessageDialog(this,"密码不少于6位");
            }else if(!passwordField.getText().equals(checkPasswordField.getText())){
                JOptionPane.showMessageDialog(this,"两次输入密码不一致");
            }else{
                Admin newAdmin = new Admin();
                String hashPassword = PasswordUtil.hashPassword(passwordField.getText());

                newAdmin.setAdminId(adminIdField.getText());
                newAdmin.setPassword(hashPassword);
                newAdmin.setName(nameField.getText());
                newAdmin.setPhoneNumber(phoneField.getText());
                newAdmin.setEmail(emailField.getText());
                adminService.insert(newAdmin);

                JOptionPane.showMessageDialog(this,"新增管理员成功");
                dispose();
            }
        });

        // 设置窗口参数
        setTitle("新增管理员");
        add(contentPanel);
        setVisible(true);
        pack();
        setLocationRelativeTo(null);
    }
}
