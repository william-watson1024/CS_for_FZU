package com.hang.mapper;



import com.hang.entity.User;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface UserMapper{
    @Select("select * from user")
    List<User> selectAll();

    @Select("select * from user where #{id}=user_id")
    User selectById(String id);

    @Insert("insert into user(user_id, password, nickname, phone_number,register_date) VALUES (#{userId},#{password},#{nickname},#{phoneNumber},#{registerDate})")
    int insert(User user);

    @Update("update user set password = #{password}, nickname=#{nickname}, phone_number=#{phoneNumber}, balance=#{balance}, credit_level=#{creditLevel},status=#{status},register_date=#{registerDate} ,avatar=#{avatar}, email=#{email}, gender=#{gender}, birthday=#{birthday} where user_id = #{userId}")
    void updateById(User user);

    @Delete("delete from user where user_id = #{id}")
    void deleteById(String id);
}
