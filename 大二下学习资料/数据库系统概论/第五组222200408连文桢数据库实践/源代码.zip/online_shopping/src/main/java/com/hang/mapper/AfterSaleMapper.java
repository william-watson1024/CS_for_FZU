package com.hang.mapper;

import com.hang.entity.AfterSale;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface AfterSaleMapper {
    @Select("select * from after_sale")
    List<AfterSale> selectAll();

    @Select("select * from after_sale where after_sale_id=#{id}")
    AfterSale selectById(Integer id);

    @Select("select a.* from after_sale a " +
            "join `order` o on a.order_id = o.order_id " +
            "join product p on o.product_id = p.product_id " +
            "where p.shop_id = #{shopId};")
    List<AfterSale> selectByShopId(Integer shopId);

    @Insert("insert into after_sale(after_sale_id, order_id, request_type, reason, status, reply, request_time, solved_time) VALUES(null,#{orderId},#{requestType},#{reason},#{status} ,#{reply},#{requestTime},#{solvedTime})")
    void insert(AfterSale afterSale);


    @Update("update after_sale set request_type=#{requestType},reason=#{reason},status=#{status},reply=#{reply},request_time=#{requestTime},solved_time=#{solvedTime}   where after_sale_id=#{afterSaleId}")
    void updateById(AfterSale afterSale);

    @Delete("delete from after_sale where after_sale_id=#{id}")
    void deleteById(Integer id);
}
