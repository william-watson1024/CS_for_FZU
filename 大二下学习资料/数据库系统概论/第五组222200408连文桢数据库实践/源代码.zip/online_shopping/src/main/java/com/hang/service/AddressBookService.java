package com.hang.service;


import com.hang.entity.AddressBook;

import java.util.List;

public interface AddressBookService {
    List<AddressBook> selectByUserId(String userId);
    AddressBook selectDefaultByUserId(String userId);
    void setDefaultAddressBook(Integer addressId);

    List<AddressBook> selectAll();
    AddressBook selectById(Integer id);
    void insert(AddressBook addressBook);
    void updateById(AddressBook addressBook);
    void deleteById(Integer id);
}
