package com.hang.gui.adminframe.tabbedpanels;

import com.hang.entity.Seller;
import com.hang.service.SellerService;
import com.hang.service.impl.SellerServiceImpl;
import com.hang.utils.TableUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class SellerManage extends JPanel {
    private final SellerService sellerService = new SellerServiceImpl();
    private final JTable table = new JTable();
    private List<Seller> sellerList;

    JTextField searchField = new JTextField(10);
    JButton searchButton = new JButton("搜索");
    // 状态下拉框
    String[] statusOptions = {"全部", "正常", "禁用"};
    JComboBox<String> statusComboBox= new JComboBox<>(statusOptions);

    // 信用等级状态下拉框
    String[] orderedOptions = {"升序", "降序"};
    JComboBox<String> orderedComboBox = new JComboBox<>(orderedOptions);

    public SellerManage() {
        setLayout(new BorderLayout());

        // 创建滚动面板并将表格添加到其中
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        setNorthPanel();
        updateTable();

        setEastPanel();
    }

    private void setEastPanel() {
        JPanel eastPanel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(20, 10, 20, 10);

        JButton normalButton = new JButton("恢复正常");
        JButton banButton = new JButton("禁用");
        JButton addCreditLevelButton = new JButton("信用等级+1");
        JButton subCreditLeverButton = new JButton("信用等级-1");

        c.gridy = 0;
        eastPanel.add(normalButton, c);

        c.gridy = 1;
        eastPanel.add(banButton, c);

        c.gridy = 2;
        eastPanel.add(addCreditLevelButton, c);

        c.gridy = 3;
        eastPanel.add(subCreditLeverButton, c);

        banButton.setPreferredSize(addCreditLevelButton.getPreferredSize());
        normalButton.setPreferredSize(addCreditLevelButton.getPreferredSize());

        normalButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();

            if (selectedRow == -1) {
                return;
            }

            Seller seller = sellerList.get(selectedRow);
            seller.setStatus("正常");
            sellerService.updateById(seller);
            updateTable();

            for (int i = 0; i < sellerList.size(); i++) {
                if (sellerList.get(i).getSellerId().equals(seller.getSellerId())) {
                    table.setRowSelectionInterval(i, i);
                }
            }
        });

        banButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();

            if (selectedRow == -1) {
                return;
            }

            Seller seller = sellerList.get(selectedRow);
            seller.setStatus("禁用");
            sellerService.updateById(seller);
            updateTable();

            for (int i = 0; i < sellerList.size(); i++) {
                if (sellerList.get(i).getSellerId().equals(seller.getSellerId())) {
                    table.setRowSelectionInterval(i, i);
                }
            }
        });

        addCreditLevelButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow == -1) {
                return;
            }

            Seller seller = sellerList.get(selectedRow);

            if (seller.getCreditLevel() >= 5) {
                JOptionPane.showMessageDialog(this, "信用等级在1-5之间");
            } else {
                seller.setCreditLevel(seller.getCreditLevel() + 1);
                sellerService.updateById(seller);
                updateTable();

                for (int i = 0; i < sellerList.size(); i++) {
                    if (sellerList.get(i).getSellerId().equals(seller.getSellerId())) {
                        table.setRowSelectionInterval(i, i);
                    }
                }
            }
        });

        subCreditLeverButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow == -1) {
                return;
            }

            Seller seller = sellerList.get(selectedRow);

            if (seller.getCreditLevel() <= 1) {
                JOptionPane.showMessageDialog(this, "信用等级在1-5之间");
            } else {
                seller.setCreditLevel(seller.getCreditLevel() - 1);
                sellerService.updateById(seller);
                updateTable();

                for (int i = 0; i < sellerList.size(); i++) {
                    if (sellerList.get(i).getSellerId().equals(seller.getSellerId())) {
                        table.setRowSelectionInterval(i, i);
                    }
                }
            }
        });


        add(eastPanel, BorderLayout.EAST);
    }

    private void setNorthPanel() {
        JPanel northPanel = new JPanel();

        northPanel.add(new JLabel("  状态:"));
        northPanel.add(statusComboBox);
        northPanel.add(new JLabel("  信用等级排序:"));
        northPanel.add(orderedComboBox);
        northPanel.add(new JLabel("  账号|姓名: "));
        northPanel.add(searchField);
        northPanel.add(searchButton);

        add(northPanel, BorderLayout.NORTH);

        statusComboBox.addActionListener(e -> updateTable());
        orderedComboBox.addActionListener(e -> updateTable());
        searchButton.addActionListener(e-> updateTable());
    }

    private void updateTable() {
        sellerList = sellerService.selectByConditions(searchField.getText(),
                (String)statusComboBox.getSelectedItem(),
                (String)orderedComboBox.getSelectedItem());

        // 创建表格模型
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("账号");
        model.addColumn("姓名");
        model.addColumn("状态");
        model.addColumn("信用等级");

        // 添加数据到表格模型
        for (Seller seller : sellerList) {
            model.addRow(new Object[]{seller.getSellerId(), seller.getName(), seller.getStatus(), seller.getCreditLevel()});
        }

        table.setModel(model);
        // 使用工具类，设置表格样式
        TableUtils.setTableStyle(table);
    }
}
