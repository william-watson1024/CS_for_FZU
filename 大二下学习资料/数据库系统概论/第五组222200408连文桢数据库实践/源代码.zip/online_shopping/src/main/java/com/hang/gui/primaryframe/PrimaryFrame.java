package com.hang.gui.primaryframe;

import com.hang.config.Config;
import com.hang.gui.primaryframe.tabbedpanels.UserLoginAndRegister;
import com.hang.gui.primaryframe.tabbedpanels.AdminLogin;
import com.hang.gui.primaryframe.tabbedpanels.SellerLoginAndRegister;

import javax.swing.*;
import java.awt.*;

public class PrimaryFrame extends JFrame {

    private void setUIFont(javax.swing.plaf.FontUIResource f) {
        java.util.Enumeration<Object> keys = UIManager.getDefaults().keys();
        while (keys.hasMoreElements()) {
            Object key = keys.nextElement();
            Object value = UIManager.get(key);
            if (value instanceof javax.swing.plaf.FontUIResource) {
                UIManager.put(key, f);
            }
        }
    }

    public PrimaryFrame(){
        setTitle("电商购物系统");

        // 设置全局字体
        setUIFont(new javax.swing.plaf.FontUIResource(Config.getFontName(), Font.PLAIN, Config.getFontSize()));

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setSize(Config.getPrimaryFrameWidth(), Config.getPrimaryFrameHeight());

        // 创建选项卡面板
        JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.LEFT);
        tabbedPane.addTab("管理员入口", null, new AdminLogin(), "管理员登录");
        tabbedPane.addTab("商家入口", null, new SellerLoginAndRegister(), "商家登录/注册");
        tabbedPane.addTab("用户入口", null, new UserLoginAndRegister(), "用户登录/注册");

        // 将选项卡面板添加到框架
        add(tabbedPane, BorderLayout.CENTER);

        setLocationRelativeTo(null);
        setVisible(true);
    }
}
