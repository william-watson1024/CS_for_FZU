package com.hang.gui.primaryframe.tabbedpanels.registerframes;

import com.hang.entity.Seller;
import com.hang.service.SellerService;
import com.hang.service.impl.SellerServiceImpl;
import com.hang.utils.CheckCodeUtil;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;

public class SellerRegisterFrame extends JFrame {
    private String checkCode;
    private SellerService sellerService = new SellerServiceImpl();

    JPanel contentPanel = new JPanel(new GridBagLayout());

    JLabel idLabel = new JLabel("账号:");
    JTextField idField = new JTextField(10);

    JLabel passwordLabel = new JLabel("密码:");
    JPasswordField passwordField = new JPasswordField(10);

    JLabel checkPasswordLabel = new JLabel("确认密码:");
    JPasswordField checkPasswordField = new JPasswordField(10);

    JLabel nameLabel = new JLabel("姓名:");
    JTextField nameField = new JTextField(10);

    JLabel phoneLabel = new JLabel("手机号:");
    JTextField phoneField = new JTextField(10);

    JLabel idNumberLabel = new JLabel("身份证号:");
    JTextField idNumberField = new JTextField(10);

    JButton checkCodeButton = new JButton();
    JTextField checkCodeField = new JTextField(8);
    JPanel checkCodePanel = new JPanel();

    JPanel checkButtonPanel = new JPanel();
    JButton checkButton = new JButton("确定");


    public SellerRegisterFrame(){
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5, 5, 5, 5);

        // 第1行：账号
        c.gridy = 0;

        c.gridx = 0;
        contentPanel.add(idLabel,c);

        c.gridx = 1;
        contentPanel.add(idField,c);

        // 第2行：密码
        c.gridy = 1;

        c.gridx = 0;
        contentPanel.add(passwordLabel,c);

        c.gridx = 1;
        contentPanel.add(passwordField,c);

        // 第3行：确认密码
        c.gridy = 2;

        c.gridx = 0;
        contentPanel.add(checkPasswordLabel,c);

        c.gridx = 1;
        contentPanel.add(checkPasswordField,c);


        // 第4行：姓名
        c.gridy = 3;
        
        c.gridx = 0;
        contentPanel.add(nameLabel,c);

        c.gridx = 1;
        contentPanel.add(nameField,c);


        // 第5行：手机号
        c.gridy = 4;
        
        c.gridx = 0;
        contentPanel.add(phoneLabel,c);

        c.gridx = 1;
        contentPanel.add(phoneField,c);

        
        // 第6行：身份证号
        c.gridy = 5;
        
        c.gridx = 0;
        contentPanel.add(idNumberLabel,c);

        c.gridx = 1;
        contentPanel.add(idNumberField,c);


        // 第7行：验证码panel
        c.gridy = 6;
        
        checkCodeField.setPreferredSize(new Dimension(180, 45));
        
        checkCodeButton.addActionListener(e -> {
            checkCode = CheckCodeUtil.setButtonIconAndReturnCheckCode(checkCodeButton);
        });

        checkCodePanel.setOpaque(false);

        checkCodePanel.add(checkCodeField);
        checkCodePanel.add(checkCodeButton);

        checkCode = CheckCodeUtil.setButtonIconAndReturnCheckCode(checkCodeButton);

        c.gridx = 0;
        c.gridwidth = 2;
        contentPanel.add(checkCodePanel, c);

        
        // 第8行：确定按钮panel
        c.gridy = 7;
        
        checkButtonPanel.add(checkButton);

        c.gridx = 0;
        c.gridwidth = 2;
        contentPanel.add(checkButtonPanel,c);
        
        checkButton.addActionListener(e->{
            Seller seller = sellerService.selectById(idField.getText());
            if(idField.getText().isEmpty()){
                JOptionPane.showMessageDialog(null,"账号不能为空");
            }else if(seller!=null){
                JOptionPane.showMessageDialog(null,"账号已存在");
            }else if(passwordField.getText().length()<6){
                JOptionPane.showMessageDialog(null,"密码不少于6位");
            }else if(!passwordField.getText().equals(checkPasswordField.getText())){
                JOptionPane.showMessageDialog(null,"两次输入密码不一致");
            } else if(nameField.getText().equals("")){
                JOptionPane.showMessageDialog(null,"姓名不能为空");
            } else if(phoneField.getText().equals("")){
                JOptionPane.showMessageDialog(null,"手机号不能为空");
            } else if(idNumberField.getText().equals("")){
                JOptionPane.showMessageDialog(null,"身份证号不能为空");
            } else if(!checkCode.equalsIgnoreCase(checkCodeField.getText())){
                JOptionPane.showMessageDialog(null,"验证码错误");
                checkCode = CheckCodeUtil.setButtonIconAndReturnCheckCode(checkCodeButton);
            }else{
                Seller newSeller = new Seller();
                newSeller.setSellerId(idField.getText());
                newSeller.setPassword(passwordField.getText());
                newSeller.setName(nameField.getText());
                newSeller.setPhoneNumber(phoneField.getText());
                newSeller.setIdNumber(idNumberField.getText());
                newSeller.setRegisterDate(LocalDate.now());

                sellerService.insert(newSeller);

                JOptionPane.showMessageDialog(this,"商家注册成功");
                dispose();
            }
        });

        // 设置窗口参数
        add(contentPanel);
        setVisible(true);
        pack();
        setLocationRelativeTo(this);
    }
}
