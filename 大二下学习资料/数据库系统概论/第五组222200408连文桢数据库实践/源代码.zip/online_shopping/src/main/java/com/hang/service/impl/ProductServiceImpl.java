package com.hang.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hang.entity.Product;
import com.hang.entity.Shop;
import com.hang.entity.User;
import com.hang.mapper.ProductMapper;
import com.hang.mybatisplusmapper.ProductMybatisPlusMapper;
import com.hang.service.ProductService;
import com.hang.service.ShopService;
import com.hang.utils.MybatisPlusSqlSessionFactoryUtil;
import com.hang.utils.SqlSessionFactoryUtil;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ProductServiceImpl implements ProductService {
    private SqlSessionFactory sqlSessionFactory = SqlSessionFactoryUtil.getSqlSessionFactory();
private SqlSessionFactory mybatisPlusSqlSessionFactory = MybatisPlusSqlSessionFactoryUtil.getMybatisPlusSqlSessionFactory();
    ShopService shopService = new ShopServiceImpl();

    @Override
    public List<Product> selectAll() {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ProductMapper mapper = sqlSession.getMapper(ProductMapper.class);
        List<Product> products = mapper.selectAll();
       sqlSession.close();

        return products;
    }

    @Override
    public Product selectById(Integer id) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ProductMapper mapper = sqlSession.getMapper(ProductMapper.class);
        Product product = mapper.selectById(id);

        sqlSession.close();
        return product;
    }

    @Override
    public List<Product> selectByConditions(String keyWord, BigDecimal lowestPrice, BigDecimal highestPrice) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ProductMapper mapper = sqlSession.getMapper(ProductMapper.class);
        List<Product> products = mapper.selectByConditions("%"+keyWord+"%",lowestPrice,highestPrice);
        sqlSession.close();

        return products;
    }

    @Override
    public List<Product> selectByShopIdAndConditions(String keyWord, BigDecimal lowestPrice, BigDecimal highestPrice, Integer shopId) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ProductMapper mapper = sqlSession.getMapper(ProductMapper.class);
        List<Product> products = mapper.selectByShopIdAndConditions("%"+keyWord+"%",  lowestPrice,  highestPrice,  shopId);
        sqlSession.close();

        return products;
    }

    @Override
    public void insert(Product product) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ProductMapper mapper = sqlSession.getMapper(ProductMapper.class);
        mapper.insert(product);
        sqlSession.commit();

        sqlSession.close();
    }

    @Override
    public void updateById(Product product) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ProductMapper mapper = sqlSession.getMapper(ProductMapper.class);

        mapper.updateById(product);
        sqlSession.commit();

        sqlSession.close();
    }

    @Override
    public void deleteById(Integer id) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ProductMapper mapper = sqlSession.getMapper(ProductMapper.class);

        mapper.deleteById(id);
        sqlSession.commit();

        sqlSession.close();
    }

    @Override
    public Page<Product> selectForProductManage(String searchCategory, String searchText, String orderedByPrice, String status,int currentPage, int pageSize) {
        SqlSession sqlSession = mybatisPlusSqlSessionFactory.openSession();
        ProductMybatisPlusMapper mapper = sqlSession.getMapper(ProductMybatisPlusMapper.class);

        LambdaQueryWrapper<Product> lambdaQueryWrapper = new LambdaQueryWrapper<>();

        if(!"全部".equals(status)){
            lambdaQueryWrapper.eq(Product::getStatus,status);
        }

        if("商品名".equals(searchCategory)){
            lambdaQueryWrapper.like(Product::getName,searchText);
        }else if("店铺名".equals(searchCategory)){
            List<Shop> shops = shopService.selectLikeShopName(searchText);
            List<Integer> shopIds = new ArrayList<>();
            for (Shop shop : shops) {
                Integer shopId = shop.getShopId();
                shopIds.add(shopId);
            }

            lambdaQueryWrapper.in(shopIds.size()>0,Product::getShopId, shopIds);
        }else if("品牌".equals(searchCategory)){
            lambdaQueryWrapper.like(Product::getBrand,searchText);
        }

        if("升序".equals(orderedByPrice)){
            lambdaQueryWrapper.orderByAsc(Product::getPrice);
        }else if("降序".equals(orderedByPrice)){
            lambdaQueryWrapper.orderByDesc(Product::getPrice);
        }

        Page<Product> page = new Page<>(currentPage, pageSize);
        Page<Product> productPage = mapper.selectPage(page, lambdaQueryWrapper);
//        List<Product> products = mapper.selectList(lambdaQueryWrapper);
        sqlSession.close();
        return productPage;
    }
}
