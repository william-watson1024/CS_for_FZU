package com.hang.service;

import com.hang.entity.Product;
import com.hang.entity.SaleVolumn;

import java.util.List;

public interface SaleVolumnService {
    void insert(SaleVolumn saleVolumn);
    List<SaleVolumn> selectByShopId(Integer shopId);

}
