package com.hang.gui.adminframe.tabbedpanels;

import com.hang.entity.Order;
import com.hang.entity.Product;
import com.hang.entity.Seller;
import com.hang.service.OrderService;
import com.hang.service.ProductService;
import com.hang.service.UserAndShopService;
import com.hang.service.impl.OrderServiceImpl;
import com.hang.service.impl.ProductServiceImpl;
import com.hang.service.impl.UserAndShopServiceImpl;
import com.hang.utils.TableUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import java.awt.*;
import java.util.List;

public class OrderManage extends JPanel {
    OrderService orderService = new OrderServiceImpl();
    ProductService productService = new ProductServiceImpl();
    UserAndShopService userAndShopService = new UserAndShopServiceImpl();

    JTable table = new JTable();
    List<Order> orders;

    String[] orderedByOptions = {"最近创建订单", "大额订单"};
    JComboBox<String> orderedByComboBox = new JComboBox<>(orderedByOptions);

    String[] paymentStatusOptions = {"全部", "已支付", "未支付", "已退款"};
    JComboBox<String> paymentStatusComboBox = new JComboBox<>(paymentStatusOptions);

    String[] deliveryStatusOptions = {"全部", "未发货", "已发货", "已签收", "退货中", "已退货"};
    JComboBox<String> deliveryStatusComboBox = new JComboBox<>(deliveryStatusOptions);

    public OrderManage() {
        setLayout(new BorderLayout());

        add(new JScrollPane(table), BorderLayout.CENTER);
        setNorthPanel();
        setSouthPanel();

        updateTable();
    }

    private void setSouthPanel() {
        JPanel southPanel = new JPanel();
        JButton cancelOrderButton  = new JButton("撤销订单");
        southPanel.add(cancelOrderButton);
        add(southPanel,BorderLayout.SOUTH);

        cancelOrderButton.addActionListener(e->{
            int selectedRow = table.getSelectedRow();
            if(selectedRow == -1){
                return;
            }
            Order order = orders.get(selectedRow);
            String paymentStatus = order.getPaymentStatus();
            String message = "未知错误";
            if("已退款".equals(paymentStatus)){
                message = "已退款。";
            }else  if("未支付".equals(paymentStatus)){
                message = "未支付，无资金变动。";
            }else if("已支付".equals(paymentStatus)){
                order.setDeliveryStatus("已退货");
                Product product = productService.selectById(order.getProductId());
                message = userAndShopService.balanceFromShopToUser(order.getTotalAmount(), product.getShopId(), order.getUserId());
            }
            JOptionPane.showMessageDialog(this,message);
            if("店铺营业额不足。".equals(message)){
                return;
            }
            order.setPaymentStatus("已退款");
            orderService.updateById(order);
            updateTable();
            table.setRowSelectionInterval(selectedRow,selectedRow);
        });
    }

    private void setNorthPanel() {
        JPanel northPanel = new JPanel();

        northPanel.add(new JLabel("排序:"));
        northPanel.add(orderedByComboBox);

        northPanel.add(new JLabel("   物流状态:"));
        northPanel.add(deliveryStatusComboBox);

        northPanel.add(new JLabel("   支付状态:"));
        northPanel.add(paymentStatusComboBox);

        add(northPanel, BorderLayout.NORTH);

        orderedByComboBox.addActionListener(e->updateTable());
        deliveryStatusComboBox.addActionListener(e->updateTable());
        paymentStatusComboBox.addActionListener(e->updateTable());
    }

    private void updateTable() {
        String orderedBy = (String) orderedByComboBox.getSelectedItem();
        String deliveryStatus = (String) deliveryStatusComboBox.getSelectedItem();
        String paymentStatus = (String) paymentStatusComboBox.getSelectedItem();

        orders = orderService.selectForOrderManage(orderedBy,deliveryStatus,paymentStatus);
        // 创建表格模型
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("订单号");
        model.addColumn("用户ID");
        model.addColumn("商品ID");
        model.addColumn("订单创建时间");
        model.addColumn("订单完成时间");
        model.addColumn("金额");
        model.addColumn("物流状态");
        model.addColumn("支付状态");

        // 添加数据到表格模型
        for (Order order : orders) {
            model.addRow(new Object[]{order.getOrderId(), order.getUserId(), order.getProductId(), order.getOrderCreateDatetime(), order.getPaymentDatetime(), order.getTotalAmount(), order.getDeliveryStatus(), order.getPaymentStatus()});
        }

        table.setModel(model);
        // 使用工具类，设置表格样式
        TableUtils.setTableStyle(table);
        TableUtils.autoResizeColumns(table);
    }
}
