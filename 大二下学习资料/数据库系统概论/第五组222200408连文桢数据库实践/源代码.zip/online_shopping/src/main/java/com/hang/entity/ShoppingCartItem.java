package com.hang.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 购物车表
 * </p>
 *
 * @author hang
 * @since 2024-05-23
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class ShoppingCartItem implements Serializable {


    /**
     * 主键 自增长
     */
    @TableId(value = "shopping_cart_item_id", type = IdType.NONE)
    private Integer shoppingCartItemId;

    /**
     * 归属用户
     */
    private String userId;

    /**
     * 商品
     */
    private Integer productId;

    /**
     * 数量
     */
    private Integer number;

    /**
     * 添加时间
     */
    private LocalDateTime addDatetime;

    /**
     * 收货地址
     */
    private Integer addressBookId;

    /**
     * 备注
     */
    private String remark;


}
