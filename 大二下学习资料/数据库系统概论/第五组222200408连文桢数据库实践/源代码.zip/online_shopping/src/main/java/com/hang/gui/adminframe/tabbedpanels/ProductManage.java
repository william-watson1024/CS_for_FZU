package com.hang.gui.adminframe.tabbedpanels;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hang.entity.Product;
import com.hang.entity.Shop;
import com.hang.service.ProductService;
import com.hang.service.ShopService;
import com.hang.service.impl.ProductServiceImpl;
import com.hang.service.impl.ShopServiceImpl;
import com.hang.utils.ImageUtils;
import com.hang.utils.TableUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ProductManage extends JPanel {
    private ProductService productService = new ProductServiceImpl();
    private ShopService shopService = new ShopServiceImpl();

    List<Product> products;

    JTable table = new JTable();

    String[] searchOptions = {"商品名", "店铺名", "品牌"};
    JComboBox<String> searchComboBox = new JComboBox<>(searchOptions);
    JTextField searchField = new JTextField(10);
    JButton searchButton = new JButton("搜索");
    String[] ordered = {"降序", "升序"};
    JComboBox<String> orderedComboBox = new JComboBox<>(ordered);

    String[] statusOptions = {"全部", "在售", "缺货", "已下架"};
    JComboBox<String> statusComboBox = new JComboBox<>(statusOptions);

    JButton deListProductButton = new JButton("下架商品");
    JButton listProductButton = new JButton("重新上架");

    Integer[] pageSizes = {5, 10, 20};
    JComboBox<Integer> pageSizeComboBox = new JComboBox<>(pageSizes);

    JLabel itemCountLabel = new JLabel();
    JTextField currentPageField = new JTextField("1", 2);
    JLabel totalPageLabel = new JLabel();
    JButton pageUpButton = new JButton("上一页");
    JButton pageDownButton = new JButton("下一页");

    int pageSize;
    int currentPage;
    long itemCount;
    long totalPage;

    public ProductManage() {
        setLayout(new BorderLayout());

        add(new JScrollPane(table), BorderLayout.CENTER);
        setNorthPanel();
        setSouthPanel();

        new Thread(this::updateTable).start();
    }

    private void setSouthPanel() {
        JPanel southPanel = new JPanel(new FlowLayout());

        southPanel.add(itemCountLabel);
        southPanel.add(new JLabel("每页"));
        southPanel.add(pageSizeComboBox);
        southPanel.add(new JLabel("条  "));
        southPanel.add(pageUpButton);
        southPanel.add(currentPageField);
        southPanel.add(totalPageLabel);
        southPanel.add(pageDownButton);

        add(southPanel, BorderLayout.SOUTH);

        pageSizeComboBox.addActionListener(e -> {
            currentPage = 1;
            currentPageField.setText("1");
            updateTable();
        });
        currentPageField.addActionListener(e -> {
            int currentPage = Integer.parseInt(currentPageField.getText());
            if (currentPage <= 0 || currentPage > totalPage) {
                JOptionPane.showMessageDialog(this, "页数超出范围");
                currentPageField.setText(String.valueOf(currentPage));
            } else {
                updateTable();
            }
        });

        pageUpButton.addActionListener(e -> {
            if (currentPage <= 1) {
                return;
            }
            currentPage -= 1;
            currentPageField.setText(String.valueOf(currentPage));
            updateTable();
        });

        pageDownButton.addActionListener(e -> {
            if (currentPage >= totalPage) {
                return;
            }
            currentPage += 1;
            currentPageField.setText(String.valueOf(currentPage));
            updateTable();
        });
    }

    private void setNorthPanel() {
        JPanel northPanel = new JPanel();

        northPanel.add(new JLabel("搜索内容:"));
        northPanel.add(searchComboBox);
        northPanel.add(searchField);
        northPanel.add(searchButton);
        northPanel.add(new JLabel("   价格序:"));
        northPanel.add(orderedComboBox);
        northPanel.add(new JLabel("   商品状态:"));
        northPanel.add(statusComboBox);
        northPanel.add(deListProductButton);
        northPanel.add(listProductButton);

        searchComboBox.addActionListener(e -> {
            currentPage = 1;
            currentPageField.setText("1");
            updateTable();
        });

        orderedComboBox.addActionListener(e -> {
            currentPage = 1;
            currentPageField.setText("1");
            updateTable();
        });

        searchButton.addActionListener(e -> {
            currentPage = 1;
            currentPageField.setText("1");
            updateTable();
        });

        statusComboBox.addActionListener(e -> {
            currentPage = 1;
            currentPageField.setText("1");
            updateTable();
        });

        deListProductButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow == -1) {
                return;
            }
            Product product = products.get(selectedRow);
            product.setStatus("已下架");
            productService.updateById(product);
            updateTable();
            for (int i = 0; i < products.size(); i++) {
                if (product.getProductId().equals(products.get(i).getProductId())) {
                    table.setRowSelectionInterval(i, i);
                    break;
                }
            }
        });

        listProductButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow == -1) {
                return;
            }
            Product product = products.get(selectedRow);
            if(product.getStock()<=0){
                product.setStatus("缺货");
            }else{
                product.setStatus("在售");
            }
            productService.updateById(product);
            updateTable();
            for (int i = 0; i < products.size(); i++) {
                if (product.getProductId().equals(products.get(i).getProductId())) {
                    table.setRowSelectionInterval(i, i);
                    break;
                }
            }
        });

        add(northPanel, BorderLayout.NORTH);
    }

    private void updateTable() {
        String searchCategory = (String) searchComboBox.getSelectedItem();
        String searchText = searchField.getText();
        String orderedByPrice = (String) orderedComboBox.getSelectedItem();
        String status = (String) statusComboBox.getSelectedItem();
        pageSize = (int) pageSizeComboBox.getSelectedItem();
        currentPage = Integer.parseInt(currentPageField.getText());

        Page<Product> productPage = productService.selectForProductManage(searchCategory, searchText, orderedByPrice, status, currentPage, pageSize);
        products = productPage.getRecords();
        itemCount = productPage.getTotal();
//            totalPage = itemCount/pageSize+1;
        totalPage = productPage.getPages();
        itemCountLabel.setText(String.format("一共%d条, ", itemCount));
        totalPageLabel.setText("/" + totalPage);

        if (currentPage <= 0 || currentPage > totalPage) {
            currentPage = 1;
            currentPageField.setText("1");
            productPage = productService.selectForProductManage(searchCategory, searchText, orderedByPrice, status, currentPage, pageSize);
            products = productPage.getRecords();
        }


        if (products == null || products.size() == 0) {
            table.setModel(new DefaultTableModel());
            return;
        }

        // 定义列名
        String[] columnNames = {"序号", "照片", "商品名", "品牌", "店铺名", "价格", "商品状态","库存"};

        // 创建一个二维 Object 数组，行数为产品数量，列数为 8
        Object[][] data = new Object[products.size()][8];


        TableUtils.setTableStyle(table);


        // 遍历产品列表，将每个产品的信息填充到 Object 数组中
        for (int i = 0; i < products.size(); i++) {
            Product product = products.get(i);
            Shop shop = shopService.selectById(product.getShopId());
            String shopName = shop.getShopName();

            String path = "image/product/" + product.getPhoto();
            ImageIcon icon = ImageUtils.getProductImageIcon(150, 150, path);


            data[i][0] = (currentPage - 1) * pageSize + i + 1;
            data[i][1] = icon;
            data[i][2] = product.getName();
            data[i][3] = product.getBrand();
            data[i][4] = shopName;
            data[i][5] = product.getPrice();
            data[i][6] = product.getStatus();
            data[i][7] = product.getStock();
        }


        // 创建表格模型
        DefaultTableModel model = new DefaultTableModel(data, columnNames) {
            @Override
            public Class<?> getColumnClass(int column) {
                if (column == 1) {
                    return ImageIcon.class;
                } else {
                    return String.class;
                }
            }
        };

        table.setModel(model);

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();

        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);

        // 将渲染器应用于所有列
        for (int i = 0; i < table.getColumnCount(); i++) {
            if (i != 1) {
                table.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
            }
        }

        table.setRowHeight(150);

    }
}
