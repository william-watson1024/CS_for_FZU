package com.hang.gui.shopframe;

import com.hang.entity.Shop;
import com.hang.gui.shopframe.tabbedpanels.*;


import javax.swing.*;
import java.awt.*;

public class ShopFrame extends JFrame {
    public ShopFrame(Shop shop){
        setTitle("店铺："+shop.getShopName());

        JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.LEFT);

        setExtendedState(JFrame.MAXIMIZED_BOTH);
//        setSize(1000, 750);

        tabbedPane.addTab("欢迎", null, new Welcome(shop), "欢迎");
        tabbedPane.addTab("商品管理", null, new ProductManagement(shop,this), "商品管理");
        tabbedPane.addTab("进货明细", null, new PurchaseDetails(shop), "进货明细");
        tabbedPane.addTab("销售量管理", null, new SalesVolumeManagement(shop,this), "销售量管理");
        tabbedPane.addTab("新 销售量管理", null, new SalesVolumeManagement2(shop,this), "销售量管理");

        tabbedPane.addTab("订单管理", null, new OrderManagement(shop,this), "订单管理");
        tabbedPane.addTab("售后服务", null, new AfterSalePanel(shop,this), "售后服务");
        tabbedPane.addTab("账单和营业额", null, new IncomeExpenses(shop,this), "账单和营业额");
        tabbedPane.addTab("修改店铺信息", null, new ChangeInformation(shop), "修改店铺信息");
        // 将选项卡面板添加到框架
        add(tabbedPane, BorderLayout.CENTER);
        setLocationRelativeTo(null);
        // 显示窗口/
        setVisible(true);
    }





}
