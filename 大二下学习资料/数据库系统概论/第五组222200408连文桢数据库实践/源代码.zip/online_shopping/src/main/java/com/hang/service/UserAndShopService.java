package com.hang.service;

import java.math.BigDecimal;

public interface UserAndShopService {
    String balanceFromUserToShop(BigDecimal amount,String userId,Integer shopId);
    String balanceFromShopToUser(BigDecimal amount,Integer shopId,String userId);
}
