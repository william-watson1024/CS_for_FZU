package com.hang.service;

import com.hang.entity.UserBilling;

import java.util.List;

public interface UserBillingService {
    List<UserBilling> selectAll();
    UserBilling selectById(Integer id);
    List<UserBilling> selectByUserId(String userId);
    void insert(UserBilling userBilling);
    void updateById(UserBilling userBilling);
    void deleteById(Integer id);
}
