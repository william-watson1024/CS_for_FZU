package com.hang.gui.primaryframe.tabbedpanels;

import com.hang.entity.Admin;
import com.hang.gui.adminframe.AdminFrame;
import com.hang.service.AdminService;
import com.hang.service.impl.AdminServiceImpl;
import com.hang.utils.CheckCodeUtil;
import com.hang.utils.ImageUtils;
import com.hang.utils.PasswordUtil;
import lombok.extern.slf4j.Slf4j;

import javax.swing.*;
import java.awt.*;

@Slf4j
public class AdminLogin extends JPanel {
    private AdminService adminService = new AdminServiceImpl();
    private String checkCode;

    JLabel idLabel = new JLabel("账号:");
    JTextField idText = new JTextField(10);

    JLabel passwordLabel = new JLabel("密码:");
    JPasswordField passwordText = new JPasswordField(10);

    JButton checkCodeButton = new JButton();
    JTextField checkCodeField = new JTextField(8);
    JPanel checkCodePanel = new JPanel();

    JButton loginButton = new JButton("登录");
    JPanel buttonPanel = new JPanel();


    public AdminLogin() {
        setLayout(new GridBagLayout());

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5, 5, 5, 5);

        // 第1行：账号
        c.gridy = 0;

        c.gridx = 0;
        add(idLabel, c);

        c.gridx = 1;
        add(idText, c);


        // 第2行：密码
        c.gridy = 1;

        c.gridx = 0;
        add(passwordLabel, c);

        c.gridx = 1;
        add(passwordText, c);


        // 第3行：验证码panel
        c.gridy = 2;

        checkCodeField.setPreferredSize(new Dimension(180, 45));

        checkCodeButton.addActionListener(e -> {
            checkCode = CheckCodeUtil.setButtonIconAndReturnCheckCode(checkCodeButton);
        });

        checkCodePanel.setOpaque(false);

        checkCodePanel.add(checkCodeField);
        checkCodePanel.add(checkCodeButton);

        checkCode = CheckCodeUtil.setButtonIconAndReturnCheckCode(checkCodeButton);

        c.gridx = 0;
        c.gridwidth = 2;
        add(checkCodePanel, c);


        // 第4行：登录panel
        c.gridy = 3;

        buttonPanel.setOpaque(false);
        buttonPanel.add(loginButton);

        c.gridx = 0;
        c.gridwidth = 2;
        add(buttonPanel, c);

        loginButton.addActionListener(e -> {
            try {
                Admin admin = adminService.selectById(idText.getText());
                if (!checkCode.equalsIgnoreCase(checkCodeField.getText())) {
                    JOptionPane.showMessageDialog(this, "验证码错误");
                } else if (admin == null) {
                    JOptionPane.showMessageDialog(this, "管理员不存在");
                } else if (!PasswordUtil.checkPassword(passwordText.getText(),admin.getPassword())) {
                    JOptionPane.showMessageDialog(this, "密码错误");
                } else {
                    SwingUtilities.invokeLater(() -> {
                        new AdminFrame(admin);
                    });
                }
                checkCode = CheckCodeUtil.setButtonIconAndReturnCheckCode(checkCodeButton);
            } catch (Exception ex) {
                log.error(ex.getMessage());
                JOptionPane.showMessageDialog(this, "请检查配置文件中密码是否正确，\n或者数据库是否能正常连接", "数据库连接异常", JOptionPane.ERROR_MESSAGE);
            }

        });

        // 设置默认值，方便调试
//        idText.setText("admin");
//        passwordText.setText("123456");
//        checkCodeField.setText(checkCode);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        String backgroundPath = "image/background/admin_login.jpg";
        ImageUtils.drawBackground(backgroundPath,g,this);
    }
}
