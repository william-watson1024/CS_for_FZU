package com.hang.service;

import com.hang.entity.ShoppingCartItem;

import java.util.List;

public interface ShoppingCartItemService {
    List<ShoppingCartItem> selectAll();
    ShoppingCartItem selectById(Integer id);
    List<ShoppingCartItem> selectByUserId(String userId);
    void insert(ShoppingCartItem shoppingCartItem);
    void updateById(ShoppingCartItem shoppingCartItem);
    void deleteById(Integer id);
}
