package com.hang.entity;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import java.io.Serializable;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 订单表
 * </p>
 *
 * @author hang
 * @since 2024-05-23
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("`order`")
public class Order implements Serializable {


    /**
     * 主键 自增长
     */
    @TableId(value = "order_id", type = IdType.AUTO)
    private Integer orderId;

    /**
     * 用户
     */
    private String userId;

    /**
     * 商品
     */
    private Integer productId;

    /**
     * 收货地址
     */
    private Integer addressBookId;

    /**
     * 商品数量
     */
    private Integer productNumber;

    /**
     * 订单创建时间
     */
    private LocalDateTime orderCreateDatetime;

    /**
     * 支付完成时间
     */
    private LocalDateTime paymentDatetime;

    /**
     * 总价
     */
    private BigDecimal totalAmount;

    /**
     * 支付状态 (已支付|未支付|已退款) 默认:未支付
     */
    private String paymentStatus;

    /**
     * 物流状态 (未发货|已发货|已签收|退货中|已退货) 默认:未发货
     */
    private String deliveryStatus;

    /**
     * 备注
     */
    private String remark;


}
