package com.hang.service;

import com.hang.entity.ShopBilling;

import java.time.LocalDateTime;
import java.util.List;

public interface ShopBillingService {
    List<ShopBilling> selectAll();
    ShopBilling selectById(Integer id);
    List<ShopBilling> selectByShopIdAndTimeRange(LocalDateTime begin, LocalDateTime  end, Integer shopId);
    void insert(ShopBilling shopBilling);
    void updateById(ShopBilling shopBilling);
    void deleteById(Integer id);
}
