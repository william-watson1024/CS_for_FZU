package com.hang.service;

import com.hang.entity.Admin;

import java.sql.SQLException;
import java.util.List;

public interface AdminService {
    List<Admin> selectAll();
    Admin selectById(String id) throws SQLException;
    void updateById(Admin admin);
    void deleteById(String id);
    void insert(Admin admin);
}
