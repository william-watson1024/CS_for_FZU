package com.hang.mapper;



import com.hang.entity.AddressBook;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface AddressBookMapper {
    @Select("select * from address_book where user_id=#{useId}")
    List<AddressBook> selectByUserId(String userId);

    @Select("select * from address_book where user_id=#{userId} and is_default='是'")
    AddressBook selectDefaultByUserId(String userId);

    @Update("update address_book set is_default = '否' where is_default='是'")
    void clearDefaultAddressBook();

    @Update("update address_book set is_default = '是' where address_book_id=#{addressId}")
    void setDefaultAddressBook(Integer addressId);

    @Select("select * from address_book")
    List<AddressBook> selectAll();

    @Select("select * from address_book where address_book_id=#{id}")
    AddressBook selectById(Integer id);

    @Insert("insert into address_book(address_book_id, user_id, consignee, phone_number, province_name, city_name, district_name, detail, is_default) VALUES (null, #{userId}, #{consignee}, #{phoneNumber}, #{provinceName}, #{cityName}, #{districtName}, #{detail}, #{isDefault})")
    void insert(AddressBook addressBook);

    @Update("update address_book set consignee=#{consignee},phone_number=#{phoneNumber},province_name=#{provinceName},city_name=#{cityName},district_name=#{districtName},detail=#{detail},is_default=#{isDefault} where address_book_id=#{addressBookId}")
    void updateById(AddressBook addressBook);

    @Delete("delete from address_book where address_book_id=#{id}")
    void deleteById(Integer id);
}
