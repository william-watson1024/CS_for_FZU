package com.hang.config;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Properties;

public class Config {
    private static Properties properties = new Properties();

    static {
        try (InputStream input = Config.class.getClassLoader().getResourceAsStream("config.properties")) {
            if (input == null) {
                System.out.println("Sorry, unable to find config.properties");
            } else {
                properties.load(new InputStreamReader(input, StandardCharsets.UTF_8));
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }


    public static int getPrimaryFrameWidth() {
        return Integer.parseInt(properties.getProperty("primary_frame.width"));
    }

    public static int getPrimaryFrameHeight() {
        return Integer.parseInt(properties.getProperty("primary_frame.height"));
    }

    public static int getFrameWidth() {
        return Integer.parseInt(properties.getProperty("frame.width"));
    }

    public static int getFrameHeight() {
        return Integer.parseInt(properties.getProperty("frame.height"));
    }

    public static String getFontName() {
        return properties.getProperty("font.name");
    }

    public static int getFontSize() {
        return Integer.parseInt(properties.getProperty("font.size"));
    }
    public static int getTableRowHeight() {
        return Integer.parseInt(properties.getProperty("table.row_height"));
    }
}

