package com.hang.mapper;

import com.hang.entity.Shop;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface ShopMapper {
    @Select("select * from shop")
    List<Shop> selectAll();

    @Select("select * from shop where shop_name like #{shopName}")
    List<Shop> selectLikeShopName(String shopName);

    @Select("select * from shop where shop_id=#{id}")
    Shop selectById(Integer id);

    @Select("select * from shop where seller_id=#{sellerId}")
    List<Shop> selectBySellerId(String sellerId);

    @Insert("insert into shop(shop_id, seller_id, shop_name, photo, shop_description, business_license, legal_person, verify_status, shop_revenue) VALUES (null, #{sellerId}, #{shopName}, #{photo}, #{shopDescription}, #{businessLicense}, #{legalPerson}, #{verifyStatus},0 )")
    void insert(Shop shop);

    @Update("update shop set seller_id=#{sellerId}, shop_name=#{shopName}, photo=#{photo}, shop_description=#{shopDescription}, business_license=#{businessLicense}, legal_person=#{legalPerson}, verify_status=#{verifyStatus}, shop_revenue=#{shopRevenue} where shop_id=#{shopId}")
    void updateById(Shop shop);

    @Delete("delete from shop where shop_id=#{id}")
    void deleteById(Integer id);
}
