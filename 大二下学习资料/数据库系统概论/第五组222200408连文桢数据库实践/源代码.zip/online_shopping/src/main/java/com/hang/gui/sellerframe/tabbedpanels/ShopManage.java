package com.hang.gui.sellerframe.tabbedpanels;

import com.hang.entity.Seller;
import com.hang.entity.Shop;
import com.hang.gui.sellerframe.SellerFrame;
import com.hang.gui.shopframe.ShopFrame;
import com.hang.service.ShopService;
import com.hang.service.impl.ShopServiceImpl;
import com.hang.utils.TableUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.util.List;

public class ShopManage extends JPanel {
    private ShopService shopService = new ShopServiceImpl();

    public ShopManage(Seller seller, SellerFrame sellerFrame){


        setLayout(new BorderLayout());


        List<Shop> shops = shopService.selectBySellerId(seller.getSellerId());

        // 创建表格模型
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("店铺名");
        model.addColumn("商业执照号");
        model.addColumn("法人");
        model.addColumn("认证状态");

        // 添加数据到表格模型
        for (Shop shop : shops) {
            model.addRow(new Object[]{shop.getShopName(),shop.getBusinessLicense(),shop.getLegalPerson(),shop.getVerifyStatus()});
        }

        // 创建表格
        JTable table = new JTable(model);

        // 使用工具类，设置表格样式
        TableUtils.setTableStyle(table);

        // 创建滚动面板并将表格添加到其中
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane,BorderLayout.CENTER);


        JButton enterShopButton =  new JButton("进入店铺管理");
        JPanel buttonPanel = new JPanel();
        JButton addShopButton =  new JButton("添加店铺");
        buttonPanel.add(enterShopButton);
        buttonPanel.add(addShopButton);
        add(buttonPanel,BorderLayout.SOUTH);

        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);


        enterShopButton.addActionListener(e -> SwingUtilities.invokeLater(()->{

            int selectedRow= table.getSelectedRow();
            System.out.println(selectedRow);
            if(selectedRow!=-1) {
                Shop shop = shops.get(selectedRow);
                if(shop.getVerifyStatus().equals("审核中")){
                    JOptionPane.showMessageDialog(null, "店铺审核中，请等待审核");
                    return;
                }
                else if(shop.getVerifyStatus().equals("未通过")){
                    JOptionPane.showMessageDialog(null, "店铺审核未通过!");
                    return;
                }
                else {
                    SwingUtilities.invokeLater(() -> {
                        new ShopFrame(shop);
                    });
                }
            }
            else{
                JOptionPane.showMessageDialog(null, "未选择任何店铺！");
            }
        }));

        addShopButton.addActionListener(e -> SwingUtilities.invokeLater(()->{

            showAddShopDialog(shops, model, seller);

        }));


    }



    private void showAddShopDialog(List<Shop> shops, DefaultTableModel model, Seller seller) {
        JDialog addShopDialog = new JDialog();
        addShopDialog.setTitle("Add New Shop");
        addShopDialog.setSize(600, 400);
        addShopDialog.setLocationRelativeTo(null); // Center the dialog

        JPanel panel = new JPanel();
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GroupLayout layout = new GroupLayout(panel);
        panel.setLayout(layout);
        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);

        JLabel shopNameLabel = new JLabel("店铺名:");
        JTextField shopNameField = new JTextField(20);

        JLabel photoLabel = new JLabel("店铺照片:");
        JTextField photoField = new JTextField(20);
        JButton photoButton = new JButton("选择文件");
        photoButton.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();
            int returnValue = fileChooser.showOpenDialog(null);
            if (returnValue == JFileChooser.APPROVE_OPTION) {
                File selectedFile = fileChooser.getSelectedFile();
                photoField.setText(selectedFile.getAbsolutePath());
            }
        });

        JLabel shopDescriptionLabel = new JLabel("店铺描述:");
        JTextField shopDescriptionField = new JTextField(20);

        JLabel businessLicenseLabel = new JLabel("商业执照号:");
        JTextField businessLicenseField = new JTextField(20);

        JLabel legalPersonLabel = new JLabel("法人:");
        JTextField legalPersonField = new JTextField(20);

        JLabel verifyStatusLabel = new JLabel("认证状态:");
        JComboBox<String> verifyStatusComboBox = new JComboBox<>(new String[]{"审核中"});

        JButton submitButton = new JButton("提交");
        submitButton.addActionListener(e -> {
            String shopName = shopNameField.getText();
            String photo = photoField.getText();
            String shopDescription = shopDescriptionField.getText();
            String businessLicense = businessLicenseField.getText();
            String legalPerson = legalPersonField.getText();
            String verifyStatus = (String) verifyStatusComboBox.getSelectedItem();

            Shop newShop = new Shop();
            newShop.setShopName(shopName);
            newShop.setSellerId(seller.getSellerId());
            newShop.setPhoto(photo);
            newShop.setShopDescription(shopDescription);
            newShop.setBusinessLicense(businessLicense);
            newShop.setLegalPerson(legalPerson);
            newShop.setVerifyStatus(verifyStatus);
            shopService.insert(newShop);
            shops.add(newShop);
            model.addRow(new Object[]{shopName, businessLicense, legalPerson, verifyStatus});

            addShopDialog.dispose();

        });

        layout.setHorizontalGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addComponent(shopNameLabel)
                        .addComponent(photoLabel)
                        .addComponent(shopDescriptionLabel)
                        .addComponent(businessLicenseLabel)
                        .addComponent(legalPersonLabel)
                        .addComponent(verifyStatusLabel))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addComponent(shopNameField)
                        .addGroup(layout.createSequentialGroup()
                                .addComponent(photoField)
                                .addComponent(photoButton))
                        .addComponent(shopDescriptionField)
                        .addComponent(businessLicenseField)
                        .addComponent(legalPersonField)
                        .addComponent(verifyStatusComboBox)
                        .addComponent(submitButton))
        );

        layout.setVerticalGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(shopNameLabel)
                        .addComponent(shopNameField))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(photoLabel)
                        .addComponent(photoField)
                        .addComponent(photoButton))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(shopDescriptionLabel)
                        .addComponent(shopDescriptionField))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(businessLicenseLabel)
                        .addComponent(businessLicenseField))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(legalPersonLabel)
                        .addComponent(legalPersonField))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(verifyStatusLabel)
                        .addComponent(verifyStatusComboBox))
                .addComponent(submitButton)
        );

        addShopDialog.add(panel);
        addShopDialog.setVisible(true);
    }
}
