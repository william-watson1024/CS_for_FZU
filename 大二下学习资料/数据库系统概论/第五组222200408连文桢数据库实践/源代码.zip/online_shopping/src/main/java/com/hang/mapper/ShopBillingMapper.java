package com.hang.mapper;

import com.hang.entity.ShopBilling;
import org.apache.ibatis.annotations.*;

import java.time.LocalDateTime;
import java.util.List;

public interface ShopBillingMapper {
    @Select("select * from shop_billing")
    List<ShopBilling> selectAll();

    @Select("select * from shop_billing where shop_billing_id=#{id}")
    ShopBilling selectById(Integer id);

    @Select("select * from shop_billing where (change_time between #{begin} and #{end}) and shop_id=#{shopId}")
    List<ShopBilling> selectByShopIdAndTimeRange(@Param("begin") LocalDateTime begin, @Param("end") LocalDateTime end, @Param("shopId") Integer shopId);


    @Insert("insert into shop_billing(shop_billing_id, shop_id, change_balance, description, change_time) VALUES (null,#{shopId,},#{changeBalance},#{description},#{changeTime})")
    void insert(ShopBilling shopBilling);

    @Update("update shop_billing set change_balance=#{changeBalance},description=#{description},change_time=#{changeTime} where shop_billing_id=#{shopBillingId}")
    void updateById(ShopBilling shopBilling);

    @Delete("delete from shop_billing where shop_billing_id=#{id}")
    void deleteById(Integer id);
}
