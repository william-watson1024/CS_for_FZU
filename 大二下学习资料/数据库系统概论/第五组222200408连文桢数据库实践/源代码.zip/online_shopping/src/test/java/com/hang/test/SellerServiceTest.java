package com.hang.test;

import com.hang.service.SellerService;
import com.hang.service.impl.SellerServiceImpl;
import org.junit.Test;

public class SellerServiceTest {
    SellerService sellerService = new SellerServiceImpl();
    @Test
    public void testDeleteById(){
        sellerService.deleteById("delete");
    }
}
