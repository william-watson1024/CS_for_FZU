package com.hang.gui.userframe.tabbedpanels;

import com.hang.entity.Comment;
import com.hang.entity.Product;
import com.hang.entity.User;
import com.hang.service.CommentService;
import com.hang.service.UserService;
import com.hang.service.impl.CommentServiceImpl;
import com.hang.service.impl.UserServiceImpl;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableCellEditor;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class ViewProductComments {
    private static UserService userService = new UserServiceImpl();
    private static CommentService commentService = new CommentServiceImpl();
    static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static DefaultTableModel model;

    public static void createProductComment(Product product, User user) {
        SwingUtilities.invokeLater(() -> {
            ArrayList<Comment> comments;
            comments = (ArrayList<Comment>) commentService.selectByProductId(product.getProductId());

            JFrame frame = new JFrame("评论");

            // Create table model with some data
            model = new DefaultTableModel() {
                @Override
                public Class<?> getColumnClass(int columnIndex) {
                    return columnIndex == 0 ? JPanel.class : String.class;
                }

                @Override
                public boolean isCellEditable(int row, int column) {
                    return column == 0;
                }
            };

            model.addColumn("评论详情");
            for (Comment comment : comments) {
                model.addRow(new Object[]{createCommentPanel(
                        userService.selectById(comment.getUserId()).getNickname(),
                        String.valueOf(product.getProductId()),
                        comment.getContent(),
                        comment.getPostTime().format(formatter),
                        comment.getLikes(),
                        comment,
                        user,
                        product
                )});
            }

            // Create JTable with the model
            JTable table = new JTable(model);
            table.setRowHeight(350); // Adjust the row height to fit the panel and reply section

            // Set custom renderer and editor for the first column
            table.getColumnModel().getColumn(0).setCellRenderer(new PanelRenderer());
            table.getColumnModel().getColumn(0).setCellEditor(new PanelEditor());

            // Main panel with table
            JPanel mainPanel = new JPanel();
            mainPanel.setLayout(new BorderLayout());
            mainPanel.add(new JScrollPane(table), BorderLayout.CENTER);

            frame.add(mainPanel);
            frame.pack();
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }

    private static JPanel createCommentPanel(String nickname, String productId, String commentText, String commentTime, Integer likeCount, Comment comment, User user, Product product) {
        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        // Create components for each data
        JLabel userIdLabel = new JLabel("用户昵称: " + nickname);
        JLabel productIdLabel = new JLabel("产品ID: " + productId);
        JTextArea commentTextArea = new JTextArea(commentText);
        JLabel commentTimeLabel = new JLabel("评论时间: " + commentTime);
        JButton likeCountButton = new JButton("点赞: " + likeCount);
        JTextField replyTextField = new JTextField(20);
        JButton replyButton = new JButton("回复");

        likeCountButton.addActionListener(e -> {
            comment.setLikes(comment.getLikes() + 1);
            commentService.updateById(comment);
            likeCountButton.setText("点赞: " + comment.getLikes());
        });

        replyButton.addActionListener(e -> {
            String replyText = replyTextField.getText();
            if (!replyText.isEmpty()) {
                // Fetch the user object and validate it
                User users = userService.selectById(comment.getUserId());
                if (users != null) {
                    // Create a new comment object for the reply
                    Comment newComment = new Comment();
                    newComment.setUserId(user.getUserId());
                    newComment.setProductId(product.getProductId());
                    newComment.setContent(replyText);
                    newComment.setPostTime(LocalDateTime.now());
                    newComment.setLikes(0);
                    commentService.insert(newComment);
                    // Add new comment to the table
                    model.addRow(new Object[]{createCommentPanel(
                            user.getNickname(),
                            String.valueOf(product.getProductId()),
                            newComment.getContent(),
                            newComment.getPostTime().format(formatter),
                            newComment.getLikes(),
                            newComment,
                            user,
                            product
                    )});

                    replyTextField.setText(""); // Clear the reply text field
                } else {
                    JOptionPane.showMessageDialog(panel, "用户不存在");
                }
            } else {
                JOptionPane.showMessageDialog(panel, "回复内容不能为空");
            }
        });

        // Configure JTextArea
        commentTextArea.setWrapStyleWord(true);
        commentTextArea.setLineWrap(true);
        commentTextArea.setEditable(false);
        commentTextArea.setOpaque(false);

        // Layout components with GridBagConstraints
        // 用户昵称 - Left Top
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        gbc.insets = new Insets(5, 5, 5, 5);
        panel.add(userIdLabel, gbc);

        // 评论时间 - Right Top
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.NORTHEAST;
        panel.add(commentTimeLabel, gbc);

        // 评论内容 - Center
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        panel.add(new JScrollPane(commentTextArea), gbc);

        // 产品ID - Left Bottom
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        gbc.weightx = 0;
        gbc.weighty = 0;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.SOUTHWEST;
        panel.add(productIdLabel, gbc);

        // 点赞数 - Right Bottom
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.SOUTHEAST;
        panel.add(likeCountButton, gbc);

        // 回复文本框 - Below 评论内容
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;
        panel.add(replyTextField, gbc);

        // 回复按钮 - Next to 回复文本框
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.EAST;
        panel.add(replyButton, gbc);

        // 增加评论之间的距离
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        return panel;
    }

    // Custom renderer for JPanel in JTable cell
    static class PanelRenderer implements TableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            if (value instanceof JPanel) {
                return (JPanel) value;
            } else {
                return new JLabel(value.toString());
            }
        }
    }

    // Custom editor for JPanel in JTable cell
    static class PanelEditor extends AbstractCellEditor implements TableCellEditor {
        private JPanel panel;

        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            if (value instanceof JPanel) {
                panel = (JPanel) value;
                return panel;
            }
            return new JLabel(value.toString());
        }

        @Override
        public Object getCellEditorValue() {
            return panel;
        }
    }
}
