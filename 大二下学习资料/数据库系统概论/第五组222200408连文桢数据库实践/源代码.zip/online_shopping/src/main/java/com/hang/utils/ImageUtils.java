package com.hang.utils;

import lombok.extern.slf4j.Slf4j;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

@Slf4j
public class ImageUtils {
    public static ImageIcon scaleIcon(ImageIcon icon, int width, int height) {
        Image image = icon.getImage();
        Image scaledImage = image.getScaledInstance(width, height, Image.SCALE_SMOOTH);
        return new ImageIcon(scaledImage);
    }

    public static void setLabelIcon(JLabel label, String path){
        URL resource = ImageUtils.class.getClassLoader().getResource(path);
        if(resource == null){
            log.error(path+" not found!");
            return;
        }
        ImageIcon originalIcon  = new ImageIcon(resource);
        ImageIcon scaledIcon = ImageUtils.scaleIcon(originalIcon,label.getWidth(),label.getWidth());
        label.setIcon(scaledIcon);
    }

    public static void drawBackground(String backgroundPath, Graphics g, JPanel parent){
        URL resource = ImageUtils.class.getClassLoader().getResource(backgroundPath);
        if (resource == null) {
            log.error(backgroundPath + " not found!");
            return;
        }

        ImageIcon icon = new ImageIcon(resource);
        Image image = icon.getImage();
        g.drawImage(image, 0, 0, parent.getWidth(), parent.getHeight(), parent);
    }

    public static ImageIcon getProductImageIcon(int width, int height, String path){
        URL resource = ImageUtils.class.getClassLoader().getResource(path);


        if(path.contains(":")){
            path = path.replaceFirst("image/product/","");
            try {
                resource = new File(path).toURI().toURL();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
        }

        if(resource == null){
            log.error(path + " not found!");
            String defaultPath = "image/product/default.png";
            resource = ImageUtils.class.getClassLoader().getResource(defaultPath);
            if(resource == null){
                log.error(path + " not found!");
                return null;
            }
        }


        // 加载并调整图片大小
        ImageIcon originalIcon = new ImageIcon(resource);
        Image scaledImage = originalIcon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
        return new ImageIcon(scaledImage);
    }
}
