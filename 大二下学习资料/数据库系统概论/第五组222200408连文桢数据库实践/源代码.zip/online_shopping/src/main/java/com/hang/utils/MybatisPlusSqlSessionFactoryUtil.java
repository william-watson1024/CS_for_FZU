package com.hang.utils;

import com.baomidou.mybatisplus.core.MybatisSqlSessionFactoryBuilder;
import com.baomidou.mybatisplus.extension.plugins.MybatisPlusInterceptor;
import com.baomidou.mybatisplus.extension.plugins.inner.PaginationInnerInterceptor;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.Configuration;
import org.apache.ibatis.session.SqlSessionFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class MybatisPlusSqlSessionFactoryUtil {

    private static SqlSessionFactory mybatisPlusSqlSessionFactory;

    static {
        try {
            // 加载外部属性文件
            Properties properties = new Properties();
            try (InputStream propertiesStream = Resources.getResourceAsStream("config.properties")) {
                properties.load(propertiesStream);
            }

            // 读取MyBatis配置文件
            String resource = "mybatisplus-config.xml";
            InputStream inputStream = Resources.getResourceAsStream(resource);

            // 创建SqlSessionFactory
            mybatisPlusSqlSessionFactory = new MybatisSqlSessionFactoryBuilder().build(inputStream,properties);

            // 创建MyBatis-Plus拦截器
            MybatisPlusInterceptor interceptor = new MybatisPlusInterceptor();
            interceptor.addInnerInterceptor(new PaginationInnerInterceptor());
            Configuration configuration = mybatisPlusSqlSessionFactory.getConfiguration();
            configuration.addInterceptor(interceptor);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static SqlSessionFactory getMybatisPlusSqlSessionFactory() {
        return mybatisPlusSqlSessionFactory;
    }
}
