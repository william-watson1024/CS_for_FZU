package com.hang.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.hang.entity.User;
import com.hang.mapper.UserMapper;
import com.hang.mybatisplusmapper.UserMybatisPlusMapper;
import com.hang.service.UserService;
import com.hang.utils.MybatisPlusSqlSessionFactoryUtil;
import com.hang.utils.SqlSessionFactoryUtil;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.List;

public class UserServiceImpl implements UserService {
    private SqlSessionFactory sqlSessionFactory = SqlSessionFactoryUtil.getSqlSessionFactory();
    SqlSessionFactory mybatisPlusSqlSessionFactory = MybatisPlusSqlSessionFactoryUtil.getMybatisPlusSqlSessionFactory();

    @Override
    public List<User> selectAll() {

        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserMapper mapper = sqlSession.getMapper(UserMapper.class);
        List<User> users = mapper.selectAll();
        sqlSession.close();

        return users;
    }

    @Override
    public User selectById(String id) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserMapper mapper = sqlSession.getMapper(UserMapper.class);
        User user = mapper.selectById(id);
        sqlSession.close();

        return user;
    }

    @Override
    public void insert(User user) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserMapper mapper = sqlSession.getMapper(UserMapper.class);
        mapper.insert(user);
        sqlSession.commit();
        sqlSession.close();
    }

    @Override
    public void updateById(User user) {
        SqlSession sqlSession = mybatisPlusSqlSessionFactory.openSession();
        UserMybatisPlusMapper mapper = sqlSession.getMapper(UserMybatisPlusMapper.class);

        mapper.updateById(user);
        sqlSession.commit();
        sqlSession.close();
    }

    @Override
    public List<User> selectByConditions(String searchText, String status, String creditLevelOrBalance, String ordered) {
        SqlSession sqlSession = mybatisPlusSqlSessionFactory.openSession();
        UserMybatisPlusMapper mapper = sqlSession.getMapper(UserMybatisPlusMapper.class);
        LambdaQueryWrapper<User> lambdaQueryWrapper = new LambdaQueryWrapper<>();

        if (!"全部".equals(status)) {
            lambdaQueryWrapper.eq(User::getStatus, status);
        }


        if ("信用等级".equals(creditLevelOrBalance)) {
            if ("升序".equals(ordered)) {
                lambdaQueryWrapper.orderByAsc(User::getCreditLevel);
            } else if ("降序".equals(ordered)) {
                lambdaQueryWrapper.orderByDesc(User::getCreditLevel);
            }
        } else if ("余额".equals(creditLevelOrBalance)){
            if ("升序".equals(ordered)) {
                lambdaQueryWrapper.orderByAsc(User::getBalance);
            } else if ("降序".equals(ordered)) {
                lambdaQueryWrapper.orderByDesc(User::getBalance);
            }
        }

        lambdaQueryWrapper.and(wrapper -> wrapper.like(User::getNickname, searchText)
                .or().like(User::getUserId, searchText));

        List<User> userList = mapper.selectList(lambdaQueryWrapper);

        sqlSession.close();
        return userList;
    }

    @Override
    public void deleteById(String userId) {
        SqlSession sqlSession = mybatisPlusSqlSessionFactory.openSession();
        UserMybatisPlusMapper mapper = sqlSession.getMapper(UserMybatisPlusMapper.class);

        mapper.deleteById(userId);
        sqlSession.commit();
        sqlSession.close();
    }


}
