package com.hang.service.impl;

import com.hang.entity.Order;
import com.hang.entity.ShopBilling;
import com.hang.mapper.OrderMapper;
import com.hang.mapper.ShopBillingMapper;
import com.hang.service.ShopBillingService;
import com.hang.utils.SqlSessionFactoryUtil;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.time.LocalDateTime;
import java.util.List;

public class ShopBillingServiceImpl implements ShopBillingService {
    private SqlSessionFactory sqlSessionFactory = SqlSessionFactoryUtil.getSqlSessionFactory();

    @Override
    public List<ShopBilling> selectAll() {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ShopBillingMapper mapper = sqlSession.getMapper(ShopBillingMapper.class);

        List<ShopBilling> shopBillings = mapper.selectAll();

        sqlSession.close();

        return shopBillings;
    }

    @Override
    public ShopBilling selectById(Integer id) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ShopBillingMapper mapper = sqlSession.getMapper(ShopBillingMapper.class);

        ShopBilling shopBilling = mapper.selectById(id);

        sqlSession.close();

        return shopBilling;
    }

    @Override
    public List<ShopBilling> selectByShopIdAndTimeRange(LocalDateTime begin, LocalDateTime  end, Integer shopId) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ShopBillingMapper mapper = sqlSession.getMapper(ShopBillingMapper.class);

        List<ShopBilling> shopBillings = mapper.selectByShopIdAndTimeRange( begin,  end,  shopId);

        sqlSession.close();

        return shopBillings;
    }

    @Override
    public void insert(ShopBilling shopBilling) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ShopBillingMapper mapper = sqlSession.getMapper(ShopBillingMapper.class);

        mapper.insert(shopBilling);

        sqlSession.commit();
        sqlSession.close();

    }

    @Override
    public void updateById(ShopBilling shopBilling) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ShopBillingMapper mapper = sqlSession.getMapper(ShopBillingMapper.class);

        mapper.updateById(shopBilling);

        sqlSession.commit();
        sqlSession.close();

    }

    @Override
    public void deleteById(Integer id) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ShopBillingMapper mapper = sqlSession.getMapper(ShopBillingMapper.class);

        mapper.deleteById(id);

        sqlSession.commit();
        sqlSession.close();
    }
}
