package com.hang.test;

import com.hang.entity.AddressBook;
import com.hang.service.AddressBookService;
import com.hang.service.impl.AddressBookServiceImpl;
import org.junit.Test;

public class AddressBookTest {
    AddressBookService addressBookService = new AddressBookServiceImpl();
    @Test
    public void testSelectDefaultByUserId(){
        AddressBook addressBook = addressBookService.selectDefaultByUserId("user");
        System.out.println(addressBook);
    }
}
