package com.hang.gui.userframe.tabbedpanels;

import com.hang.entity.*;
import com.hang.gui.userframe.UserFrame;
import com.hang.service.*;
import com.hang.service.impl.*;

import javax.swing.*;
import java.awt.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class OrderConfirmationFrame extends JFrame {
    private UserBillingService userBillingService = new UserBillingServiceImpl();
    private UserService userService = new UserServiceImpl();

    private SaleVolumnService saleVolumnService = new SaleVolumnServiceImpl();
    private ProductService productService = new ProductServiceImpl();
    private OrderService orderService = new OrderServiceImpl();
    private ShoppingCartItemService shoppingCartItemService = new ShoppingCartItemServiceImpl();
    private static final BigDecimal SHIPPING_COST = new BigDecimal("10.00"); // example shipping cost
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public OrderConfirmationFrame(User user, List<ShoppingCartItem> items, AddressBook address, BigDecimal totalAmount, UserFrame userFrame) {
        setTitle("订单确认");
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        setLayout(new BorderLayout());

        JPanel orderDetailsPanel = new JPanel();
        orderDetailsPanel.setLayout(new BoxLayout(orderDetailsPanel, BoxLayout.Y_AXIS));
        orderDetailsPanel.setBorder(BorderFactory.createTitledBorder("订单详情"));

        for (ShoppingCartItem item : items) {
            JPanel itemPanel = new JPanel(new GridLayout(0, 2));
            itemPanel.add(new JLabel("商品名称:"));
            itemPanel.add(new JLabel(productService.selectById(item.getProductId()).getName()));
            itemPanel.add(new JLabel("商品数量:"));
            itemPanel.add(new JLabel(String.valueOf(item.getNumber())));
            itemPanel.add(new JLabel("价格:"));
            ProductService productService = new ProductServiceImpl();
            Product product = productService.selectById(item.getProductId());
            BigDecimal productTotalPrice = product.getPrice().multiply(new BigDecimal(item.getNumber()));
            itemPanel.add(new JLabel(productTotalPrice.toString() + " 元"));
            orderDetailsPanel.add(itemPanel);
        }

        JPanel addressPanel = new JPanel(new GridLayout(0, 1));
        addressPanel.setBorder(BorderFactory.createTitledBorder("收货地址"));

        addressPanel.add(new JLabel("收货人: " + address.getConsignee()));
        addressPanel.add(new JLabel("电话: " + address.getPhoneNumber()));
        addressPanel.add(new JLabel("地址: " + address.getDetail()));

        orderDetailsPanel.add(addressPanel);

        JPanel shippingPanel = new JPanel(new GridLayout(0, 2));
        shippingPanel.add(new JLabel("运费:"));
        shippingPanel.add(new JLabel(SHIPPING_COST.toString() + " 元"));
        orderDetailsPanel.add(shippingPanel);

        JPanel deliveryPanel = new JPanel(new GridLayout(0, 2));
        deliveryPanel.add(new JLabel("预计送达时间:"));
        deliveryPanel.add(new JLabel(LocalDateTime.now().plusDays(3).format(formatter))); // example estimated delivery time
        orderDetailsPanel.add(deliveryPanel);

        add(orderDetailsPanel, BorderLayout.CENTER);

        JPanel summaryPanel = new JPanel(new GridLayout(1, 2));
        summaryPanel.add(new JLabel("订单总金额:"));
        BigDecimal finalAmount = totalAmount.add(SHIPPING_COST);
        summaryPanel.add(new JLabel(finalAmount.toString() + " 元"));

        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new BorderLayout());
        bottomPanel.add(summaryPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(1, 2));
        JButton submitOrderButton = new JButton("提交订单");
        JButton cancelButton = new JButton("取消");

        // Set preferred size to make buttons smaller
        Dimension buttonSize = new Dimension(100, 30);
        submitOrderButton.setPreferredSize(buttonSize);
        cancelButton.setPreferredSize(buttonSize);

        buttonPanel.add(submitOrderButton);
        buttonPanel.add(cancelButton);

        bottomPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(bottomPanel, BorderLayout.SOUTH);

        submitOrderButton.addActionListener(e -> {
            if (finalAmount.compareTo(user.getBalance()) > 0) {
                JOptionPane.showMessageDialog(this, "余额不足，请先充值后再进行订单支付");
            } else {
                UserBilling userBilling = new UserBilling();
                userBilling.setChangeTime(LocalDateTime.now());
                userBilling.setUserId(user.getUserId());
                userBilling.setDescription("新帐单");
                userBilling.setChangeBalance(finalAmount);
                userBillingService.insert(userBilling);


                for (ShoppingCartItem item : items) {
                    Order order = new Order();
                    order.setOrderCreateDatetime(item.getAddDatetime());
                    order.setPaymentDatetime(LocalDateTime.now());
                    order.setRemark("新订单,支付");
                    order.setProductId(item.getProductId());
                    order.setProductNumber(item.getNumber());
                    order.setUserId(user.getUserId());
                    order.setAddressBookId(address.getAddressBookId());
                    order.setTotalAmount(finalAmount);
                    order.setDeliveryStatus("未发货");
                    order.setPaymentStatus("已支付");
                    orderService.insert(order);
                    SaleVolumn saleVolumn = new SaleVolumn();
                    saleVolumn.setCount(item.getNumber());
                    saleVolumn.setSaleDate(LocalDate.now());
                    saleVolumn.setProductId(item.getProductId());
                    saleVolumnService.insert(saleVolumn);
                }
                for (ShoppingCartItem item : items) {
                    // Remove item from shopping cart after order is confirmed
                    shoppingCartItemService.deleteById(item.getShoppingCartItemId());
                }
                user.setBalance(user.getBalance().subtract(finalAmount));
                userService.updateById(user);
                //if(userAndShopService.balanceFromUserToShop(finalAmount,user.getUserId(),))
                JOptionPane.showMessageDialog(this, "订单已支付，谢谢惠顾");

                // 关闭当前窗口
                dispose();

                // 刷新主界面
                //userFrame.getTabbedPane().setSelectedIndex(2); // 切换到购物车选项卡
            }
        });

        cancelButton.addActionListener(e -> {
            // 关闭当前窗口
            dispose();
        });

        setVisible(true);
    }
}
