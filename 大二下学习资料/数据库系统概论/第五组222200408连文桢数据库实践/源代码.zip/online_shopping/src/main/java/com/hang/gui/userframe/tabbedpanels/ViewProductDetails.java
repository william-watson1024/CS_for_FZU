package com.hang.gui.userframe.tabbedpanels;

import com.hang.entity.Product;
import com.hang.service.ProductService;
import com.hang.service.impl.ProductServiceImpl;
import com.hang.utils.ImageUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.Objects;

public class ViewProductDetails {

    private static JTable table = new JTable();
    private static ProductService productService = new ProductServiceImpl();

    public static void createProductDetails(Product product) {
        SwingUtilities.invokeLater(() -> {

            JFrame frame = new JFrame("详情");

            // Create table model with product data
            DefaultTableModel model = new DefaultTableModel() {
                @Override
                public Class<?> getColumnClass(int columnIndex) {
                    return columnIndex == 0 ? JPanel.class : String.class;
                }
            };

            model.addColumn("详情");

            model.addRow(new Object[]{createProductPanel(
                    product.getName(),
                    product.getBrand(),
                    product.getPhoto(),
                    product.getDescription(),
                    product.getPrice().toString(),
                    product.getType(),
                    String.valueOf(product.getStock()),
                    String.valueOf(product.getWeight()),
                    product.getSize(),
                    product.getStatus()
            )});

            JTable table = new JTable(model);
            table.setRowHeight(600);

            table.getColumnModel().getColumn(0).setCellRenderer(new PanelRenderer());

            frame.add(new JScrollPane(table));
            frame.pack();
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }

    private static JPanel createProductPanel(String productName, String productBrand, String productPhoto, String productDescription,
                                             String productPrice, String productType, String productSales, String productWeight,
                                             String productSize, String productStatus) {
        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        JLabel productNameLabel = new JLabel("名称: " + productName);
        JLabel productBrandLabel = new JLabel("品牌: " + productBrand);
        JLabel productPriceLabel = new JLabel("价格: " + productPrice);
        JLabel productTypeLabel = new JLabel("类型: " + productType);
        JLabel productSalesLabel = new JLabel("销量: " + productSales);
        JLabel productWeightLabel = new JLabel("重量: " + productWeight);
        JLabel productSizeLabel = new JLabel("尺寸: " + productSize);
        JLabel productStatusLabel = new JLabel("状态: " + productStatus);

        String path = "image/product/" + productPhoto;
        ImageIcon icon = ImageUtils.getProductImageIcon(150, 150, path);

        JLabel productPhotoLabel = new JLabel(icon);

        JTextArea productDescriptionArea = new JTextArea(productDescription);

        productDescriptionArea.setWrapStyleWord(true);
        productDescriptionArea.setLineWrap(true);
        productDescriptionArea.setEditable(false);
        productDescriptionArea.setOpaque(false);

        // 产品名称 - Left Top
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        gbc.insets = new Insets(5, 5, 5, 5);
        panel.add(productNameLabel, gbc);

        // 品牌 - Right Top
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.NORTHEAST;
        panel.add(productBrandLabel, gbc);

        // 商品照片 - Center Top
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(productPhotoLabel, gbc);

        // 产品描述 - Center
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        panel.add(new JScrollPane(productDescriptionArea), gbc);

        // 价格 - Left Bottom
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 1;
        gbc.weightx = 0;
        gbc.weighty = 0;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.SOUTHWEST;
        panel.add(productPriceLabel, gbc);

        // 类型 - Right Bottom
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.SOUTHEAST;
        panel.add(productTypeLabel, gbc);

        // 销量 - Left Bottom
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 1;
        gbc.weightx = 0;
        gbc.weighty = 0;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.SOUTHWEST;
        panel.add(productSalesLabel, gbc);

        // 重量 - Right Bottom
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.SOUTHEAST;
        panel.add(productWeightLabel, gbc);

        // 尺寸 - Left Bottom
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 1;
        gbc.weightx = 0;
        gbc.weighty = 0;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.SOUTHWEST;
        panel.add(productSizeLabel, gbc);

        // 状态 - Right Bottom
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.SOUTHEAST;
        panel.add(productStatusLabel, gbc);

        return panel;
    }

    static class PanelRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            if (value instanceof JPanel) {
                return (JPanel) value;
            } else {
                return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            }
        }
    }
}
