package com.hang.gui.sellerframe.tabbedpanels;

import com.hang.entity.Seller;
import com.hang.utils.ImageUtils;

import javax.swing.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class WelcomeSeller extends JPanel {


    public WelcomeSeller(Seller seller) {


        setLayout(new GridBagLayout());

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(30, 30, 30, 30);

        // 创建 SimpleDateFormat 对象并指定日期格式
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy年M月d日");

        // 获取当前日期
        Date today = new Date();

        // 格式化日期并输出
        String formattedDate = dateFormat.format(today);

        c.gridx = 0;
        c.gridy = 0;
        JLabel welcomeLabel = new JLabel("商家 " + seller.getSellerId() + "，欢迎来到商家系统");
        welcomeLabel.setFont(new Font("黑体", Font.BOLD, 40));
        add(welcomeLabel, c);

        c.gridx = 0;
        c.gridy = 1;
        JLabel dateLabel = new JLabel("今天是" + formattedDate, JLabel.CENTER);
        dateLabel.setFont(new Font("微软雅黑", Font.BOLD, 30));
        add(dateLabel, c);


    }
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        String backgroundPath = "image/background/seller_welcome.jpg";
        ImageUtils.drawBackground(backgroundPath,g,this);
    }


}