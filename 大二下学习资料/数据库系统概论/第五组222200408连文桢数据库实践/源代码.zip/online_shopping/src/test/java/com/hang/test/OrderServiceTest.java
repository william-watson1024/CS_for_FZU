package com.hang.test;

import com.hang.entity.Order;
import com.hang.service.OrderService;
import com.hang.service.impl.OrderServiceImpl;
import org.junit.Test;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;

public class OrderServiceTest {
    private OrderService orderService = new OrderServiceImpl();

    @Test
    public void test(){
        LocalDateTime begin = LocalDateTime.of(2020,1,1,0,0);
        LocalDateTime end = LocalDateTime.now();
        List<Order> orders = orderService.selectBetweenDatetime(begin, end);
        for (Order order : orders) {
            System.out.println(order);
        }
    }

    @Test
    public void testSelectByUserId(){
        List<Order> orders = orderService.selectByUserId("user");
        for (Order order : orders) {
            System.out.println(order);
        }
    }

    @Test
    public void testInsert(){
        Order order = orderService.selectById(1000);
        order.setOrderCreateDatetime(null);
        orderService.insert(order);
    }


    @Test
    public void testSelectByShopId(){
        List<Order> orders = orderService.selectByShopId(1);
        for (Order order : orders) {
            System.out.println(order);
        }
    }
}
