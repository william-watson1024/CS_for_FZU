package com.hang.mybatisplusmapper;

import com.hang.entity.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 用户表 Mapper 接口
 * </p>
 *
 * @author hang
 * @since 2024-05-25
 */
public interface UserMybatisPlusMapper extends BaseMapper<User> {

}
