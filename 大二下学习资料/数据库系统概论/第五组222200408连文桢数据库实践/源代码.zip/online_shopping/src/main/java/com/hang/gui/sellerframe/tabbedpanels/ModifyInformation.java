package com.hang.gui.sellerframe.tabbedpanels;

import com.hang.entity.Seller;
import com.hang.gui.sellerframe.tabbedpanels.frames.*;
import com.hang.gui.sellerframe.SellerFrame;
import com.hang.service.SellerService;
import com.hang.service.impl.SellerServiceImpl;
import com.hang.utils.ImageUtils;

import javax.swing.*;
import java.awt.*;
public class ModifyInformation extends JPanel{
    private SellerService sellerService = new SellerServiceImpl();
    private Seller seller;

    JLabel sellerIdWordLabel = new JLabel("账号: ");
    JLabel sellerIdLabel = new JLabel();

    JLabel nameLabel = new JLabel("姓名: ");
    JTextField nameField = new JTextField(12);

    JLabel phoneLabel = new JLabel("手机号: ");
    JTextField phoneField = new JTextField(12);

    JLabel emailLabel = new JLabel("邮箱: ");
    JTextField emailField = new JTextField(12);

    JButton confirmButton = new JButton("确认修改");
    JPanel confirmButtonPanel = new JPanel();

    JButton changePasswordButton = new JButton("修改密码");
    JPanel changePasswordButtonPanel = new JPanel();

    JButton deleteAccountButton = new JButton("注销账号");
    JPanel deleteButtonPanel = new JPanel();

    public ModifyInformation(Seller seller, SellerFrame sellerFrame) {
        this.seller = seller;

        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5, 5, 5, 5);


        // 第1行：账号
        c.gridy = 0;

        c.gridx = 0;
        add(sellerIdWordLabel, c);

        c.gridx = 1;
        sellerIdLabel.setText(seller.getSellerId());
        add(sellerIdLabel, c);


        // 第2行：姓名
        c.gridy = 1;

        c.gridx = 0;
        add(nameLabel, c);

        c.gridx = 1;
        nameField.setText(seller.getName());
        add(nameField, c);


        // 第3行：手机号
        c.gridy = 2;

        c.gridx = 0;
        add(phoneLabel, c);

        c.gridx = 1;
        phoneField.setText(seller.getPhoneNumber());
        add(phoneField, c);


        // 第4行：邮箱
        c.gridy = 3;

        c.gridx = 0;
        add(emailLabel, c);

        c.gridx = 1;
        emailField.setText(seller.getEmail());
        add(emailField, c);


        // 第5行：确认修改按钮panel
        c.gridy = 4;
        confirmButtonPanel.add(confirmButton);
        confirmButtonPanel.setOpaque(false);

        c.gridx = 0;
        c.gridwidth = 2;
        add(confirmButtonPanel, c);

        confirmButton.addActionListener(e -> {
            seller.setName(nameField.getText());
            seller.setPhoneNumber(phoneField.getText());
            seller.setEmail(emailField.getText());
            System.out.println(seller.getName());
            sellerService.updateById(seller);
            JOptionPane.showMessageDialog(this, "修改成功");
        });

        // 第6行：修改密码按钮panel
        c.gridy = 5;
        changePasswordButtonPanel.add(changePasswordButton);
        changePasswordButtonPanel.setOpaque(false);

        changePasswordButton.addActionListener(e->{
            SwingUtilities.invokeLater(()->{
                new ChangeSellerPasswordFrame(seller);
            });
        });

        c.gridx = 0;
        c.gridwidth = 2;
        add(changePasswordButtonPanel, c);

        // 第7行：注销账号按钮panel
        c.gridy = 7;

        deleteButtonPanel.add(deleteAccountButton);
        deleteButtonPanel.setOpaque(false);

        c.gridx = 0;
        c.gridwidth = 2;
        add(deleteButtonPanel, c);

        deleteAccountButton.addActionListener(e -> {
            SwingUtilities.invokeLater(() -> {
                new DeleteSellerAccountFrame(seller,sellerFrame);
            });
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        String backgroundPath = "image/background/change_information.jpg";
        ImageUtils.drawBackground(backgroundPath,g,this);
    }
}
