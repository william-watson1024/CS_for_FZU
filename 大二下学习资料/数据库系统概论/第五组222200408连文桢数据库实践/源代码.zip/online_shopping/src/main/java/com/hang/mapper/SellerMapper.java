package com.hang.mapper;


import com.hang.entity.Seller;
import org.apache.ibatis.annotations.*;

import java.util.List;

public interface SellerMapper {
    @Select("select * from seller")
    List<Seller> selectAll();

    @Select("select * from seller where seller_id=#{id}")
    Seller selectById(String id);

    @Select("select * from seller where status=#{status}")
    List<Seller> selectByStatus(String status);

    List<Seller> selectByStatusAndOrdered(@Param("status") String status, @Param("ordered") String ordered);

    @Insert("insert into seller(seller_id, password, name, phone_number, register_date, id_number)VALUES (#{sellerId},#{password},#{name},#{phoneNumber},#{registerDate},#{idNumber}) ")
    void insert(Seller newSeller);

    @Update("update seller set password=#{password}, name=#{name}, avatar=#{avatar}, email=#{email}, phone_number=#{phoneNumber}, id_number=#{idNumber},status=#{status},credit_level=#{creditLevel} where seller_id=#{sellerId}")
    void updateById(Seller seller);

    @Delete("delete from seller where seller_id=#{sellerId}")
    void deleteById(String sellerId);
}
