package com.hang.service.impl;

import com.hang.entity.AfterSale;
import com.hang.mapper.AfterSaleMapper;
import com.hang.service.AfterSaleService;
import com.hang.utils.SqlSessionFactoryUtil;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.List;

public class AfterSaleServiceImpl implements AfterSaleService {
    private SqlSessionFactory sqlSessionFactory = SqlSessionFactoryUtil.getSqlSessionFactory();

    @Override
    public List<AfterSale> selectAll() {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        AfterSaleMapper mapper = sqlSession.getMapper(AfterSaleMapper.class);
        List<AfterSale> afterSales = mapper.selectAll();

        sqlSession.close();

        return afterSales;
    }

    @Override
    public AfterSale selectById(Integer id) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        AfterSaleMapper mapper = sqlSession.getMapper(AfterSaleMapper.class);

        AfterSale afterSale = mapper.selectById(id);

        sqlSession.close();

        return afterSale;
    }

    @Override
    public List<AfterSale> selectByShopId(Integer shopId) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        AfterSaleMapper mapper = sqlSession.getMapper(AfterSaleMapper.class);
        List<AfterSale> afterSales = mapper.selectByShopId(shopId);

        sqlSession.close();

        return afterSales;
    }

    @Override
    public void insert(AfterSale afterSale) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        AfterSaleMapper mapper = sqlSession.getMapper(AfterSaleMapper.class);

        mapper.insert(afterSale);
        sqlSession.commit();

        sqlSession.close();
    }

    @Override
    public void updateById(AfterSale afterSale) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        AfterSaleMapper mapper = sqlSession.getMapper(AfterSaleMapper.class);

        mapper.updateById(afterSale);
        sqlSession.commit();

        sqlSession.close();
    }

    @Override
    public void deleteById(Integer id) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        AfterSaleMapper mapper = sqlSession.getMapper(AfterSaleMapper.class);

        mapper.deleteById(id);
        sqlSession.commit();

        sqlSession.close();
    }
}
