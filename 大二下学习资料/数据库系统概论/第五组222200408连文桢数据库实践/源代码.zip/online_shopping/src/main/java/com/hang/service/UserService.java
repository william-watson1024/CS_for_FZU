package com.hang.service;


import com.hang.entity.User;

import java.util.List;

public interface UserService {
    List<User> selectAll();
    User selectById(String id);
    void insert(User user);
    void updateById(User user);
    List<User> selectByConditions(String searchText, String status, String creditLevelOrBalance,String ordered);

    void deleteById(String userId);
}
