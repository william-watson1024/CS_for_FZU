package com.hang.gui.userframe.tabbedpanels;

import com.hang.entity.Comment;
import com.hang.entity.Order;
import com.hang.entity.User;
import com.hang.service.CommentService;
import com.hang.service.impl.CommentServiceImpl;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDateTime;

public class CommentFrame extends JDialog {

    public CommentFrame(JFrame owner, User user, Order order) {
        super(owner, "评论", true);
        setSize(600, 600);
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout());

        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);

        // 评论者
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(new JLabel("评论者:"), gbc);

        gbc.gridx = 1;
        JLabel userIdLabel = new JLabel(user.getNickname());
        userIdLabel.setPreferredSize(new Dimension(300, 25));
        formPanel.add(userIdLabel, gbc);

        // 商品
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(new JLabel("商品:"), gbc);

        gbc.gridx = 1;
        JLabel productIdLabel = new JLabel(String.valueOf(order.getProductId()));
        productIdLabel.setPreferredSize(new Dimension(300, 25));
        formPanel.add(productIdLabel, gbc);

        // 星级评分
        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(new JLabel("商品评分:"), gbc);

        gbc.gridx = 1;
        JPanel starPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        ButtonGroup starGroup = new ButtonGroup();
        for (int i = 1; i <= 5; i++) {
            JRadioButton starButton = new JRadioButton(String.valueOf(i));
            starGroup.add(starButton);
            starPanel.add(starButton);
        }
        formPanel.add(starPanel, gbc);

        // 评论内容
        gbc.gridx = 0;
        gbc.gridy = 3;
        formPanel.add(new JLabel("评论内容:"), gbc);

        gbc.gridx = 1;
        JTextArea contentTextArea = new JTextArea(7, 30); // Adjusted size
        JScrollPane contentScrollPane = new JScrollPane(contentTextArea);
        contentScrollPane.setPreferredSize(new Dimension(300, 140)); // Adjusted size
        formPanel.add(contentScrollPane, gbc);

        // 卖家服务态度评分
        gbc.gridx = 0;
        gbc.gridy = 4;
        formPanel.add(new JLabel("服务态度评分:"), gbc);

        gbc.gridx = 1;
        JPanel servicePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        ButtonGroup serviceGroup = new ButtonGroup();
        for (int i = 1; i <= 5; i++) {
            JRadioButton serviceButton = new JRadioButton(String.valueOf(i));
            serviceGroup.add(serviceButton);
            servicePanel.add(serviceButton);
        }
        formPanel.add(servicePanel, gbc);

        // 物流速度评分
        gbc.gridx = 0;
        gbc.gridy = 5;
        formPanel.add(new JLabel("物流速度评分:"), gbc);

        gbc.gridx = 1;
        JPanel logisticsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        ButtonGroup logisticsGroup = new ButtonGroup();
        for (int i = 1; i <= 5; i++) {
            JRadioButton logisticsButton = new JRadioButton(String.valueOf(i));
            logisticsGroup.add(logisticsButton);
            logisticsPanel.add(logisticsButton);
        }
        formPanel.add(logisticsPanel, gbc);

        JScrollPane formScrollPane = new JScrollPane(formPanel);
        add(formScrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton submitButton = new JButton("提交");
        submitButton.setPreferredSize(new Dimension(80, 25)); // Smaller size
        submitButton.addActionListener(e -> {
            CommentService commentService = new CommentServiceImpl();
            Comment comment = new Comment();
            comment.setLikes(0);
            comment.setContent(contentTextArea.getText());
            comment.setUserId(user.getUserId());
            comment.setProductId(order.getProductId());
            comment.setPostTime(LocalDateTime.now());
            commentService.insert(comment);
            JOptionPane.showMessageDialog(this, "评论提交成功！");
            dispose();
        });
        buttonPanel.add(submitButton);

        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }
}
