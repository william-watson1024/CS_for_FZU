package com.hang.gui.userframe.tabbedpanels;

import com.hang.entity.Order;
import com.hang.entity.User;
import com.hang.gui.userframe.UserFrame;
import com.hang.service.AddressBookService;
import com.hang.service.OrderService;
import com.hang.service.ProductService;
import com.hang.service.impl.AddressBookServiceImpl;
import com.hang.service.impl.OrderServiceImpl;
import com.hang.service.impl.ProductServiceImpl;
import com.hang.utils.TableUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class OrderManagePanel extends JPanel {

    ArrayList<Order> Orders = new ArrayList<>();
    private OrderService orderService = new OrderServiceImpl();
    private ProductService productService = new ProductServiceImpl();
    private AddressBookService addressBookService = new AddressBookServiceImpl();
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private JTable table;
    private DefaultTableModel model;
    private User user;
    private UserFrame userFrame;

    public OrderManagePanel(User user, UserFrame userFrame) {
        this.user = user;
        this.userFrame = userFrame;
        setLayout(new BorderLayout());
        Orders = (ArrayList<Order>) orderService.selectByUserId(user.getUserId());
        model = new DefaultTableModel();
        model.addColumn("订单号");
        model.addColumn("商品");
        model.addColumn("商品数量");
        model.addColumn("订单创建时间");
        model.addColumn("总价");
        for (Order order : Orders) {
            model.addRow(new Object[]{
                    order.getOrderId(),
                    productService.selectById(order.getProductId()).getName(),
                    order.getProductNumber(),
                    order.getOrderCreateDatetime().format(formatter),
                    order.getTotalAmount()
            });
        }
        table = new JTable(model);
        TableUtils.setTableStyle(table);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        JButton enterOrderButton = new JButton("查看详情");
        JButton requestAfterSalesButton = new JButton("申请售后");
        JButton commentButton = new JButton("评论");
        JButton refreshButton = new JButton("刷新");
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(enterOrderButton);
        buttonPanel.add(requestAfterSalesButton);
        buttonPanel.add(commentButton);
        buttonPanel.add(refreshButton);
        add(buttonPanel, BorderLayout.SOUTH);

        enterOrderButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                Order selectedOrder = Orders.get(selectedRow);
                JDialog dialog = new JDialog(userFrame, "订单详情", true);
                dialog.setSize(500, 600);
                dialog.setLocationRelativeTo(this);
                dialog.setLayout(new GridLayout(0, 2));

                // 添加订单详细信息到对话框
                dialog.add(new JLabel("订单号:"));
                dialog.add(new JLabel(String.valueOf(selectedOrder.getOrderId())));
                dialog.add(new JLabel("商品:"));
                dialog.add(new JLabel(String.valueOf(productService.selectById(selectedOrder.getProductId()).getName())));
                dialog.add(new JLabel("收货地址:"));
                dialog.add(new JLabel(String.valueOf(addressBookService.selectDefaultByUserId(selectedOrder.getUserId()).getDetail())));
                dialog.add(new JLabel("商品数量:"));
                dialog.add(new JLabel(String.valueOf(selectedOrder.getProductNumber())));
                dialog.add(new JLabel("订单创建时间:"));
                dialog.add(new JLabel(String.valueOf(selectedOrder.getOrderCreateDatetime().format(formatter))));
                dialog.add(new JLabel("支付完成时间:"));
                dialog.add(new JLabel(String.valueOf(selectedOrder.getPaymentDatetime().format(formatter))));
                dialog.add(new JLabel("总价:"));
                dialog.add(new JLabel(String.valueOf(selectedOrder.getTotalAmount())));
                dialog.add(new JLabel("支付状态:"));
                dialog.add(new JLabel(selectedOrder.getPaymentStatus()));
                dialog.add(new JLabel("配送状态:"));
                dialog.add(new JLabel(selectedOrder.getDeliveryStatus()));
                dialog.add(new JLabel("备注:"));
                dialog.add(new JLabel(selectedOrder.getRemark()));

                dialog.setVisible(true);
            } else {
                JOptionPane.showMessageDialog(null, "未选择任何订单！");
            }
        });

        requestAfterSalesButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                Order selectedOrder = Orders.get(selectedRow);
                new AfterSalesRequestFrame(userFrame, selectedOrder);
            } else {
                JOptionPane.showMessageDialog(null, "未选择任何订单！");
            }
        });

        commentButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                Order selectedOrder = Orders.get(selectedRow);
                new CommentFrame(userFrame, user, selectedOrder);
            } else {
                JOptionPane.showMessageDialog(null, "未选择任何订单！");
            }
        });

        refreshButton.addActionListener(e -> refresh(user));
    }

    public void refresh(User user) {
        model.setRowCount(0); // Clear the existing rows
        Orders = (ArrayList<Order>) orderService.selectByUserId(user.getUserId());
        for (Order order : Orders) {
            model.addRow(new Object[]{
                    order.getOrderId(),
                    productService.selectById(order.getProductId()).getName(),
                    order.getProductNumber(),
                    order.getOrderCreateDatetime().format(formatter),
                    order.getTotalAmount()
            });
        }
    }
}
