package com.hang.gui.userframe.tabbedpanels;

import com.hang.entity.AddressBook;
import com.hang.entity.Product;
import com.hang.entity.ShoppingCartItem;
import com.hang.entity.User;
import com.hang.gui.userframe.UserFrame;
import com.hang.service.AddressBookService;
import com.hang.service.ProductService;
import com.hang.service.ShoppingCartItemService;
import com.hang.service.UserService;
import com.hang.service.impl.AddressBookServiceImpl;
import com.hang.service.impl.ProductServiceImpl;
import com.hang.service.impl.ShoppingCartItemServiceImpl;
import com.hang.service.impl.UserServiceImpl;
import com.hang.utils.TableUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class ShoppingCartPanel extends JPanel {
    ArrayList<ShoppingCartItem> ShoppingCartItems;
    private ShoppingCartItemService shoppingCartItemService = new ShoppingCartItemServiceImpl();
    private ProductService productService = new ProductServiceImpl();
    private UserService userService = new UserServiceImpl();
    private AddressBookService addressBookService = new AddressBookServiceImpl();
    BigDecimal totalAmount = new BigDecimal(0.0);
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private JTable table;
    private DefaultTableModel model;
    private User user;
    private UserFrame userFrame;

    public ShoppingCartPanel(User user, UserFrame userFrame) {
        this.user = user;
        this.userFrame = userFrame;
        setLayout(new BorderLayout());
        model = new DefaultTableModel();
        model.addColumn("用户名");
        model.addColumn("产品名称");
        model.addColumn("产品数量");
        model.addColumn("添加时间");
        ShoppingCartItems = (ArrayList<ShoppingCartItem>) shoppingCartItemService.selectByUserId(user.getUserId());
        for (ShoppingCartItem shoppingCartItem : ShoppingCartItems) {
            model.addRow(new Object[]{
                    userService.selectById(shoppingCartItem.getUserId()).getNickname(),
                    productService.selectById(shoppingCartItem.getProductId()).getName(),
                    shoppingCartItem.getNumber(),
                    shoppingCartItem.getAddDatetime().format(formatter),
            });
        }
        table = new JTable(model);
        table.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        TableUtils.setTableStyle(table);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        JButton enterOrderButton = new JButton("查看详情");
        JButton updateQuantityButton = new JButton("修改商品数量");
        JButton checkoutButton = new JButton("结算");
        JButton deleteOrderButton = new JButton("删除商品");
        JButton refreshButton = new JButton("刷新");
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(enterOrderButton);
        buttonPanel.add(updateQuantityButton);
        buttonPanel.add(checkoutButton);
        buttonPanel.add(deleteOrderButton);
        buttonPanel.add(refreshButton);
        add(buttonPanel, BorderLayout.SOUTH);

        enterOrderButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                ShoppingCartItem selectedOrder = ShoppingCartItems.get(selectedRow);
                JDialog dialog = new JDialog(userFrame, "购物车详情", true);
                dialog.setSize(500, 600);
                dialog.setLocationRelativeTo(this);
                dialog.setLayout(new GridLayout(0, 2));

                // 添加订单详细信息到对话框
                dialog.add(new JLabel("用户名:"));
                dialog.add(new JLabel(userService.selectById(selectedOrder.getUserId()).getNickname()));
                dialog.add(new JLabel("商品:"));
                dialog.add(new JLabel(productService.selectById(selectedOrder.getProductId()).getName()));
                dialog.add(new JLabel("收货地址:"));
                dialog.add(new JLabel(addressBookService.selectDefaultByUserId(selectedOrder.getUserId()).getDetail()));
                dialog.add(new JLabel("商品数量:"));
                dialog.add(new JLabel(String.valueOf(selectedOrder.getNumber())));
                dialog.add(new JLabel("购物车添加时间:"));
                dialog.add(new JLabel(String.valueOf(selectedOrder.getAddDatetime().format(formatter))));
                dialog.add(new JLabel("备注:"));
                dialog.add(new JLabel(selectedOrder.getRemark()));

                dialog.setVisible(true);
            } else {
                JOptionPane.showMessageDialog(null, "未选择任何商品！");
            }
        });

        updateQuantityButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                ShoppingCartItem selectedCartItem = ShoppingCartItems.get(selectedRow);
                ShoppingCartItem shopCartItem = new ShoppingCartItem();
                // 弹出对话框获取新的商品数量
                String newQuantityStr = JOptionPane.showInputDialog(this, "输入新的商品数量:", selectedCartItem.getNumber());
                try {
                    int newQuantity = Integer.parseInt(newQuantityStr);
                    if (newQuantity <= 0) {
                        JOptionPane.showMessageDialog(this, "商品数量必须为正整数！");
                    } else {
                        shopCartItem.setRemark(selectedCartItem.getRemark());
                        shopCartItem.setUserId(selectedCartItem.getUserId());
                        shopCartItem.setProductId(selectedCartItem.getProductId());
                        shopCartItem.setAddDatetime(selectedCartItem.getAddDatetime());
                        shopCartItem.setAddressBookId(selectedCartItem.getAddressBookId());
                        shopCartItem.setNumber(newQuantity);
                        //selectedCartItem.setNumber(newQuantity);
                        shoppingCartItemService.deleteById(selectedCartItem.getShoppingCartItemId());
                        shoppingCartItemService.insert(shopCartItem);
                        refresh(user); // Refresh the table
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "请输入有效的数字！");
                }
            } else {
                JOptionPane.showMessageDialog(this, "未选择任何商品！");
            }
        });

        checkoutButton.addActionListener(e -> {
            totalAmount = BigDecimal.ZERO; // 重置 totalAmount 为 0
            int[] selectedRows = table.getSelectedRows();
            if (selectedRows.length > 0) {
                List<ShoppingCartItem> selectedItems = new ArrayList<>();
                for (int selectedRow : selectedRows) {
                    ShoppingCartItem selectedCartItem = ShoppingCartItems.get(selectedRow);
                    selectedItems.add(selectedCartItem);
                    Product product = productService.selectById(selectedCartItem.getProductId());
                    BigDecimal productPrice = product.getPrice();
                    BigDecimal number = new BigDecimal(selectedCartItem.getNumber());
                    totalAmount = totalAmount.add(number.multiply(productPrice));
                }
                // 显示总金额
                JOptionPane.showMessageDialog(this, "商品总金额: " + totalAmount + " 元");

                // 弹出选择收货地址的对话框
                List<AddressBook> addresses = addressBookService.selectByUserId(user.getUserId());
                if (addresses.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "没有收货地址，请先添加收货地址！");
                    return;
                }

                // 创建一个对话框来显示地址选择
                JDialog addressDialog = new JDialog(userFrame, "选择收货地址", true);
                addressDialog.setSize(500, 400);
                addressDialog.setLocationRelativeTo(this);

                // 使用 GridLayout 布局来显示每个地址的详细信息
                JPanel addressPanel = new JPanel();
                addressPanel.setLayout(new BoxLayout(addressPanel, BoxLayout.Y_AXIS));

                ButtonGroup addressGroup = new ButtonGroup();
                for (AddressBook address : addresses) {
                    JPanel singleAddressPanel = new JPanel(new GridLayout(0, 2));
                    singleAddressPanel.setBorder(BorderFactory.createTitledBorder("地址"));

                    singleAddressPanel.add(new JLabel("收货人:"));
                    singleAddressPanel.add(new JLabel(address.getConsignee()));
                    singleAddressPanel.add(new JLabel("电话:"));
                    singleAddressPanel.add(new JLabel(address.getPhoneNumber()));
                    singleAddressPanel.add(new JLabel("地址:"));
                    singleAddressPanel.add(new JLabel(address.getDetail()));

                    JRadioButton selectAddressButton = new JRadioButton("选择此地址");
                    selectAddressButton.setActionCommand(String.valueOf(address.getAddressBookId()));
                    addressGroup.add(selectAddressButton);
                    singleAddressPanel.add(selectAddressButton);

                    addressPanel.add(singleAddressPanel);
                }

                JButton confirmAddressButton = new JButton("确认地址");
                confirmAddressButton.addActionListener(e1 -> {
                    String selectedAddressId = addressGroup.getSelection().getActionCommand();
                    if (selectedAddressId != null) {
                        AddressBook selectedAddress = addresses.stream()
                                .filter(address -> String.valueOf(address.getAddressBookId()).equals(selectedAddressId))
                                .findFirst()
                                .orElse(null);

                        if (selectedAddress != null) {
                            addressDialog.dispose();

                            // Navigate to order confirmation panel
                            new OrderConfirmationFrame(user, selectedItems, selectedAddress, totalAmount, userFrame);
                            userFrame.revalidate();
                            userFrame.repaint();
                        }
                    } else {
                        JOptionPane.showMessageDialog(addressDialog, "请选择一个地址！");
                    }
                });

                JButton cancelButton = new JButton("取消");
                cancelButton.addActionListener(e1 -> addressDialog.dispose());
                JPanel buttonPanel1 = new JPanel();
                buttonPanel1.add(confirmAddressButton);
                buttonPanel1.add(cancelButton);

                addressDialog.add(new JScrollPane(addressPanel), BorderLayout.CENTER);
                addressDialog.add(buttonPanel1, BorderLayout.SOUTH);
                addressDialog.setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "未选择任何商品！");
            }
        });

        deleteOrderButton.addActionListener(e -> {
            int[] selectedRows = table.getSelectedRows();
            if (selectedRows.length > 0) {
                for (int i = selectedRows.length - 1; i >= 0; i--) {
                    ShoppingCartItem selectedCartItem = ShoppingCartItems.get(selectedRows[i]);
                    shoppingCartItemService.deleteById(selectedCartItem.getShoppingCartItemId());
                    ShoppingCartItems.remove(selectedRows[i]);
                    model.removeRow(selectedRows[i]);
                }
                JOptionPane.showMessageDialog(this, "商品删除成功！");
            } else {
                JOptionPane.showMessageDialog(this, "未选择任何商品！");
            }
        });

        refreshButton.addActionListener(e -> refresh(user));
    }

    public void refresh(User user) {
        model.setRowCount(0); // Clear the existing rows
        ShoppingCartItems = (ArrayList<ShoppingCartItem>) shoppingCartItemService.selectByUserId(user.getUserId());
        for (ShoppingCartItem shoppingCartItem : ShoppingCartItems) {
            model.addRow(new Object[]{
                    userService.selectById(shoppingCartItem.getUserId()).getNickname(),
                    productService.selectById(shoppingCartItem.getProductId()).getName(),
                    shoppingCartItem.getNumber(),
                    shoppingCartItem.getAddDatetime().format(formatter),
            });
        }
    }
}
