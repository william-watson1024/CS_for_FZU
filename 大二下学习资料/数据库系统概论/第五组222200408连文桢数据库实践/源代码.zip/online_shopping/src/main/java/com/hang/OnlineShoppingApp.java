package com.hang;

import com.hang.gui.primaryframe.PrimaryFrame;

import javax.swing.*;

public class OnlineShoppingApp {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(()->{
            new PrimaryFrame();
        });
    }
}
