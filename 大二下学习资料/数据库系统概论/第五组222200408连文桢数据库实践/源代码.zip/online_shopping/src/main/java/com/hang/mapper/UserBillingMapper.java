package com.hang.mapper;

import com.hang.entity.UserBilling;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface UserBillingMapper {
    @Select("select * from user_billing")
    List<UserBilling> selectAll();

    @Select("select * from user_billing where user_billing_id=#{id}")
    UserBilling selectById(Integer id);

    @Select("select * from user_billing where user_id=#{userId}")
    List<UserBilling> selectByUserId(String userId);

    @Insert("insert into user_billing(user_billing_id, user_id, change_balance, description, change_time) VALUES (null, #{userId}, #{changeBalance}, #{description}, #{changeTime})")
    void insert(UserBilling userBilling);

    @Update("update user_billing   set  change_balance=#{changeBalance},description=#{description},change_time=#{changeTime} where user_billing_id=#{userBillingId}")
    void updateById(UserBilling userBilling);

    @Delete("delete from user_billing where user_billing_id=#{id};")
    void deleteById(Integer id);
}
