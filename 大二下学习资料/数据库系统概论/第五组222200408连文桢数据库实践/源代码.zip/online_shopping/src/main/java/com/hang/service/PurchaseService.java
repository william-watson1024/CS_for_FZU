package com.hang.service;

import com.hang.entity.Purchase;
import com.hang.gui.shopframe.tabbedpanels.DatePicker;

import java.time.LocalDate;
import java.util.List;

public interface PurchaseService {
    List<Purchase> selectByShopIdAndRange(LocalDate begin, LocalDate end, Integer shopId,String orderString,String productId);
void insert(Purchase purchase);
}
