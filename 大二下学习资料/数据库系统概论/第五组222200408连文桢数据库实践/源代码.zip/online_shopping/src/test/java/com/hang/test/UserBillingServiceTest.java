package com.hang.test;

import com.hang.entity.UserBilling;
import com.hang.service.UserBillingService;
import com.hang.service.impl.UserBillingServiceImpl;
import org.junit.Test;

import java.util.List;

public class UserBillingServiceTest {
    UserBillingService userBillingService = new UserBillingServiceImpl();
    @Test
    public void testSelectByUserId(){
        List<UserBilling> userBillings = userBillingService.selectByUserId("user");
        for (UserBilling userBilling : userBillings) {
            System.out.println(userBilling);
        }
    }
}
