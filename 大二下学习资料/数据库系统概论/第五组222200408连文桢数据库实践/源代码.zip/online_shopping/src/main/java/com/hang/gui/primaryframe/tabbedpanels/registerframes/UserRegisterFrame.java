package com.hang.gui.primaryframe.tabbedpanels.registerframes;

import com.hang.entity.User;
import com.hang.service.UserService;
import com.hang.service.impl.UserServiceImpl;
import com.hang.utils.CheckCodeUtil;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;

public class UserRegisterFrame extends JFrame {
    private final UserService userService = new UserServiceImpl();
    private String checkCode;

    JPanel contentPanel = new JPanel(new GridBagLayout());

    JLabel idLabel = new JLabel("账号: ");
    JTextField idField = new JTextField(10);

    JLabel passwordLabel = new JLabel("密码: ");
    JPasswordField passwordField = new JPasswordField(10);

    JLabel checkPasswordLabel = new JLabel("确认密码: ");
    JPasswordField checkPasswordField = new JPasswordField(10);

    JLabel nicknameLabel = new JLabel("昵称: ");
    JTextField nicknameField = new JTextField(10);

    JLabel phoneLabel = new JLabel("手机号: ");
    JTextField phoneField = new JTextField(10);

    JButton checkCodeButton = new JButton();
    JTextField checkCodeField = new JTextField(8);
    JPanel checkCodePanel = new JPanel();

    JButton checkButton = new JButton("确定");
    JPanel checkButtonPanel = new JPanel();
    
    public UserRegisterFrame(){
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5, 5, 5, 5);

        // 第1行：账号
        c.gridy = 0;

        c.gridx = 0;
        contentPanel.add(idLabel,c);

        c.gridx = 1;
        contentPanel.add(idField,c);


        // 第2行：密码
        c.gridy = 1;

        c.gridx = 0;
        contentPanel.add(passwordLabel,c);

        c.gridx = 1;
        contentPanel.add(passwordField,c);


        // 第3行：确认密码
        c.gridy = 2;

        c.gridx = 0;
        contentPanel.add(checkPasswordLabel,c);

        c.gridx = 1;
        contentPanel.add(checkPasswordField,c);


        // 第4行：昵称
        c.gridy = 3;

        c.gridx = 0;
        contentPanel.add(nicknameLabel,c);

        c.gridx = 1;
        contentPanel.add(nicknameField,c);


        // 第5行：手机号
        c.gridy = 4;

        c.gridx = 0;
        contentPanel.add(phoneLabel,c);

        c.gridx = 1;
        contentPanel.add(phoneField,c);


        // 第6行：设置验证码panel
        c.gridy = 5;

        checkCodeField.setPreferredSize(new Dimension(180, 45));
        checkCodeButton.addActionListener(e -> {
            checkCode = CheckCodeUtil.setButtonIconAndReturnCheckCode(checkCodeButton);
        });

        checkCodePanel.setOpaque(false);

        checkCodePanel.add(checkCodeField);
        checkCodePanel.add(checkCodeButton);

        checkCode = CheckCodeUtil.setButtonIconAndReturnCheckCode(checkCodeButton);

        c.gridx = 0;
        c.gridwidth = 2;
        contentPanel.add(checkCodePanel, c);


        // 第7行：设置确定按钮panel
        c.gridy = 6;

        checkButtonPanel.add(checkButton);

        c.gridx = 0;
        c.gridwidth = 2;
        contentPanel.add(checkButtonPanel,c);

        checkButton.addActionListener(e->{
            User user = userService.selectById(idField.getText());
            if(idField.getText().equals("")){
                JOptionPane.showMessageDialog(this,"账号不能为空");
            }else if(user!=null){
                JOptionPane.showMessageDialog(this,"账号已存在");
            }else if(passwordField.getText().length()<6){
                JOptionPane.showMessageDialog(this,"密码不少于6位");
            }else if(!passwordField.getText().equals(checkPasswordField.getText())){
                JOptionPane.showMessageDialog(this,"两次输入密码不一致");
            } else if(phoneField.getText().equals("")){
                JOptionPane.showMessageDialog(this,"手机号不能为空");
            } else if(!checkCode.equalsIgnoreCase(checkCodeField.getText())){
                JOptionPane.showMessageDialog(this,"验证码错误");
                checkCode = CheckCodeUtil.setButtonIconAndReturnCheckCode(checkCodeButton);
            }else{
                User newUser = new User();
                newUser.setUserId(idField.getText());
                newUser.setPassword(passwordField.getText());
                newUser.setNickname(nicknameField.getText());
                newUser.setPhoneNumber(phoneField.getText());
                newUser.setRegisterDate(LocalDate.now());

                userService.insert(newUser);

                JOptionPane.showMessageDialog(this,"用户注册成功");
                dispose();
            }
        });


        // 设置窗口参数
        setTitle("注册新用户");
        add(contentPanel);
        setVisible(true);
        pack();
        setLocationRelativeTo(null);
    }
}
