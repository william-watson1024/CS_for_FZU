package com.hang.test;

import com.hang.entity.ShoppingCartItem;
import com.hang.service.ShoppingCartItemService;
import com.hang.service.impl.ShoppingCartItemServiceImpl;
import org.junit.Test;

import java.util.List;

public class ShoppingCartItemServiceTest {
    ShoppingCartItemService shoppingCartItemService = new ShoppingCartItemServiceImpl();
    @Test
    public void testSelectByUserId(){
        List<ShoppingCartItem> shoppingCartItems = shoppingCartItemService.selectByUserId("user");
        for (ShoppingCartItem shoppingCartItem : shoppingCartItems) {
            System.out.println(shoppingCartItem);
        }
    }
}
