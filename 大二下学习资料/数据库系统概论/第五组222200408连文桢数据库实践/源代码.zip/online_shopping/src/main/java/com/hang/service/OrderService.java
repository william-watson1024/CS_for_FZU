package com.hang.service;

import com.hang.entity.Order;


import java.time.LocalDateTime;
import java.util.List;

public interface OrderService {
    List<Order> selectAll();
    Order selectById(Integer id);
    List<Order> selectBetweenDatetime(LocalDateTime begin, LocalDateTime end);

    List<Order> selectByShopId(Integer shopId);

    List<Order> selectByUserId(String userId);
    void insert(Order order);
    void updateById(Order order);
    void deleteById(Integer id);

    List<Order> selectForOrderManage(String orderedBy, String deliveryStatus, String paymentStatus);
}
