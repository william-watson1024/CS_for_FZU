package com.hang.gui.shopframe.tabbedpanels;

import com.hang.entity.Product;
import com.hang.entity.Shop;
import com.hang.service.ProductService;
import com.hang.service.impl.ProductServiceImpl;


import javax.swing.*;
import java.awt.*;
import java.math.BigDecimal;

public class ProductInfoDialog extends JDialog {
    private ProductService productService = new ProductServiceImpl();

    private JTextField productNameField;
    private JTextField brandField;
    private JTextField descriptionField;
    private JTextField priceField;
    private JTextField categoryField;
    private JTextField stockField;
    private JTextField weightField;
    private JTextField sizeField;
    private JTextField photoPathField;

    public ProductInfoDialog(JFrame parent, Shop shop) {
        super(parent, "商品信息", true);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;


        productNameField = addLabeledField("商品名称:", gbc, 1);
        brandField = addLabeledField("品牌:", gbc, 2);
        descriptionField = addLabeledField("商品详细描述:", gbc, 3);
        priceField = addLabeledField("价格:", gbc, 4);
        categoryField = addLabeledField("种类:", gbc, 5);
        stockField = addLabeledField("库存数量:", gbc, 6);
        weightField = addLabeledField("重量:", gbc, 7);
        sizeField = addLabeledField("商品尺寸:", gbc, 8);
        photoPathField = addLabeledField("照片路径:", gbc, 9);

        JButton browseButton = new JButton("选择照片");
        browseButton.addActionListener(e -> selectPhoto());
        gbc.gridx = 4; // 放在文本框的右边
        gbc.gridy = 9;
        add(browseButton, gbc);

        JButton okButton = new JButton("确定");
        okButton.setSize(100, 30);
        okButton.addActionListener(e -> {
            String productName = productNameField.getText();
            String brand = brandField.getText();
            String description = descriptionField.getText();
            String price = priceField.getText();
            String category = categoryField.getText();
            String stock = stockField.getText();
            String weight = weightField.getText();
            String size = sizeField.getText();
            String photoPath = photoPathField.getText();
            //System.out.println(storeName + " " + productName + " " + brand + " " + description + " " + price + " " + category + " " + stock + " " + weight + " " + size + " " + photoPath);

            Product product = new Product();
            product.setShopId(shop.getShopId());
            product.setName(productName);
            product.setBrand(brand);
            product.setDescription(description);
            product.setPrice(new BigDecimal(price));
            product.setType(category);
            product.setStock(Integer.parseInt(stock));
            product.setWeight(new BigDecimal(weight));
            product.setSize(size);
            product.setPhoto(photoPath);
            product.setKeyWords(productName);
            product.setStatus("在售");
            product.setSalesVolume(0);
            productService.insert(product);
            dispose();
        });
        gbc.gridx = 1;
        gbc.gridy = 10;
        gbc.gridwidth = 1;
        add(okButton, gbc);

        JButton cancelButton = new JButton("取消");
        cancelButton.setSize(100, 30);
        cancelButton.addActionListener(e -> dispose());
        gbc.gridx = 2;
        add(cancelButton, gbc);

        pack();
        setLocationRelativeTo(parent);
    }
    private void selectPhoto() {
        JFileChooser fileChooser = new JFileChooser();
        int returnValue = fileChooser.showOpenDialog(this);
        if (returnValue == JFileChooser.APPROVE_OPTION) {
            String filePath = fileChooser.getSelectedFile().getPath();
            photoPathField.setText(filePath);
        }
    }
    private JTextField addLabeledField(String labelText, GridBagConstraints gbc, int y) {
        JLabel label = new JLabel(labelText);
        gbc.gridx = 0;
        gbc.gridy = y;
        add(label, gbc);

        JTextField textField = new JTextField(20);
        gbc.gridx = 1;
        gbc.gridwidth = 3;
        add(textField, gbc);
        gbc.gridwidth = 1;

        return textField;
    }


}
