package com.hang.gui.adminframe.tabbedpanels;


import com.hang.entity.User;
import com.hang.service.UserService;
import com.hang.service.impl.UserServiceImpl;
import com.hang.utils.TableUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class UserManage extends JPanel {
    private final UserService userService = new UserServiceImpl();
    private final JTable table = new JTable();
    List<User> userList;

    JTextField searchField = new JTextField(10);
    JButton searchButton = new JButton("搜索");

    // 状态下拉框
    String[] statusOptions = {"全部", "正常", "禁用"};
    JComboBox<String> statusComboBox= new JComboBox<>(statusOptions);

    // 选择排序下拉框
    String[] creditLevelOrderedOptions = {"信用等级", "余额"};
    JComboBox<String> creditLevelOrBalanceComboBox = new JComboBox<>(creditLevelOrderedOptions);

    // 信用等级排序下拉框
    String[] orderedOptions = {"升序", "降序"};
    JComboBox<String> orderedComboBox = new JComboBox<>(orderedOptions);

    public UserManage(){
        setLayout(new BorderLayout());

        setNorthPanel();
        setEastPanel();

        add(new JScrollPane(table),BorderLayout.CENTER);
        updateTable();
    }
    private void setEastPanel() {
        JPanel eastPanel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(20, 10, 20, 10);

        JButton normalButton = new JButton("恢复正常");
        JButton banButton = new JButton("禁用");
        JButton addCreditLevelButton = new JButton("信用等级+1");
        JButton subCreditLeverButton = new JButton("信用等级-1");

        c.gridy = 0;
        eastPanel.add(normalButton, c);

        c.gridy = 1;
        eastPanel.add(banButton, c);

        c.gridy = 2;
        eastPanel.add(addCreditLevelButton, c);

        c.gridy = 3;
        eastPanel.add(subCreditLeverButton, c);

        banButton.setPreferredSize(addCreditLevelButton.getPreferredSize());
        normalButton.setPreferredSize(addCreditLevelButton.getPreferredSize());

        normalButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();

            if (selectedRow == -1) {
                return;
            }

            User user = userList.get(selectedRow);
            user.setStatus("正常");
            userService.updateById(user);
            updateTable();

            for (int i = 0; i < userList.size(); i++) {
                if (userList.get(i).getUserId().equals(user.getUserId())) {
                    table.setRowSelectionInterval(i, i);
                }
            }
        });

        banButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();

            if (selectedRow == -1) {
                return;
            }

           User user = userList.get(selectedRow);
            user.setStatus("禁用");
            userService.updateById(user);
            updateTable();

            for (int i = 0; i < userList.size(); i++) {
                if (userList.get(i).getUserId().equals(user.getUserId())) {
                    table.setRowSelectionInterval(i, i);
                }
            }
        });

        addCreditLevelButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow == -1) {
                return;
            }

           User user = userList.get(selectedRow);

            if (user.getCreditLevel() >= 5) {
                JOptionPane.showMessageDialog(this, "信用等级在1-5之间");
            } else {
                user.setCreditLevel(user.getCreditLevel() + 1);
                userService.updateById(user);
                updateTable();

                for (int i = 0; i < userList.size(); i++) {
                    if (userList.get(i).getUserId().equals(user.getUserId())) {
                        table.setRowSelectionInterval(i, i);
                    }
                }
            }
        });

        subCreditLeverButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow == -1) {
                return;
            }

            User user = userList.get(selectedRow);

            if (user.getCreditLevel() <= 1) {
                JOptionPane.showMessageDialog(this, "信用等级在1-5之间");
            } else {
                user.setCreditLevel(user.getCreditLevel() - 1);
                userService.updateById(user);
                updateTable();

                for (int i = 0; i < userList.size(); i++) {
                    if (userList.get(i).getUserId().equals(user.getUserId())) {
                        table.setRowSelectionInterval(i, i);
                    }
                }
            }
        });


        add(eastPanel, BorderLayout.EAST);
    }

    private void setNorthPanel() {
        JPanel northPanel = new JPanel();

        northPanel.add(new JLabel("  状态:"));
        northPanel.add(statusComboBox);
        northPanel.add(new JLabel("  按照"));
        northPanel.add(creditLevelOrBalanceComboBox);
        northPanel.add(new JLabel("排序:"));
        northPanel.add(orderedComboBox);
        northPanel.add(new JLabel("  账号|昵称: "));
        northPanel.add(searchField);
        northPanel.add(searchButton);

        add(northPanel, BorderLayout.NORTH);

        statusComboBox.addActionListener(e -> updateTable());
        creditLevelOrBalanceComboBox.addActionListener(e -> updateTable());
        orderedComboBox.addActionListener(e -> updateTable());
        searchButton.addActionListener(e-> updateTable());
    }

    private void updateTable() {
        userList = userService.selectByConditions(searchField.getText(),
                (String)statusComboBox.getSelectedItem(),
                (String) creditLevelOrBalanceComboBox.getSelectedItem(),
                (String) orderedComboBox.getSelectedItem()
        );

        // 创建表格模型
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("账号");
        model.addColumn("昵称");
        model.addColumn("状态");
        model.addColumn("信用状态");
        model.addColumn("余额");
        model.addColumn("注册日期");

        // 添加数据到表格模型
        for (User user : userList) {
            model.addRow(new Object[]{user.getUserId(),user.getNickname(),user.getStatus(),user.getCreditLevel(),user.getBalance(),user.getRegisterDate()});
        }

        table.setModel(model);

        // 使用工具类，设置表格样式
        TableUtils.setTableStyle(table);
    }
}
