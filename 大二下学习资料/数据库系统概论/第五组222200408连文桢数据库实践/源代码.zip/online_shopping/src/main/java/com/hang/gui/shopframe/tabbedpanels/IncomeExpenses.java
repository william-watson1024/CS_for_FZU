package com.hang.gui.shopframe.tabbedpanels;


import com.hang.entity.Shop;
import com.hang.entity.ShopBilling;
import com.hang.gui.shopframe.ShopFrame;
import com.hang.service.ShopBillingService;
import com.hang.service.impl.ShopBillingServiceImpl;
import com.hang.service.impl.ShopServiceImpl;
import com.hang.service.ShopService;
import com.hang.utils.TableUtils;


import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigInteger;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.List;


public class IncomeExpenses extends JPanel {

    ShopBillingService shopBillingService = new ShopBillingServiceImpl() ;

    ShopService shopService = new ShopServiceImpl();
    List<ShopBilling> shopBillings = shopBillingService.selectAll();
    //ArrayList<ShopBilling> shopBillings =new ArrayList<ShopBilling>();

    private JComboBox<String> yearComboBox;
    private JComboBox<String> monthComboBox;
    private JComboBox<String> dayComboBox;

    private LocalDateTime targetTimeBegin;
    private LocalDateTime targetTimeEnd;
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private JTable table = new JTable();
    BigDecimal totalIncome = new BigDecimal(0);
    JLabel totalIncomeLabel=new JLabel();
    JButton detailButton = new JButton("查看详情");
    public IncomeExpenses(Shop shop, ShopFrame shopFrame) {

        setLayout(new BorderLayout());

//        LocalDateTime now = LocalDateTime.now();
//        ShowShopBillingTable( );

        JPanel selectPanel = new JPanel();

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        yearComboBox = new JComboBox<>();
        for (int i = currentYear; i >= currentYear - 100; i--) {
            yearComboBox.addItem(String.valueOf(i));
        }
        // 创建月份下拉框
        monthComboBox = new JComboBox<>();
        monthComboBox.addItem("-");
        for (int i = 1; i <= 12; i++) {
            monthComboBox.addItem(String.valueOf(i));
        }

        // 添加事件监听器到月份下拉框
        monthComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateDays();
            }
        });

        // 创建日期下拉框
        dayComboBox = new JComboBox<>();
        dayComboBox.addItem("-");
        for (int i = 1; i <= 31; i++) {
            dayComboBox.addItem(String.valueOf(i));
        }
        dayComboBox.setEnabled(false);
        selectPanel.add(new JLabel("年份："));
        selectPanel.add(yearComboBox);
        selectPanel.add(new JLabel("月份："));
        selectPanel.add(monthComboBox);
        selectPanel.add(new JLabel("日期："));
        selectPanel.add(dayComboBox);
        JButton searchButton = new JButton("搜索");
        selectPanel.add(searchButton);

        selectPanel.add(detailButton);
        totalIncomeLabel.setText("总收入："+totalIncome);
        selectPanel.add(totalIncomeLabel);

        JLabel totalAmount = new JLabel("可提现："+shop.getShopRevenue());
        selectPanel.add(totalAmount);

        JButton withdrawButton = new JButton("提现");
        selectPanel.add(withdrawButton);


        add(selectPanel, BorderLayout.NORTH);
        withdrawButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JDialog withdrawDialog=new JDialog(shopFrame,"提现",true);
                withdrawDialog.setLayout(new BorderLayout());
                JPanel withdrawPanel=new JPanel();
                withdrawPanel.add(new JLabel("提现金额："));
                JTextField withdrawTextField=new JTextField(10);
                withdrawPanel.add(withdrawTextField);
                withdrawDialog.add(withdrawPanel,BorderLayout.CENTER);
                JPanel buttonPanel=new JPanel();
                JButton withdrawButton=new JButton("提现");
                JButton cancelButton=new JButton("取消");


                withdrawButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if(withdrawTextField.getText().equals("")){
                            JOptionPane.showMessageDialog(shopFrame,"请输入提现金额");
                            return;
                        } else if (!withdrawTextField.getText().matches("^[0-9]+\\.?[0-9]*$")) {
                            JOptionPane.showMessageDialog(shopFrame,"请输入正确的金额");
                            return;
                        } else if(shop.getShopRevenue().compareTo(new BigDecimal(withdrawTextField.getText()))<0){
                            JOptionPane.showMessageDialog(shopFrame,"余额不足");
                            return;
                        }
                        else{

                            ShopBilling tarShopBilling = new ShopBilling();
                            tarShopBilling.setShopId(shop.getShopId());
                            tarShopBilling.setChangeBalance((new BigDecimal(withdrawTextField.getText())).multiply(BigDecimal.valueOf(-1)));
                            tarShopBilling.setDescription("提现");
                            tarShopBilling.setChangeTime(LocalDateTime.now());
                            shop.setShopRevenue(shop.getShopRevenue().subtract(new BigDecimal(withdrawTextField.getText())));
                            shopService.updateById(shop);
                            totalAmount.setText("可提现："+shop.getShopRevenue());
                            shopBillingService.insert(tarShopBilling);
                            JOptionPane.showMessageDialog(shopFrame,"提现成功");
                            //totalIncome=totalIncome.subtract(new BigDecimal(withdrawTextField.getText()));
                        }
                        withdrawDialog.dispose();
                    }
                });
                cancelButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        withdrawDialog.dispose();
                    }
                });

                buttonPanel.add(withdrawButton);
                buttonPanel.add(cancelButton);
                withdrawDialog.add(buttonPanel,BorderLayout.SOUTH);
                withdrawDialog.setSize(400,300);
                withdrawDialog.setLocation(shopFrame.getX()+shopFrame.getWidth()/2-200,shopFrame.getY()+shopFrame.getHeight()/2-150);
                withdrawDialog.setVisible(true);

                LocalDateTime now = LocalDateTime.now();
                ShowShopBillingTable(String.valueOf(now.getYear()), String.valueOf(now.getMonthValue()), String.valueOf(now.getDayOfMonth()), shop, shopFrame);
            }
        });

        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedYear = (String) yearComboBox.getSelectedItem();
                String selectedMonth = (String) monthComboBox.getSelectedItem();
                String selectedDay = (String) dayComboBox.getSelectedItem();
                ShowShopBillingTable(selectedYear, selectedMonth, selectedDay, shop,shopFrame);
            }
        });
        LocalDateTime now = LocalDateTime.now();
        ShowShopBillingTable( String.valueOf(now.getYear()), String.valueOf(now.getMonthValue()), String.valueOf(now.getDayOfMonth()), shop, shopFrame);

    }
    private void ShowShopBillingTable(String selectedYear, String selectedMonth, String selectedDay, Shop shop,ShopFrame shopFrame) {
        totalIncome= BigDecimal.valueOf(0);
        if(!selectedMonth.equals("-")&&selectedDay.equals("-")){// 如果只选择了年月，则显示该月的所有账单
            targetTimeBegin=LocalDateTime.of(Integer.parseInt(selectedYear),Integer.parseInt(selectedMonth),1,0,0,0);
            targetTimeEnd=targetTimeBegin.plusMonths(1);
        }
        else if (selectedMonth.equals("-")){
            targetTimeBegin=LocalDateTime.of(Integer.parseInt(selectedYear),1,1,0,0,0);
            targetTimeEnd=targetTimeBegin.plusYears(1);
        }// 如果只选择了年份，则显示该年份的所有账单
        else {
            targetTimeBegin=LocalDateTime.of(Integer.parseInt(selectedYear),Integer.parseInt(selectedMonth),Integer.parseInt(selectedDay),0,0,0);
            targetTimeEnd=targetTimeBegin.plusDays(1);
        }
        shopBillings=shopBillingService.selectByShopIdAndTimeRange(targetTimeBegin,targetTimeEnd,shop.getShopId());
        String[][] data = new String[shopBillings.size()][5];
        String[] columnNames = {"","变动时间", "变动金额", "描述", "归属店铺"};
        TableUtils.setTableStyle(table);

        for (int i = 0; i < shopBillings.size(); i++) {

            data[i][1] = String.valueOf(shopBillings.get(i).getChangeTime().format(formatter));
            data[i][2] = String.valueOf(shopBillings.get(i).getChangeBalance());
            data[i][3] = String.valueOf(shopBillings.get(i).getDescription());
            data[i][4] = String.valueOf(shopService.selectById(shop.getShopId()).getShopName());
            totalIncome=totalIncome.add(shopBillings.get(i).getChangeBalance());
        }
        totalIncomeLabel.setText("总收入："+totalIncome);
        // 创建表格模型
        DefaultTableModel model = new DefaultTableModel(data, columnNames) {
            @Override
            public Class<?> getColumnClass(int column) {
                if (column == 0) {
                    return ImageIcon.class;
                } else {
                    return String.class;
                }
            }
        };

//        JPanel tablePanel = new JPanel();
//        tablePanel.add(table);

        table.setModel(model);

        // 获取表格的列模型
        TableColumnModel columnModel = table.getColumnModel();


        TableColumn firstColumn = columnModel.getColumn(0); // 获取第一列
        firstColumn.setPreferredWidth(1); // 设置首选宽度
        firstColumn.setMaxWidth(1); // 设置最大宽度
        firstColumn.setMinWidth(0); // 设置最小宽度
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();

        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        table.setVisible(true);


        detailButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if( selectedRow == -1) {
                JOptionPane.showMessageDialog(null, "未选择任何账单！");
            }
            else{
                ShopBilling shopBilling = shopBillings.get(selectedRow);
                JDialog detailDialog =  new JDialog(shopFrame,"账单详情",true);
                detailDialog.setSize(500, 400);
                int x = shopFrame.getX() + (shopFrame.getWidth() - detailDialog.getWidth()) / 2;
                int y = shopFrame.getY() + (shopFrame.getHeight() - detailDialog.getHeight()) / 2;
                detailDialog.setLocation(x,y);
                JPanel detailPanel = new JPanel();
                detailDialog.add(detailPanel);
                detailPanel.setLayout(new GridLayout(5,8));
                JLabel changeTimeLabel = new JLabel("变动时间：");
                JLabel changeTimeValueLabel = new JLabel(String.valueOf(shopBilling.getChangeTime().format(formatter)));
                JLabel changeBalanceLabel = new JLabel("变动金额：");
                JLabel changeBalanceValueLabel = new JLabel(String.valueOf(shopBilling.getChangeBalance()));
                JLabel descriptionLabel = new JLabel("描述：");
                JLabel descriptionValueLabel = new JLabel(String.valueOf(shopBilling.getDescription()));
                JLabel shopIdLabel = new JLabel("归属店铺：");
                JLabel shopIdValueLabel = new JLabel(String.valueOf(shopService.selectById(shop.getShopId()).getShopName()));

                detailPanel.add(changeTimeLabel);
                detailPanel.add(changeTimeValueLabel);
                detailPanel.add(changeBalanceLabel);
                detailPanel.add(changeBalanceValueLabel);
                detailPanel.add(descriptionLabel);
                detailPanel.add(descriptionValueLabel);
                detailPanel.add(shopIdLabel);
                detailPanel.add(shopIdValueLabel);



                detailDialog.setVisible(true);
            }

        });


    }

    private void updateDays() {
        String selectedMonth = (String) monthComboBox.getSelectedItem();
        if (selectedMonth != null && selectedMonth.equals("-")) {
            dayComboBox.setSelectedItem("-");
            dayComboBox.setEnabled(false);
        } else {
            dayComboBox.setEnabled(true);
            int month = Integer.parseInt(selectedMonth);
            int daysInMonth = getDaysInMonth(month);
            dayComboBox.removeAllItems();
            dayComboBox.addItem("-");
            for (int i = 1; i <= daysInMonth; i++) {
                dayComboBox.addItem(String.valueOf(i));
            }
        }
    }

    private int getDaysInMonth(int month) {
        int year = Integer.parseInt((String) yearComboBox.getSelectedItem());
        switch (month) {
            case 2:
                // 检查闰年
                if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) {
                    return 29;
                } else {
                    return 28;
                }
            case 4: case 6: case 9: case 11:
                return 30;
            default:
                return 31;
        }
    }

}
