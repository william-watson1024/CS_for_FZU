package com.hang.gui.userframe;

import com.hang.entity.User;
import com.hang.gui.userframe.tabbedpanels.*;
import com.hang.service.UserService;
import com.hang.service.impl.UserServiceImpl;

import javax.swing.*;
import java.awt.*;

public class UserFrame extends JFrame {
    private UserService userService = new UserServiceImpl();
    private final User user;
    // 创建选项卡面板
    private final JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.LEFT);

    public UserFrame(User user) {
        setTitle("用户：" + user.getUserId());
        this.user = user;

        setExtendedState(JFrame.MAXIMIZED_BOTH);

        tabbedPane.addTab("欢迎", null, new Welcome(user), "欢迎");
        tabbedPane.addTab("购物", null, new Shopping(user), "购物");
        tabbedPane.addTab("购物车", null, new ShoppingCartPanel(user, this), "购物车");
        tabbedPane.addTab("全部订单", null, new OrderManagePanel(user, this), "全部订单");
        tabbedPane.addTab("收货地址管理", null, new AddressBookManage(user), "收货地址管理");
        tabbedPane.addTab("账单和余额", null, new BalancePanel(user), "余额");
        tabbedPane.addTab("修改用户信息", null, new ChangeInformation(user, this), "修改用户信息");

        // 将选项卡面板添加到框架
        add(tabbedPane, BorderLayout.CENTER);
        setLocationRelativeTo(null);
        // 显示窗口/
        setVisible(true);
    }

    // 公开方法来访问 JTabbedPane
    public JTabbedPane getTabbedPane() {
        return tabbedPane;
    }
}
