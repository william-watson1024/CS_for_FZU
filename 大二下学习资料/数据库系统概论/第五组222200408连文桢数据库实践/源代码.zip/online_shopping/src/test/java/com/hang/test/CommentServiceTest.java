package com.hang.test;

import com.hang.entity.Comment;
import com.hang.service.CommentService;
import com.hang.service.impl.CommentServiceImpl;
import org.junit.Test;

public class CommentServiceTest {
    private CommentService commentService = new CommentServiceImpl();

    @Test
    public void test(){
        Comment comment = commentService.selectById(1005);
        System.out.println(comment);
    }
}
