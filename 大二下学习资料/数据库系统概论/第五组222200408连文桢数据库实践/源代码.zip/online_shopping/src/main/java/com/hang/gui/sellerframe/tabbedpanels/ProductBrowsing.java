package com.hang.gui.sellerframe.tabbedpanels;

import com.hang.entity.Seller;
import com.hang.entity.Product;
import com.hang.entity.Shop;
import com.hang.service.ProductService;
import com.hang.service.ShopService;
import com.hang.service.impl.ProductServiceImpl;
import com.hang.service.impl.ShopServiceImpl;
import com.hang.utils.ImageUtils;
import com.hang.utils.TableUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;

public class ProductBrowsing extends JPanel {
    private ProductService productService = new ProductServiceImpl();
    private ShopService shopService = new ShopServiceImpl();
    private JTable table = new JTable();

    public ProductBrowsing(Seller seller) {
        setLayout(new BorderLayout());

        // 创建滚动面板并将表格添加到其中
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        setSelectConditionPanel();
        //showTable("", new BigDecimal(0), new BigDecimal(2e+75));
    }

    private void setSelectConditionPanel() {
        JPanel selectConditionPanel = new JPanel();

        selectConditionPanel.add(new JLabel("关键词: "));

        JTextField inputField = new JTextField(10);
        selectConditionPanel.add(inputField);

        selectConditionPanel.add(new JLabel("价格区间:"));

        JTextField lowestPriceField = new JTextField("0", 4);
        selectConditionPanel.add(lowestPriceField);

        selectConditionPanel.add(new JLabel("-"));


        JTextField highestPriceField = new JTextField("1000", 4);
        selectConditionPanel.add(highestPriceField);

        JButton searchButton = new JButton("搜索");
        selectConditionPanel.add(searchButton);

        searchButton.addActionListener(e -> {
            BigDecimal lowestPrice = BigDecimal.valueOf(Double.parseDouble(lowestPriceField.getText()));
            BigDecimal highestPrice = BigDecimal.valueOf(Double.parseDouble(highestPriceField.getText()));
            showTable(inputField.getText(), lowestPrice, highestPrice);
        });

        add(selectConditionPanel, BorderLayout.NORTH);
    }


    private void showTable(String keyWord, BigDecimal lowestPrice, BigDecimal highestPrice) {
        List<Product> products = productService.selectByConditions(keyWord, lowestPrice, highestPrice);


        // 定义列名
        String[] columnNames = {"照片", "商品名", "品牌", "店铺名", "价格"};

        // 创建一个二维 Object 数组，行数为产品数量，列数为 5
        Object[][] data = new Object[products.size()][5];


        TableUtils.setTableStyle(table);

        // 遍历产品列表，将每个产品的信息填充到 Object 数组中
        for (int i = 0; i < products.size(); i++) {
            Product product = products.get(i);
            Shop shop = shopService.selectById(product.getShopId());
            String shopName = shop.getShopName();

            String path = "image/product/" + product.getPhoto();
            ImageIcon icon = ImageUtils.getProductImageIcon(150, 150, path);

            data[i][0] = icon;
            data[i][1] = product.getName();
            data[i][2] = product.getBrand();
            data[i][3] = shopName;
            data[i][4] = product.getPrice();
        }

        // 创建表格模型
        DefaultTableModel model = new DefaultTableModel(data, columnNames) {
            @Override
            public Class<?> getColumnClass(int column) {
                if (column == 0) {
                    return ImageIcon.class;
                } else {
                    return String.class;
                }
            }
        };

        table.setModel(model);

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();

        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);

        // 将渲染器应用于所有列
        for (int i = 1; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }

        table.setRowHeight(150);

    }
}
