package com.hang.mapper;

import com.hang.entity.ShoppingCartItem;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface ShoppingCartItemMapper {
    @Select("select * from shopping_cart_item")
    List<ShoppingCartItem> selectAll();

    @Select("select * from shopping_cart_item where shopping_cart_item_id=#{id}")
    ShoppingCartItem selectById(Integer id);

    @Select("select * from shopping_cart_item where user_id=#{userId}")
    List<ShoppingCartItem> selectByUserId(String userId);

    @Insert("insert into shopping_cart_item (shopping_cart_item_id, user_id, product_id, number, add_datetime, address_book_id, remark) values (null, #{userId}, #{productId}, #{number}, #{addDatetime}, #{addressBookId}, #{remark});")
    void insert(ShoppingCartItem shoppingCartItem);

    @Update("update shopping_cart_item set number=#{number},add_datetime=#{addDateTime},address_book_id=#{addressBookId},remark=#{remark} where shopping_cart_item_id=#{shoppingCartItemId}")
    void updateById(ShoppingCartItem shoppingCartItem);

    @Delete("delete from shopping_cart_item where shopping_cart_item_id=#{id}")
    void deleteById(Integer id);
}
