package com.hang.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import java.time.LocalDate;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 商家表
 * </p>
 *
 * @author hang
 * @since 2024-05-23
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class Seller implements Serializable {


    /**
     * 账号
     */
    @TableId(value = "seller_id", type = IdType.NONE)
    private String sellerId;

    /**
     * 密码
     */
    private String password;

    /**
     * 姓名
     */
    private String name;

    /**
     * 头像
     */
    private String avatar;

    /**
     * 邮箱
     */
    private String email;

    /**
     * 手机号
     */
    private String phoneNumber;

    /**
     * 状态 (正常|禁用) 默认:正常
     */
    private String status;

    /**
     * 信用等级 [1-5] 默认:3
     */
    private Integer creditLevel;

    /**
     * 注册日期
     */
    private LocalDate registerDate;

    /**
     * 身份证号
     */
    private String idNumber;


}
