package com.hang.service;

import com.hang.entity.Seller;

import java.util.List;

public interface SellerService {
    List<Seller> selectAll();
    Seller selectById(String id);
    List<Seller> selectByConditions(String searchText, String status, String ordered);
    void insert(Seller newSeller);

    void updateById(Seller seller);
    void deleteById(String sellerId);
}
