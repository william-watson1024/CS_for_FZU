package com.hang.mapper;


import com.hang.entity.Admin;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface AdminMapper {
    @Select("select * from admin")
    List<Admin> selectAll();

    @Select("select * from admin where admin_id=#{id}")
    Admin selectById(String id);

    @Insert("insert into admin(admin_id, password, name, phone_number, email) VALUES (#{adminId},#{password},#{name},#{phoneNumber},#{email})")
    void insert(Admin admin);


    @Update("update admin set password=#{password}, name=#{name}, phone_number=#{phoneNumber}, email=#{email} where admin_id=#{adminId}")
    void updateById(Admin admin);

    @Delete("delete from admin where admin_id=#{id}")
    void deleteById(String id);
}
