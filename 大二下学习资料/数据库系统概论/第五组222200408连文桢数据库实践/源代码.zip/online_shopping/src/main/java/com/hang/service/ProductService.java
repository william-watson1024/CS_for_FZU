package com.hang.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hang.entity.Product;
import com.hang.entity.User;

import java.math.BigDecimal;
import java.util.List;

public interface ProductService {
    List<Product> selectAll();
    Product selectById(Integer id);
    List<Product> selectByConditions(String keyWord,BigDecimal lowestPrice,BigDecimal highestPrice);
    List<Product> selectByShopIdAndConditions(String keyWord, BigDecimal lowestPrice,BigDecimal highestPrice,Integer shopId);

    void insert(Product product);
    void updateById(Product product);
    void deleteById(Integer id);

    Page<Product> selectForProductManage(String searchCategory, String searchText, String orderedByPrice, String status,int currentPage, int pageSize);
}
