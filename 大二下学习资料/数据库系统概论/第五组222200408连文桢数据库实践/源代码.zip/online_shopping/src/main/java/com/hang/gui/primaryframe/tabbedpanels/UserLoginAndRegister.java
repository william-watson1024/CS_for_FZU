package com.hang.gui.primaryframe.tabbedpanels;

import com.hang.entity.User;
import com.hang.gui.primaryframe.tabbedpanels.registerframes.UserRegisterFrame;
import com.hang.gui.userframe.UserFrame;
import com.hang.service.UserService;
import com.hang.service.impl.UserServiceImpl;
import com.hang.utils.CheckCodeUtil;
import com.hang.utils.ImageUtils;
import lombok.extern.slf4j.Slf4j;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.net.URL;

@Slf4j
public class UserLoginAndRegister extends JPanel {
    private String avatarDefaultPath = "image/avatar/user/default.png";

    private UserService userService = new UserServiceImpl();
    private String checkCode;


    JLabel avatarLabel = new JLabel();
    JPanel avatarPanel = new JPanel();

    JLabel idLabel = new JLabel("账号:");
    JTextField idText = new JTextField(10);

    JLabel passwordLabel = new JLabel("密码:");
    JPasswordField passwordText = new JPasswordField(10);

    JButton checkCodeButton = new JButton();
    JTextField checkCodeField = new JTextField(8);
    JPanel checkCodePanel = new JPanel();

    JButton loginButton = new JButton("登录");
    JButton registerButton = new JButton("注册");
    JPanel buttonPanel = new JPanel();



    public UserLoginAndRegister() {
        setLayout(new GridBagLayout());

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5, 5, 5, 5);


        // 第1行：头像
        c.gridy = 0;

        avatarLabel.setSize(150,150);
        ImageUtils.setLabelIcon(avatarLabel,avatarDefaultPath);

        avatarPanel.add(avatarLabel);
        avatarPanel.setOpaque(false);

        c.gridx = 0;
        c.gridwidth = 2;
        add(avatarPanel, c);

        // 第2行：账号
        c.gridy = 1;

        c.gridx = 0;
        c.gridwidth = 1;
        add(idLabel, c);

        c.gridx = 1;
        add(idText, c);

        idText.getDocument().addDocumentListener((new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                updateLabel();
            }
            @Override
            public void removeUpdate(DocumentEvent e) {
                updateLabel();
            }
            @Override
            public void changedUpdate(DocumentEvent e) {
                updateLabel();
            }
            // 更新标签文本的方法
            private void updateLabel() {
                User user = userService.selectById(idText.getText());
                if(user==null){
                    SwingUtilities.invokeLater(()->{
                        ImageUtils.setLabelIcon(avatarLabel,avatarDefaultPath);
                    });
                }else{
                    SwingUtilities.invokeLater(()->{
                        String avatarPath = "image/avatar/user/" + user.getAvatar();
                        ImageUtils.setLabelIcon(avatarLabel,avatarPath);
                    });
                }
            }
        }));

        // 第3行：密码
        c.gridy = 2;

        c.gridx = 0;
        add(passwordLabel, c);

        c.gridx = 1;
        add(passwordText, c);

        // 第4行：验证码panel
        c.gridy = 3;

        checkCodeField.setPreferredSize(new Dimension(180, 45));

        checkCodeButton.addActionListener(e -> {
            checkCode = CheckCodeUtil.setButtonIconAndReturnCheckCode(checkCodeButton);
        });

        checkCodePanel.setOpaque(false);

        checkCodePanel.add(checkCodeField);
        checkCodePanel.add(checkCodeButton);

        checkCode = CheckCodeUtil.setButtonIconAndReturnCheckCode(checkCodeButton);

        c.gridx = 0;
        c.gridwidth = 2;
        add(checkCodePanel, c);


        // 设置登录注册panel
        c.gridx = 0;
        c.gridy = 4;
        c.gridwidth = 2;

        buttonPanel.setOpaque(false);

        add(buttonPanel, c);

        buttonPanel.add(loginButton);
        buttonPanel.add(registerButton);

        loginButton.addActionListener(e -> {
            User user = userService.selectById(idText.getText());
            if (!checkCode.equalsIgnoreCase(checkCodeField.getText())) {
                JOptionPane.showMessageDialog(this, "验证码错误");
            } else if (user == null) {
                JOptionPane.showMessageDialog(this, "用户不存在");
            }else if ("禁用".equals(user.getStatus())) {
                JOptionPane.showMessageDialog(this, "账号已被禁用");
            }  else if (!user.getPassword().equals(passwordText.getText())) {
                JOptionPane.showMessageDialog(this, "密码错误");
            } else {
                SwingUtilities.invokeLater(() -> {
                    new UserFrame(user);
                });
            }
            checkCode = CheckCodeUtil.setButtonIconAndReturnCheckCode(checkCodeButton);
        });

        registerButton.addActionListener(e -> {
            SwingUtilities.invokeLater(UserRegisterFrame::new);
            checkCode = CheckCodeUtil.setButtonIconAndReturnCheckCode(checkCodeButton);
        });

//        idText.setText("user");
//        passwordText.setText("123456");
//        checkCodeField.setText(checkCode);
    }


    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        String backgroundPath = "image/background/user_login_register.jpg";
        ImageUtils.drawBackground(backgroundPath,g,this);
    }


}
