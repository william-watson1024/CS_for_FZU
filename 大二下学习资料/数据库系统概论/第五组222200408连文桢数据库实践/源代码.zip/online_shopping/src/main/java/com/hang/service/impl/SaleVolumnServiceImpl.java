package com.hang.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.hang.entity.SaleVolumn;
import com.hang.mapper.SaleVolumnMapper;
import com.hang.mybatisplusmapper.SaleVolumnMybatisPlusMapper;
import com.hang.service.SaleVolumnService;
import com.hang.utils.MybatisPlusSqlSessionFactoryUtil;
import com.hang.utils.SqlSessionFactoryUtil;
import org.apache.ibatis.session.*;
import org.apache.ibatis.session.defaults.DefaultSqlSessionFactory;

import java.sql.Connection;
import java.util.List;

public class SaleVolumnServiceImpl implements SaleVolumnService {
    private SqlSessionFactory mybatispulsSqlSessionFactory = MybatisPlusSqlSessionFactoryUtil.getMybatisPlusSqlSessionFactory();

    SqlSessionFactory sqlSessionFactory = SqlSessionFactoryUtil.getSqlSessionFactory();

    @Override
    public void insert(SaleVolumn saleVolumn) {
        SqlSession sqlSession = mybatispulsSqlSessionFactory.openSession();
        SaleVolumnMybatisPlusMapper mapper = sqlSession.getMapper(SaleVolumnMybatisPlusMapper.class);
        mapper.insert(saleVolumn);
        sqlSession.commit();
        sqlSession.close();
    }

    @Override
    public List<SaleVolumn> selectByShopId(Integer shopId) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        SaleVolumnMapper mapper = sqlSession.getMapper(SaleVolumnMapper.class);
        List<SaleVolumn> saleVolumns = mapper.selectByShopId(shopId);

        sqlSession.close();
        return saleVolumns;
    }
}
