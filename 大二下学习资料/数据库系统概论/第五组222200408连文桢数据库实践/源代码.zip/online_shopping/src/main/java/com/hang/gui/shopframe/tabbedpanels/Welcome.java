package com.hang.gui.shopframe.tabbedpanels;

import com.hang.entity.Admin;
import com.hang.entity.Shop;
import com.hang.utils.ImageUtils;

import javax.swing.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Welcome extends JPanel {
    public Welcome(Shop shop){
        setLayout(new GridBagLayout());

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(30,30,30,30);

        // 创建 SimpleDateFormat 对象并指定日期格式
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy年M月d日");

        // 获取当前日期
        Date today = new Date();

        // 格式化日期并输出
        String formattedDate = dateFormat.format(today);


        c.gridx = 0;
        c.gridy = 0;
        JLabel welcomeLabel = new JLabel("欢迎来到"+shop.getShopName()+"店铺");
        welcomeLabel.setFont(new Font("黑体",Font.BOLD,40));
        add(welcomeLabel,c);

        c.gridx = 0;
        c.gridy = 1;
        JLabel dateLabel = new JLabel("今天是" + formattedDate, JLabel.CENTER);
        dateLabel.setFont(new Font("微软雅黑",Font.BOLD,30));
        add(dateLabel,c);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        String backgroundPath = "image/background/shop_welcome.jpg";
        ImageUtils.drawBackground(backgroundPath,g,this);
    }
}
