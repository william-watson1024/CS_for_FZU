package com.hang.gui.shopframe.tabbedpanels;

import javax.swing.*;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;

// 日期选择Panel，用于GUI界面选择日期
public class DatePicker extends JPanel {
    private JSpinner spinner;

    // Default constructor
    public DatePicker() {
        this(LocalDate.now());
    }

    // Constructor with default date
    public DatePicker(LocalDate defaultDate) {
        spinner = new JSpinner(new SpinnerDateModel(Date.from(defaultDate.atStartOfDay(ZoneId.systemDefault()).toInstant()), null, null, Calendar.DAY_OF_MONTH));
        spinner.setEditor(new JSpinner.DateEditor(spinner, "yyyy/MM/dd"));
        this.add(spinner);
    }

    public LocalDate getSelectedDate() {
        return ((SpinnerDateModel) spinner.getModel()).getDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }
}
