package com.hang.gui.userframe.tabbedpanels;

import com.hang.entity.*;
import com.hang.gui.userframe.UserFrame;
import com.hang.service.AddressBookService;
import com.hang.service.ProductService;
import com.hang.service.ShopService;
import com.hang.service.ShoppingCartItemService;
import com.hang.service.impl.AddressBookServiceImpl;
import com.hang.service.impl.ProductServiceImpl;
import com.hang.service.impl.ShopServiceImpl;
import com.hang.service.impl.ShoppingCartItemServiceImpl;
import com.hang.utils.ImageUtils;
import com.hang.utils.TableUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import static com.hang.gui.userframe.tabbedpanels.ViewProductComments.createProductComment;
import static com.hang.gui.userframe.tabbedpanels.ViewProductDetails.createProductDetails;

public class Shopping extends JPanel {
    private ProductService productService = new ProductServiceImpl();
    private ShopService shopService = new ShopServiceImpl();
    private ShoppingCartItemService shoppingCartItemService = new ShoppingCartItemServiceImpl();
    private AddressBookService addressService = new AddressBookServiceImpl();

    private JTable table = new JTable();
    private List<Product> products = null;
    private List<Product> cart = new ArrayList<>(); // 购物车
    private ShoppingCartPanel shoppingCartPanel; // 添加ShoppingCartPanel的实例
    public Shopping(User user) {
        setLayout(new BorderLayout());
        // 创建滚动面板并将表格添加到其中
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        setSelectConditionPanel(user);
        // showTable("", BigDecimal.ZERO, new BigDecimal("1000"), "全部", "全部");
    }

    private void setSelectConditionPanel(User user) {
        JPanel selectConditionPanel = new JPanel(new FlowLayout());

        selectConditionPanel.add(new JLabel("关键词: "));

        JTextField inputField = new JTextField(10);
        selectConditionPanel.add(inputField);

        JComboBox<String> classifyBox = new JComboBox<>();
        JComboBox<String> brandBox = new JComboBox<>();

        // 获取所有产品的分类和品牌
        products = productService.selectByConditions("", BigDecimal.ZERO, new BigDecimal("1000"));
        Set<String> classifications = products.stream().map(Product::getType).collect(Collectors.toSet());
        Set<String> brands = products.stream().map(Product::getBrand).collect(Collectors.toSet());

        classifyBox.addItem("全部");
        classifications.forEach(classifyBox::addItem);
        selectConditionPanel.add(new JLabel("分类: "));
        selectConditionPanel.add(classifyBox);

        brandBox.addItem("全部");
        brands.forEach(brandBox::addItem);
        selectConditionPanel.add(new JLabel("品牌: "));
        selectConditionPanel.add(brandBox);

        selectConditionPanel.add(new JLabel("价格区间:"));

        JTextField lowestPriceField = new JTextField("0", 4);
        selectConditionPanel.add(lowestPriceField);

        selectConditionPanel.add(new JLabel("-"));

        JTextField highestPriceField = new JTextField("1000", 4);
        selectConditionPanel.add(highestPriceField);

        JButton searchButton = new JButton("搜索");
        selectConditionPanel.add(searchButton);

        JButton commentButton = new JButton("查看评论");
        selectConditionPanel.add(commentButton);

        JButton allInformationButton = new JButton("查看详情");
        selectConditionPanel.add(allInformationButton);

        JButton addToCartButton = new JButton("添加到购物车");
        selectConditionPanel.add(addToCartButton);

        //查看评论
        commentButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                createProductComment(products.get(selectedRow), user);
            } else {
                Component userFrames = null;
                JOptionPane.showMessageDialog(userFrames, "未选择任何商品！", "提示", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        //查看详情
        allInformationButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                createProductDetails(products.get(selectedRow));
            } else {
                Component userFrames = null;
                JOptionPane.showMessageDialog(userFrames, "未选择任何商品！", "提示", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        //添加到购物车
        addToCartButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                AddressBook addresses = addressService.selectDefaultByUserId(user.getUserId());
                Product selectedProduct = products.get(selectedRow);
                cart.add(selectedProduct);
                ShoppingCartItem shoppingCartItem = new ShoppingCartItem();
                shoppingCartItem.setUserId(user.getUserId());
                shoppingCartItem.setProductId(selectedProduct.getProductId());
                shoppingCartItem.setNumber(1);
                shoppingCartItem.setAddDatetime(LocalDateTime.now());
                shoppingCartItem.setRemark("添加商品到购物车");
                shoppingCartItem.setAddressBookId(addresses.getAddressBookId());
                shoppingCartItemService.insert(shoppingCartItem);
                JOptionPane.showMessageDialog(this, selectedProduct.getName() + " 已添加到购物车", "添加成功", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "未选择任何商品！", "提示", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        searchButton.addActionListener(e -> {
            BigDecimal lowestPrice = BigDecimal.valueOf(Double.parseDouble(lowestPriceField.getText()));
            BigDecimal highestPrice = BigDecimal.valueOf(Double.parseDouble(highestPriceField.getText()));
            String selectedClassification = (String) classifyBox.getSelectedItem();
            String selectedBrand = (String) brandBox.getSelectedItem();
            showTable(inputField.getText(), lowestPrice, highestPrice, selectedClassification, selectedBrand);
        });

        add(selectConditionPanel, BorderLayout.NORTH);
    }

    private void showTable(String keyWord, BigDecimal lowestPrice, BigDecimal highestPrice, String classification, String brand) {
        this.products = productService.selectByConditions(keyWord, lowestPrice, highestPrice);

        // 根据分类和品牌过滤产品
        if (!classification.equals("全部")) {
            products = products.stream().filter(p -> p.getType().equals(classification)).collect(Collectors.toList());
        }
        if (!brand.equals("全部")) {
            products = products.stream().filter(p -> p.getBrand().equals(brand)).collect(Collectors.toList());
        }

        // 定义列名
        String[] columnNames = {"照片", "商品名", "品牌","类别", "店铺名", "价格"};

        // 创建一个二维 Object 数组，行数为产品数量，列数为 6
        Object[][] data = new Object[products.size()][6];

        TableUtils.setTableStyle(table);

        // 遍历产品列表，将每个产品的信息填充到 Object 数组中
        for (int i = 0; i < products.size(); i++) {
            Product product = products.get(i);
            Shop shop = shopService.selectById(product.getShopId());
            String shopName = shop.getShopName();

            String path = "image/product/" + product.getPhoto();
            ImageIcon icon = ImageUtils.getProductImageIcon(150, 150, path);

            data[i][0] = icon;
            data[i][1] = product.getName();
            data[i][2] = product.getBrand();
            data[i][3] = product.getType();
            data[i][4] = shopName;
            data[i][5] = product.getPrice();
        }

        // 创建表格模型
        DefaultTableModel model = new DefaultTableModel(data, columnNames) {
            @Override
            public Class<?> getColumnClass(int column) {
                if (column == 0) {
                    return ImageIcon.class;
                } else {
                    return String.class;
                }
            }
        };

        table.setModel(model);

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);

        // 将渲染器应用于所有列
        for (int i = 1; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }

        table.setRowHeight(150);
    }
}
