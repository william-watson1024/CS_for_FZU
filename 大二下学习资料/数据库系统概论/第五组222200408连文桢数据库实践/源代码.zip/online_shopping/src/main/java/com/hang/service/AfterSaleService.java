package com.hang.service;

import com.hang.entity.AfterSale;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface AfterSaleService {
    List<AfterSale> selectAll();

    AfterSale selectById(Integer id);

    List<AfterSale> selectByShopId(Integer shopId);

    void insert(AfterSale afterSale);

    void updateById(AfterSale afterSale);

    void deleteById(Integer id);
}
