package com.hang.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.hang.entity.Seller;
import com.hang.mapper.SellerMapper;
import com.hang.mybatisplusmapper.SellerMybatisPlusMapper;
import com.hang.service.SellerService;
import com.hang.utils.MybatisPlusSqlSessionFactoryUtil;
import com.hang.utils.SqlSessionFactoryUtil;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.List;

public class SellerServiceImpl implements SellerService {
    private SqlSessionFactory sqlSessionFactory = SqlSessionFactoryUtil.getSqlSessionFactory();
    private SqlSessionFactory mybatispulsSqlSessionFactory = MybatisPlusSqlSessionFactoryUtil.getMybatisPlusSqlSessionFactory();

    @Override
    public List<Seller> selectAll() {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        SellerMapper mapper = sqlSession.getMapper(SellerMapper.class);
        List<Seller> sellers = mapper.selectAll();
        sqlSession.close();

        return sellers;
    }

    @Override
    public Seller selectById(String id) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        SellerMapper mapper = sqlSession.getMapper(SellerMapper.class);
        Seller seller = mapper.selectById(id);
        sqlSession.close();

        return seller;
    }

    @Override
    public void insert(Seller newSeller) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        SellerMapper mapper = sqlSession.getMapper(SellerMapper.class);
        mapper.insert(newSeller);
        sqlSession.commit();

        sqlSession.close();
    }

    @Override
    public void updateById(Seller seller) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        SellerMapper mapper = sqlSession.getMapper(SellerMapper.class);
        mapper.updateById(seller);
        sqlSession.commit();
        sqlSession.close();
    }

    @Override
    public void deleteById(String sellerId) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        SellerMapper mapper = sqlSession.getMapper(SellerMapper.class);
        mapper.deleteById(sellerId);
        sqlSession.commit();
        sqlSession.close();
    }

    @Override
    public List<Seller> selectByConditions(String searchText, String status, String ordered) {
        SqlSession sqlSession = mybatispulsSqlSessionFactory.openSession();
        SellerMybatisPlusMapper mapper = sqlSession.getMapper(SellerMybatisPlusMapper.class);
        LambdaQueryWrapper<Seller> lambdaQueryWrapper = new LambdaQueryWrapper<>();

        if (!"全部".equals(status)) {
            lambdaQueryWrapper.eq(Seller::getStatus, status);
        }
        if ("升序".equals(ordered)) {
            lambdaQueryWrapper.orderByAsc(Seller::getCreditLevel);
        } else if ("降序".equals(ordered)) {
            lambdaQueryWrapper.orderByDesc(Seller::getCreditLevel);
        }

        lambdaQueryWrapper.and(wrapper -> wrapper.like(Seller::getName, searchText)
                .or().like(Seller::getSellerId, searchText));

        List<Seller> sellers = mapper.selectList(lambdaQueryWrapper);

        sqlSession.close();
        return sellers;
    }

}
