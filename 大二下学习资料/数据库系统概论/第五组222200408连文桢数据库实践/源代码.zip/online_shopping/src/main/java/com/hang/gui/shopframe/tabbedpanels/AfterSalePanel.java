package com.hang.gui.shopframe.tabbedpanels;

import com.hang.entity.AfterSale;
import com.hang.entity.Shop;
import com.hang.gui.shopframe.ShopFrame;
import com.hang.service.AfterSaleService;
import com.hang.service.impl.AfterSaleServiceImpl;
import com.hang.service.impl.ProductServiceImpl;
import com.hang.utils.TableUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

public class AfterSalePanel extends JPanel {

    private AfterSaleService afterSaleService = new AfterSaleServiceImpl();
    private com.hang.service.ProductService ProductService = new ProductServiceImpl();
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private DefaultTableModel model;
    private JTable table;

    public AfterSalePanel(Shop shop, ShopFrame shopFrame) {
        JPanel searchPanel = new JPanel();
        setLayout(new BorderLayout());
        add(searchPanel, BorderLayout.NORTH);

        JComboBox<String> searchComboBox = new JComboBox<>();
        searchComboBox.addItem("售后类型");
        searchComboBox.addItem("售后状态");
        searchPanel.add(searchComboBox);

        JComboBox<String> sortComboBox = new JComboBox<>();
        sortComboBox.addItem("升序");
        sortComboBox.addItem("降序");
        searchPanel.add(sortComboBox);

        JLabel orderLabel = new JLabel("订单号：");
        JTextField orderTextField = new JTextField(10);
        searchPanel.add(orderLabel);
        searchPanel.add(orderTextField);

        JButton searchButton = new JButton("搜索");
        searchButton.addActionListener(e -> {
            String searchChoice = (String) searchComboBox.getSelectedItem();
            String sortChoice = (String) sortComboBox.getSelectedItem();
            String orderId = orderTextField.getText();
            updateTableModel(searchChoice, sortChoice, orderId, shop);
        });
        searchPanel.add(searchButton);
        searchPanel.setVisible(true);

        table = createTable(null, null, null, shop);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        JButton dealButton = new JButton("处理售后");
        buttonPanel.add(dealButton);
        add(buttonPanel, BorderLayout.SOUTH);

        dealButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                AfterSale selectedAfterSale = afterSaleService.selectById(Integer.parseInt(table.getValueAt(selectedRow, 0).toString()));
                new AfterSaleDialog(shopFrame, selectedAfterSale).setVisible(true);
                // Assuming that AfterSaleDialog updates the status of the selectedAfterSale
                updateTableModel(null, null, null, shop);
            } else {
                JOptionPane.showMessageDialog(this, "未选择任何售后！");
            }
        });
    }

    JTable createTable(String choice, String sort, String orderId,Shop shop) {
        List<AfterSale> afterSales = afterSaleService.selectByShopId(shop.getShopId());
        if (orderId != null && !orderId.trim().isEmpty()) {
            afterSales = afterSales.stream()
                    .filter(afterSale -> afterSale.getOrderId().toString().contains(orderId))
                    .collect(Collectors.toList());
        }

        if (choice != null && choice.equals("售后类型")) {
            afterSales.sort((a1, a2) -> {
                if (sort.equals("升序")) {
                    return a1.getRequestType().compareTo(a2.getRequestType());
                } else {
                    return a2.getRequestType().compareTo(a1.getRequestType());
                }
            });
        } else if (choice != null && choice.equals("售后状态")) {
            afterSales.sort((a1, a2) -> {
                if (sort.equals("升序")) {
                    return a1.getStatus().compareTo(a2.getStatus());
                } else {
                    return a2.getStatus().compareTo(a1.getStatus());
                }
            });
        }

        model = new DefaultTableModel();
        model.addColumn("售后单号");
        model.addColumn("订单号");
        model.addColumn("请求类型");
        model.addColumn("原因");
        model.addColumn("处理状态");
        model.addColumn("请求时间");
        model.addColumn("完成时间");

        for (AfterSale afterSale : afterSales) {
            if (!"未处理".equals(afterSale.getStatus())) {
                model.addRow(new Object[]{
                        afterSale.getAfterSaleId(),
                        afterSale.getOrderId(),
                        afterSale.getRequestType(),
                        afterSale.getReason(),
                        afterSale.getStatus(),
                        afterSale.getRequestTime().format(formatter),
                        afterSale.getSolvedTime().format(formatter),
                });
            } else {
                model.addRow(new Object[]{
                        afterSale.getAfterSaleId(),
                        afterSale.getOrderId(),
                        afterSale.getRequestType(),
                        afterSale.getReason(),
                        afterSale.getStatus(),
                        afterSale.getRequestTime().format(formatter),
                        "未处理",
                });
            }
        }

        JTable table = new JTable(model);
        TableUtils.setTableStyle(table);
        table.setRowHeight(30);
        return table;
    }

    void updateTableModel(String choice, String sort, String orderId,Shop shop) {
        List<AfterSale> afterSales = afterSaleService.selectByShopId(shop.getShopId());
        // Filtering and sorting logic
        if (orderId != null && !orderId.trim().isEmpty()) {
            afterSales = afterSales.stream()
                    .filter(afterSale -> afterSale.getOrderId().toString().contains(orderId))
                    .collect(Collectors.toList());
        }

        if (choice != null && choice.equals("售后类型")) {
            afterSales.sort((a1, a2) -> {
                if (sort.equals("升序")) {
                    return a1.getRequestType().compareTo(a2.getRequestType());
                } else {
                    return a2.getRequestType().compareTo(a1.getRequestType());
                }
            });
        } else if (choice != null && choice.equals("售后状态")) {
            afterSales.sort((a1, a2) -> {
                if (sort.equals("升序")) {
                    return a1.getStatus().compareTo(a2.getStatus());
                } else {
                    return a2.getStatus().compareTo(a1.getStatus());
                }
            });
        }

        model.setRowCount(0); // Clear the existing rows

        for (AfterSale afterSale : afterSales) {
            if (!"未处理".equals(afterSale.getStatus())) {
                model.addRow(new Object[]{
                        afterSale.getAfterSaleId(),
                        afterSale.getOrderId(),
                        afterSale.getRequestType(),
                        afterSale.getReason(),
                        afterSale.getStatus(),
                        afterSale.getRequestTime().format(formatter),
                        afterSale.getSolvedTime().format(formatter),
                });
            } else {
                model.addRow(new Object[]{
                        afterSale.getAfterSaleId(),
                        afterSale.getOrderId(),
                        afterSale.getRequestType(),
                        afterSale.getReason(),
                        afterSale.getStatus(),
                        afterSale.getRequestTime().format(formatter),
                        "未处理",
                });
            }
        }

        model.fireTableDataChanged(); // Notify the table that the model has been updated
    }
}
