package com.hang.service.impl;

import com.hang.entity.Comment;
import com.hang.mapper.CommentMapper;
import com.hang.service.CommentService;
import com.hang.utils.SqlSessionFactoryUtil;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.List;

public class CommentServiceImpl implements CommentService {
    private SqlSessionFactory sqlSessionFactory = SqlSessionFactoryUtil.getSqlSessionFactory();

    @Override
    public List<Comment> selectAll() {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        CommentMapper mapper = sqlSession.getMapper(CommentMapper.class);

        List<Comment> comments = mapper.selectAll();

        sqlSession.commit();
        sqlSession.close();

        return comments;
    }

    @Override
    public Comment selectById(Integer id) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        CommentMapper mapper = sqlSession.getMapper(CommentMapper.class);

        Comment comment = mapper.selectById(id);

        sqlSession.close();

        return comment;
    }

    @Override
    public List<Comment> selectByProductId(Integer productId) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        CommentMapper mapper = sqlSession.getMapper(CommentMapper.class);

        List<Comment> comments = mapper.selectByProductId(productId);

        sqlSession.close();

        return comments;
    }

    @Override
    public void insert(Comment comment) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        CommentMapper mapper = sqlSession.getMapper(CommentMapper.class);

        mapper.insert(comment);

        sqlSession.commit();
        sqlSession.close();
    }

    @Override
    public void updateById(Comment comment) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        CommentMapper mapper = sqlSession.getMapper(CommentMapper.class);

        mapper.updateById(comment);

        sqlSession.commit();
        sqlSession.close();
    }

    @Override
    public void deleteById(Integer id) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        CommentMapper mapper = sqlSession.getMapper(CommentMapper.class);

        mapper.deleteById(id);

        sqlSession.commit();
        sqlSession.close();
    }
}
