package com.hang.mapper;

import com.hang.entity.Admin;
import com.hang.entity.Comment;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface CommentMapper {
    @Select("select * from `comment`")
    List<Comment> selectAll();

    @Select("select * from `comment` where comment_id=#{id}")
    Comment selectById(Integer id);

    @Select("select * from `comment` where product_id=#{productId}")
    List<Comment> selectByProductId(Integer productId);

    @Insert("insert into `comment`(user_id, product_id, content, post_time, likes) VALUES (#{userId},#{productId},#{content},#{postTime},#{likes})")
    void insert(Comment comment);

    @Update("update `comment` set content=#{content},likes=#{likes} where comment_id=#{commentId} ")
    void updateById(Comment comment);

    @Delete("delete from `comment` where comment_id=#{id} ")
    void deleteById(Integer id);
}
