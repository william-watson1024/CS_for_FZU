package com.hang.entity;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 店铺表
 * </p>
 *
 * @author hang
 * @since 2024-05-23
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class Shop implements Serializable {


    /**
     * 主键 自动生成
     */
    @TableId(value = "shop_id", type = IdType.AUTO)
    private Integer shopId;

    /**
     * 归属商家
     */
    private String sellerId;

    /**
     * 店铺名
     */
    private String shopName;

    /**
     * 店铺照片
     */
    private String photo;

    /**
     * 店铺描述
     */
    private String shopDescription;

    /**
     * 商业执照号
     */
    private String businessLicense;

    /**
     * 法人
     */
    private String legalPerson;

    /**
     * 认证状态 (审核中|已通过|未通过) 默认:审核中
     */
    private String verifyStatus;

    /**
     * 店铺营业额
     */
    private BigDecimal shopRevenue;


}
