package com.hang.entity;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 商品表
 * </p>
 *
 * @author hang
 * @since 2024-05-23
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class Product implements Serializable {


    /**
     * 主键 自增长
     */
    @TableId(value = "product_id", type = IdType.AUTO)
    private Integer productId;

    /**
     * 归属店铺
     */
    private Integer shopId;

    /**
     * 商品名称
     */
    private String name;

    /**
     * 品牌
     */
    private String brand;

    /**
     * 商品详细描述
     */
    private String description;

    /**
     * 价格
     */
    private BigDecimal price;

    /**
     * 类型
     */
    private String type;

    /**
     * 商品关键词
     */
    private String keyWords;

    /**
     * 库存数量
     */
    private Integer stock;

    /**
     * 销量
     */
    private Integer salesVolume;

    /**
     * 重量
     */
    private BigDecimal weight;

    /**
     * 商品尺寸
     */
    private String size;

    /**
     * 照片
     */
    private String photo;

    /**
     * 状态 (在售|缺货|已下架) 默认:在售
     */
    private String status;


}
