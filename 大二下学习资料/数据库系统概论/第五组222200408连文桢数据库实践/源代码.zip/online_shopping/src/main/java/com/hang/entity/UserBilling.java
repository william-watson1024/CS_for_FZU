package com.hang.entity;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.IdType;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 
 * </p>
 *
 * @author hang
 * @since 2024-05-23
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class UserBilling implements Serializable {


    /**
     * 主键 自增长
     */
    @TableId(value = "user_billing_id", type = IdType.NONE)
    private Integer userBillingId;

    /**
     * 外键 归属用户
     */
    private String userId;

    /**
     * 变动金额
     */
    private BigDecimal changeBalance;

    /**
     * 描述
     */
    private String description;

    /**
     * 变动时间
     */
    private LocalDateTime changeTime;


}
