package com.hang.mybatisplusmapper;

import com.hang.entity.Admin;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 管理员表 Mapper 接口
 * </p>
 *
 * @author hang
 * @since 2024-05-25
 */
public interface AdminMybatisPlusMapper extends BaseMapper<Admin> {

}
