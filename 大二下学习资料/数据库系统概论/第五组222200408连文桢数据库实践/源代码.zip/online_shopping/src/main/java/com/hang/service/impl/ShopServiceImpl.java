package com.hang.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.hang.entity.Shop;
import com.hang.mapper.ShopMapper;
import com.hang.mybatisplusmapper.ShopMybatisPlusMapper;
import com.hang.service.ShopService;
import com.hang.utils.MybatisPlusSqlSessionFactoryUtil;
import com.hang.utils.SqlSessionFactoryUtil;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.List;

public class ShopServiceImpl implements ShopService {
    private SqlSessionFactory sqlSessionFactory = SqlSessionFactoryUtil.getSqlSessionFactory();
    private SqlSessionFactory mybatispulsSqlSessionFactory = MybatisPlusSqlSessionFactoryUtil.getMybatisPlusSqlSessionFactory();

    @Override
    public List<Shop> selectAll() {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ShopMapper mapper = sqlSession.getMapper(ShopMapper.class);
        List<Shop> shops = mapper.selectAll();
        sqlSession.close();

        return shops;
    }

    @Override
    public Shop selectById(Integer id) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ShopMapper mapper = sqlSession.getMapper(ShopMapper.class);
        Shop shop = mapper.selectById(id);
        sqlSession.close();

        return shop;
    }

    @Override
    public List<Shop> selectLikeShopName(String shopName) {
        shopName = "%"+shopName+"%";

        SqlSession sqlSession = sqlSessionFactory.openSession();
        ShopMapper mapper = sqlSession.getMapper(ShopMapper.class);
        List<Shop> shops = mapper.selectLikeShopName(shopName);
        sqlSession.close();

        return shops;
    }

    @Override
    public List<Shop> selectBySellerId(String sellerId) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ShopMapper mapper = sqlSession.getMapper(ShopMapper.class);
        List<Shop> shops = mapper.selectBySellerId(sellerId);
        sqlSession.close();

        return shops;
    }

    @Override
    public void insert(Shop shop) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ShopMapper mapper = sqlSession.getMapper(ShopMapper.class);
        mapper.insert(shop);
        sqlSession.commit();
        sqlSession.close();
    }

    @Override
    public void updateById(Shop shop) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ShopMapper mapper = sqlSession.getMapper(ShopMapper.class);
        mapper.updateById(shop);
        sqlSession.commit();
        sqlSession.close();
    }

    @Override
    public void deleteById(Integer id) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ShopMapper mapper = sqlSession.getMapper(ShopMapper.class);
        mapper.deleteById(id);
        sqlSession.commit();
        sqlSession.close();
    }

    @Override
    public List<Shop> selectByConditions(String status, String searchText) {
        SqlSession sqlSession = mybatispulsSqlSessionFactory.openSession();
        ShopMybatisPlusMapper mapper = sqlSession.getMapper(ShopMybatisPlusMapper.class);
        LambdaQueryWrapper<Shop> lambdaQueryWrapper = new LambdaQueryWrapper<>();
        if(!"全部".equals(status)){
            lambdaQueryWrapper.eq(Shop::getVerifyStatus,status);
        }


        lambdaQueryWrapper.and(w->w.like(Shop::getShopName,searchText)
                .or().like(Shop::getSellerId,searchText));
        List<Shop> shops = mapper.selectList(lambdaQueryWrapper);
        sqlSession.close();

        return shops;
    }
}
