package com.hang.mapper;

import com.hang.entity.Order;
import org.apache.ibatis.annotations.*;

import java.time.LocalDateTime;
import java.util.List;

public interface OrderMapper {
    @Select("select * from `order`")
    List<Order> selectAll();

    @Select("select * from `order` where order_id=#{id}")
    Order selectById(Integer id);

    @Select("select * from `order` where user_id=#{userId}")
    List<Order> selectByUserId(String userId);

    @Select("select * from `order` o " +
            "join product p on o.product_id = p.product_id " +
            "where p.shop_id = #{shopId}")
    List<Order> selectByShopId(Integer shopId);


    @Select("select * from `order` where order_create_datetime between #{begin} and #{end}")
    List<Order> selectBetweenDatetime(@Param("begin") LocalDateTime begin, @Param("end") LocalDateTime end);

    @Insert("insert into `order`(order_id, user_id, product_id, address_book_id, product_number, order_create_datetime, payment_datetime, total_amount, payment_status, delivery_status, remark) VALUES (null,#{userId},#{productId},#{addressBookId},#{productNumber},#{orderCreateDatetime},#{paymentDatetime},#{totalAmount},#{paymentStatus},#{deliveryStatus},#{remark})")
    void insert(Order order);

    @Update("update `order` set address_book_id=#{addressBookId},product_id=#{productNumber},payment_datetime=#{paymentDatetime},total_amount=#{totalAmount},payment_status=#{paymentStatus},delivery_status=#{deliveryStatus},remark=#{remark} where order_id=#{orderId}")
    void updateById(Order order);

    @Delete("delete from `order` where order_id=#{id}")
    void deleteById(Integer id);
}
