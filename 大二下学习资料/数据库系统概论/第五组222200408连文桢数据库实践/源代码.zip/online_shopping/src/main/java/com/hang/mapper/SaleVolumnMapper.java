package com.hang.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hang.entity.SaleVolumn;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author hang
 * @since 2024-06-26
 */
public interface SaleVolumnMapper{
    @Select("select sale_volumn.* from sale_volumn, product where sale_volumn.product_id = product.product_id and shop_id = #{shopId}")
    List<SaleVolumn> selectByShopId(Integer shopId);
}
