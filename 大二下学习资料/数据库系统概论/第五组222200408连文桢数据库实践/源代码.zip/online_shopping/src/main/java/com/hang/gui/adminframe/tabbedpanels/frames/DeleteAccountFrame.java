package com.hang.gui.adminframe.tabbedpanels.frames;


import com.hang.entity.Admin;
import com.hang.service.AdminService;
import com.hang.service.impl.AdminServiceImpl;
import com.hang.utils.PasswordUtil;

import javax.swing.*;
import java.awt.*;

public class DeleteAccountFrame extends JFrame {
    private AdminService adminService = new AdminServiceImpl();

    JPanel contentPanel = new JPanel(new GridBagLayout());

    JLabel infoLabel = new JLabel("此操作将永久注销账号，请谨慎操作！");

    JLabel passwordLabel = new JLabel("输入密码:");
    JPasswordField passwordField = new JPasswordField(12);

    JButton confirmButton = new JButton("确认注销");
    JPanel confirmPanel = new JPanel();


    public DeleteAccountFrame(Admin admin, JFrame adminFrame) {
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5, 5, 5, 5);

        // 第1行：提示
        c.gridy = 0;

        c.gridx = 0;
        c.gridwidth = 2;
        contentPanel.add(infoLabel,c);

        // 第2行：输入密码panel
        c.gridy = 1;

        c.gridx = 0;
        c.gridwidth = 1;
        contentPanel.add(passwordLabel,c);

        c.gridx = 1;
        contentPanel.add(passwordField,c);

        // 第3行：确认按钮panel
        c.gridy = 2;

        confirmPanel.add(confirmButton);

        c.gridx = 0;
        c.gridwidth = 2;
        contentPanel.add(confirmPanel,c);

        confirmButton.addActionListener(e -> {
            if (PasswordUtil.checkPassword(passwordField.getText(),admin.getPassword())) {
                adminService.deleteById(admin.getAdminId());
                JOptionPane.showMessageDialog(this, "注销成功");
                this.dispose();
                adminFrame.dispose();
            }else{
                JOptionPane.showMessageDialog(this, "密码错误");
            }
        });

        setTitle("注销账号");
        add(contentPanel);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
