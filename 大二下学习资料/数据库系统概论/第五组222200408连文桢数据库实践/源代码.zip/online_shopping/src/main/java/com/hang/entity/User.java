package com.hang.entity;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.IdType;
import java.time.LocalDate;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 用户表
 * </p>
 *
 * @author hang
 * @since 2024-05-23
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class User implements Serializable {


    /**
     * 账号
     */
    @TableId(value = "user_id", type = IdType.NONE)
    private String userId;

    /**
     * 密码
     */
    private String password;

    /**
     * 昵称
     */
    private String nickname;

    /**
     * 手机号
     */
    private String phoneNumber;

    /**
     * 余额
     */
    private BigDecimal balance;

    /**
     * 信用等级 [1-5] 默认:3
     */
    private Integer creditLevel;

    /**
     * 状态 (正常|禁用) 默认:正常
     */
    private String status;

    /**
     * 注册日期
     */
    private LocalDate registerDate;

    /**
     * 头像
     */
    private String avatar;

    /**
     * 邮箱
     */
    private String email;

    /**
     * 性别
     */
    private String gender;

    /**
     * 生日
     */
    private LocalDate birthday;


}
