package com.hang.gui.shopframe.tabbedpanels;

import com.hang.entity.Purchase;
import com.hang.entity.Shop;
import com.hang.service.PurchaseService;
import com.hang.service.impl.PurchaseServiceImpl;
import com.hang.utils.TableUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class PurchaseDetails extends JPanel {
    JTable table = new JTable();
    PurchaseService purchaseService = new PurchaseServiceImpl();
    Shop shop;
    JButton searchButton = new JButton("搜索");
    String[] options = {"时间升序","时间降序"};
    JComboBox<String> orderComboBox = new JComboBox<>(options);
    JTextField productIdField = new JTextField(8);

    public PurchaseDetails(Shop shop) {
        this.shop = shop;
        setLayout(new BorderLayout());

        add(new JScrollPane(table), BorderLayout.CENTER);
        setNorthPanel();
        setSouthPanel();

        updateTable();
    }

    JLabel sumLabel = new JLabel();

    private void setSouthPanel() {
        JPanel southPanel = new JPanel();
        southPanel.add(sumLabel);
        add(southPanel,BorderLayout.SOUTH);
    }


    DatePicker begin = new DatePicker();
    DatePicker end = new DatePicker();

    private void setNorthPanel() {
        JPanel northPanel = new JPanel();

        northPanel.add(begin);
        northPanel.add(end);
        northPanel.add(orderComboBox);
        northPanel.add(new JLabel("   商品ID"));
        northPanel.add(productIdField);

        northPanel.add(searchButton);


        searchButton.addActionListener(e->{
            updateTable();
        });

        add(northPanel, BorderLayout.NORTH);

    }

    List<Purchase> purchases;

    private void updateTable() {
        String selectString = (String) orderComboBox.getSelectedItem();
        String orderString;
        if("时间升序".equals(selectString)){
            orderString = "asc";
        }else{
            orderString = "desc";
        }

        purchases = purchaseService.selectByShopIdAndRange(begin.getSelectedDate(), end.getSelectedDate(), shop.getShopId(),orderString,productIdField.getText());


        // 创建表格模型
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("进货单号");
        model.addColumn("进货时间");
        model.addColumn("进货商品ID");
        model.addColumn("进货数量");

        int sum = 0;
        for (Purchase purchase : purchases) {
            model.addRow(new Object[]{purchase.getPurchaseId(), purchase.getPurchaseDate(), purchase.getProductId(), purchase.getCount()});
        sum+=purchase.getCount();
        }
        sumLabel.setText("进货总量: "+sum);

        // 添加数据到表格模型

        table.setModel(model);
        // 使用工具类，设置表格样式
        TableUtils.setTableStyle(table);
        TableUtils.autoResizeColumns(table);
    }

}
