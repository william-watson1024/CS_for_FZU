package com.hang.gui.adminframe.tabbedpanels;

import com.hang.entity.Admin;
import com.hang.gui.adminframe.tabbedpanels.frames.AddAdminFrame;
import com.hang.service.AdminService;
import com.hang.service.impl.AdminServiceImpl;
import com.hang.utils.TableUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;

public class AddAdmin extends JPanel {
    private final AdminService adminService = new AdminServiceImpl();

    JTable table = new JTable();


    public AddAdmin(Admin admin){
        setLayout(new BorderLayout());

        // 创建滚动面板并将表格添加到其中
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane,BorderLayout.CENTER);


        JButton addButton = new JButton("新增管理员");
        JPanel addButtonPanel = new JPanel();
        addButtonPanel.add(addButton);
        add(addButtonPanel,BorderLayout.SOUTH);

        addButton.addActionListener(e->{
            SwingUtilities.invokeLater(()->{
                new AddAdminFrame().addWindowListener(new WindowAdapter() {
                    @Override
                    public void windowClosed(WindowEvent e) {
                        showTable();
                    }
                });
            });
        });

        showTable();
    }

    private void showTable(){
        List<Admin> all = adminService.selectAll();

        // 创建表格模型
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("账号");
        model.addColumn("姓名");
        model.addColumn("手机号");
        model.addColumn("邮箱");

        // 添加数据到表格模型
        for (Admin administrator : all) {
            model.addRow(new Object[]{administrator.getAdminId(),administrator.getName(),administrator.getPhoneNumber(),administrator.getEmail()});
        }

        table.setModel(model);

        // 使用工具类，设置表格样式
        TableUtils.setTableStyle(table);
    }
}
