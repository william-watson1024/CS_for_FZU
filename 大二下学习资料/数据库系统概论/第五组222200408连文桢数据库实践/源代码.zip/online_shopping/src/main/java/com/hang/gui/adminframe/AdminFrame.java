package com.hang.gui.adminframe;

import com.hang.entity.Admin;
import com.hang.gui.adminframe.tabbedpanels.*;

import javax.swing.*;
import java.awt.*;

public class AdminFrame extends JFrame {
    public AdminFrame(Admin admin){
        setTitle("管理员："+admin.getAdminId());
//        setSize(Config.getFrameWidth(), Config.getFrameHeight());
        setExtendedState(JFrame.MAXIMIZED_BOTH);

        JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.LEFT);
        tabbedPane.addTab("欢迎", null, new Welcome(admin), "欢迎");
        tabbedPane.addTab("管理员列表", null, new AddAdmin(admin), "管理员列表");
        tabbedPane.addTab("管理商家", null, new SellerManage(), "商家列表");
        tabbedPane.addTab("管理店铺", null, new ShopManage(), "店铺列表");
        tabbedPane.addTab("管理商品", null, new ProductManage(), "商品列表");
        tabbedPane.addTab("管理订单", null, new OrderManage(), "订单列表");
        tabbedPane.addTab("管理用户", null, new UserManage(), "用户列表");
        tabbedPane.addTab("修改个人信息", null, new ChangeInformation(admin,this), "修改个人信息");


        // 将选项卡面板添加到框架
        add(tabbedPane, BorderLayout.CENTER);

        setLocationRelativeTo(null);
        setVisible(true);
    }







}
