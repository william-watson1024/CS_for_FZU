package com.hang.mybatisplusmapper;

import com.hang.entity.Product;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 商品表 Mapper 接口
 * </p>
 *
 * @author hang
 * @since 2024-05-25
 */
public interface ProductMybatisPlusMapper extends BaseMapper<Product> {

}
