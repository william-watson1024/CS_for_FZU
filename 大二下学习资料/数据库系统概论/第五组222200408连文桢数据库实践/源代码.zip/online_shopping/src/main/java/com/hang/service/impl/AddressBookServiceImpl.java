package com.hang.service.impl;

import com.hang.entity.AddressBook;
import com.hang.mapper.AddressBookMapper;
import com.hang.service.AddressBookService;
import com.hang.utils.SqlSessionFactoryUtil;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.List;



public class AddressBookServiceImpl implements AddressBookService {
    private SqlSessionFactory sqlSessionFactory = SqlSessionFactoryUtil.getSqlSessionFactory();

    @Override
    public List<AddressBook> selectByUserId(String userId) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        AddressBookMapper mapper = sqlSession.getMapper(AddressBookMapper.class);
        List<AddressBook> addresses = mapper.selectByUserId(userId);

        sqlSession.close();

        return addresses;
    }

    @Override
    public AddressBook selectDefaultByUserId(String userId) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        AddressBookMapper mapper = sqlSession.getMapper(AddressBookMapper.class);
        AddressBook addressBook = mapper.selectDefaultByUserId(userId);

        sqlSession.close();
        return addressBook;
    }

    @Override
    public void setDefaultAddressBook(Integer addressId) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        AddressBookMapper mapper = sqlSession.getMapper(AddressBookMapper.class);
        mapper.clearDefaultAddressBook();
        mapper.setDefaultAddressBook(addressId);
        sqlSession.commit();

        sqlSession.close();
    }

    @Override
    public List<AddressBook> selectAll() {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        AddressBookMapper mapper = sqlSession.getMapper(AddressBookMapper.class);
        List<AddressBook> addressBooks = mapper.selectAll();

        sqlSession.close();
        return addressBooks;
    }

    @Override
    public AddressBook selectById(Integer id) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        AddressBookMapper mapper = sqlSession.getMapper(AddressBookMapper.class);

        AddressBook addressBook = mapper.selectById(id);

        sqlSession.close();
        return addressBook;
    }

    @Override
    public void insert(AddressBook addressBook) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        AddressBookMapper mapper = sqlSession.getMapper(AddressBookMapper.class);
        mapper.insert(addressBook);

        sqlSession.commit();

        sqlSession.close();
    }

    @Override
    public void updateById(AddressBook addressBook) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        AddressBookMapper mapper = sqlSession.getMapper(AddressBookMapper.class);

       mapper.updateById(addressBook);

        sqlSession.commit();

        sqlSession.close();
    }

    @Override
    public void deleteById(Integer id) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        AddressBookMapper mapper = sqlSession.getMapper(AddressBookMapper.class);
        mapper.deleteById(id);

        sqlSession.commit();

        sqlSession.close();
    }
}
