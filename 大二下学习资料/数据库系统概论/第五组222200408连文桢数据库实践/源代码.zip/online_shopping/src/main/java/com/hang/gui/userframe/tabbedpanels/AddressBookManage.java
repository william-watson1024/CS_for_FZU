package com.hang.gui.userframe.tabbedpanels;

import com.hang.entity.AddressBook;
import com.hang.entity.User;
import com.hang.service.AddressBookService;
import com.hang.service.impl.AddressBookServiceImpl;
import com.hang.utils.TableUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class AddressBookManage extends JPanel {
    private AddressBookService addressService = new AddressBookServiceImpl();
    private JTable table = new JTable();
    private List<AddressBook> addresses;
    private User user;

    public AddressBookManage(User user) {
        this.user = user;

        setLayout(new BorderLayout());

        // 创建滚动面板并将表格添加到其中
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);
        showTable();

        addSetDefaultButtonPanel();
    }

    private void addSetDefaultButtonPanel() {
        JButton setDefaultButton = new JButton("设置为默认地址");
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(setDefaultButton);
        add(buttonPanel, BorderLayout.SOUTH);


        setDefaultButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            System.out.println(selectedRow);
            if (selectedRow != -1) {
                AddressBook address = addresses.get(selectedRow);
                addressService.setDefaultAddressBook(address.getAddressBookId());
                showTable();
            }
        });
    }

    private void showTable() {
        addresses = addressService.selectByUserId(user.getUserId());

        // 创建表格模型
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("省");
        model.addColumn("市");
        model.addColumn("区");
        model.addColumn("收件人");
        model.addColumn("手机号");
        model.addColumn("是否默认");

        // 添加数据到表格模型
        for (AddressBook address : addresses) {
            model.addRow(new Object[]{address.getProvinceName(), address.getCityName(), address.getDistrictName(), address.getConsignee(), address.getPhoneNumber(), address.getIsDefault()});
        }

        table.setModel(model);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);


        // 使用工具类，设置表格样式
        TableUtils.setTableStyle(table);
    }
}
