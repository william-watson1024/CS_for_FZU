package com.hang.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * <p>
 * 
 * </p>
 *
 * @author hang
 * @since 2024-06-26
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class SaleVolumn implements Serializable {


    @TableId(value = "sale_volumn_id", type = IdType.NONE)
    private Integer saleVolumnId;

    private Integer count;

    private LocalDate saleDate;

    private Integer productId;


}
