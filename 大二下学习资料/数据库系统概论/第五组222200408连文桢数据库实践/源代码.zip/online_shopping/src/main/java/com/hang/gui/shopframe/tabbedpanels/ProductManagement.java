package com.hang.gui.shopframe.tabbedpanels;


import com.hang.entity.Product;
import com.hang.entity.Purchase;
import com.hang.entity.Shop;
import com.hang.gui.shopframe.ShopFrame;
import com.hang.service.ProductService;
import com.hang.service.PurchaseService;
import com.hang.service.ShopService;
import com.hang.service.impl.ProductServiceImpl;
import com.hang.service.impl.PurchaseServiceImpl;
import com.hang.service.impl.ShopServiceImpl;
import com.hang.utils.ImageUtils;
import com.hang.utils.TableUtils;


import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;

import static com.hang.gui.shopframe.tabbedpanels.JPanelInTable.createComment;

public class ProductManagement extends JPanel {
    private ProductService productService = new ProductServiceImpl();
    private ShopService shopService = new ShopServiceImpl();
    private JTable table = new JTable();
    private List<Product> products = null;
    public ProductManagement(Shop seller, ShopFrame shopFrame) {
        setLayout(new BorderLayout());

        // 创建滚动面板并将表格添加到其中
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        setSelectConditionPanel(seller,shopFrame);
    }

    private void setSelectConditionPanel(Shop shop,ShopFrame shopFrame) {
        JPanel selectConditionPanel = new JPanel();

        selectConditionPanel.add(new JLabel("关键词: "));

        JTextField inputField = new JTextField(10);
        selectConditionPanel.add(inputField);

        selectConditionPanel.add(new JLabel("价格区间:"));

        JTextField lowestPriceField = new JTextField("0", 4);
        selectConditionPanel.add(lowestPriceField);

        selectConditionPanel.add(new JLabel("-"));


        JTextField highestPriceField = new JTextField("1000", 4);
        selectConditionPanel.add(highestPriceField);

        JButton searchButton = new JButton("搜索");
        selectConditionPanel.add(searchButton);


        JButton deleteButton = new JButton("删除商品");
        selectConditionPanel.add(deleteButton);

        JButton addButton = new JButton("添加商品");
        selectConditionPanel.add(addButton);

        JButton InventoryButton = new JButton("增加库存");
        selectConditionPanel.add(InventoryButton);

        JButton CommentButton = new JButton("查看评论");
        selectConditionPanel.add(CommentButton);

//        JPanel dialogPanel = new JPanel();


        //删除商品
        deleteButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();

            if (selectedRow != -1) {
                Product product = products.get(selectedRow);
                JLabel label1 = new JLabel("确定删除“"+product.getBrand()+"”品牌的“"+product.getName()+"”商品吗？");

                JButton verifyButton = new JButton("确认");
                verifyButton.setSize(100,30);
                JButton cancelButton = new JButton("取消");
                cancelButton.setSize(100,30);
                JDialog modalDialog = new JDialog(shopFrame, "删除", true);
                modalDialog.setSize(600, 150);
                int x = shopFrame.getX() + (shopFrame.getWidth() - modalDialog.getWidth()) / 2;
                int y = shopFrame.getY() + (shopFrame.getHeight() - modalDialog.getHeight()) / 2;
                modalDialog.setLocation(x,y);
                modalDialog.setLayout(new BorderLayout());

                JPanel buttonPanel = new JPanel();
                JPanel labelPanel = new JPanel();
                modalDialog.add(labelPanel,BorderLayout.CENTER);
                labelPanel.add(label1,CENTER_ALIGNMENT);
                modalDialog.add(buttonPanel,BorderLayout.SOUTH);
                buttonPanel.add(verifyButton);
                buttonPanel.add(cancelButton);

                // 关闭对话框并删除产品
                verifyButton.addActionListener(e1 -> {
                    productService.deleteById(product.getProductId());
                    products.remove(selectedRow);
                    modalDialog.dispose();
                    // 更新表格
                    showTable(inputField.getText(), new BigDecimal(0), new BigDecimal(2e+75), shop);
                });
                // 仅关闭对话框
                cancelButton.addActionListener(e1 -> modalDialog.dispose());

                modalDialog.setVisible(true);
            }
            else{
                JOptionPane.showMessageDialog(shopFrame, "未选择任何商品！", "提示", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        // 添加商品
        addButton.addActionListener(e -> {
            ProductInfoDialog dialog = new ProductInfoDialog(shopFrame, shop);
            dialog.setVisible(true);
        });

        PurchaseService purchaseService = new PurchaseServiceImpl();

        // 增加库存
        InventoryButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                JDialog modalDialog = new JDialog(shopFrame, "增加库存", true);
                modalDialog.setSize(600, 150);
                int x = shopFrame.getX() + (shopFrame.getWidth() - modalDialog.getWidth()) / 2;
                int y = shopFrame.getY() + (shopFrame.getHeight() - modalDialog.getHeight())/2;
                modalDialog.setLocation(x,y);
                modalDialog.setLayout(new BorderLayout());
                JLabel label1 = new JLabel("剩余库存："+products.get(selectedRow).getStock());
                JPanel textPanel = new JPanel();
                textPanel.add(label1);
                JPanel dialogPanel = new JPanel();
                JTextField inputField1 = new JTextField(10);
                dialogPanel.add(new JLabel("请输入增加库存的数量:"));
                dialogPanel.add(inputField1);
                JButton verifyButton = new JButton("确认");
                JButton cancelButton = new JButton("取消");
                verifyButton.addActionListener(e1 -> {
                    if (Integer.parseInt(inputField1.getText())<=0){
                        JOptionPane.showMessageDialog(shopFrame, "输入不合法！", "提示", JOptionPane.INFORMATION_MESSAGE);
                        return;
                    }
                    if (Integer.parseInt(inputField1.getText())+products.get(selectedRow).getStock()>100000){
                        JOptionPane.showMessageDialog(shopFrame, "库存数量超过上限！", "提示", JOptionPane.INFORMATION_MESSAGE);
                        return;
                    }
                    products.get(selectedRow).setStock(products.get(selectedRow).getStock()+Integer.parseInt(inputField1.getText()));
                    productService.updateById(products.get(selectedRow));
                    //TODO 插入进货量 商品id 数量 时间
                    LocalDate now = LocalDate.now();
                    Purchase purchase = new Purchase();
                    purchase.setPurchaseDate(now);
                    purchase.setCount(Integer.parseInt(inputField1.getText()));
                    purchase.setProductId(products.get(selectedRow).getProductId());
                    purchaseService.insert(purchase);



                    modalDialog.dispose();
                    showTable(inputField.getText(), new BigDecimal(0), new BigDecimal(2e+75), shop);
                });
                cancelButton.addActionListener(e1 -> modalDialog.dispose());
                dialogPanel.add(verifyButton);
                dialogPanel.add(cancelButton);
                modalDialog.add(dialogPanel,BorderLayout.SOUTH);
                modalDialog.add(textPanel,BorderLayout.CENTER);
                modalDialog.setVisible(true);

            }
            else {
                JOptionPane.showMessageDialog(shopFrame, "未选择任何商品！", "提示", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        //搜索
        searchButton.addActionListener(e -> {
            BigDecimal lowestPrice = BigDecimal.valueOf(Double.parseDouble(lowestPriceField.getText()));
            BigDecimal highestPrice = BigDecimal.valueOf(Double.parseDouble(highestPriceField.getText()));
            showTable(inputField.getText(), lowestPrice, highestPrice, shop);
        });

        //查看评论
        CommentButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                createComment(products.get(selectedRow));

            }
            else {
                JOptionPane.showMessageDialog(shopFrame, "未选择任何商品！", "提示", JOptionPane.INFORMATION_MESSAGE);
            }
        });




        showTable(inputField.getText(), new BigDecimal(0), new BigDecimal(2e+75), shop);
        add(selectConditionPanel, BorderLayout.NORTH);
    }


    private void showTable(String keyWord, BigDecimal lowestPrice, BigDecimal highestPrice,Shop shop) {


        products = productService.selectByShopIdAndConditions(keyWord, lowestPrice, highestPrice, shop.getShopId());


        // 定义列名
        String[] columnNames = {"照片", "商品名", "品牌", "店铺名", "价格","销售量","库存"};

        // 创建一个二维 Object 数组，行数为产品数量，列数为 5
        Object[][] data = new Object[products.size()][7];


        TableUtils.setTableStyle(table);

        // 遍历产品列表，将每个产品的信息填充到 Object 数组中
        for (int i = 0; i < products.size(); i++) {
            Product product = products.get(i);
            Shop shop1 = shopService.selectById(product.getShopId());
            String shopName = shop1.getShopName();

            String path = "image/product/" + product.getPhoto();
            ImageIcon icon = ImageUtils.getProductImageIcon(150, 150, path);

            data[i][0] = icon;
            data[i][1] = product.getName();
            data[i][2] = product.getBrand();
            data[i][3] = shopName;
            data[i][4] = product.getPrice();
            data[i][5] = product.getSalesVolume();
            data[i][6] = product.getStock();
        }

        // 创建表格模型
        DefaultTableModel model = new DefaultTableModel(data, columnNames) {
            @Override
            public Class<?> getColumnClass(int column) {
                if (column == 0) {
                    return ImageIcon.class;
                } else {
                    return String.class;
                }
            }
        };

        table.setModel(model);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();

        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);

        // 将渲染器应用于所有列
        for (int i = 1; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }

        table.setRowHeight(150);

    }
}

