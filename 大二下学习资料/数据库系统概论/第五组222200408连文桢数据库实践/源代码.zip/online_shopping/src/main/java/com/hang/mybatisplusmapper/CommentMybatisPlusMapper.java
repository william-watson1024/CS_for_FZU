package com.hang.mybatisplusmapper;

import com.hang.entity.Comment;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 评论表 Mapper 接口
 * </p>
 *
 * @author hang
 * @since 2024-05-25
 */
public interface CommentMybatisPlusMapper extends BaseMapper<Comment> {

}
