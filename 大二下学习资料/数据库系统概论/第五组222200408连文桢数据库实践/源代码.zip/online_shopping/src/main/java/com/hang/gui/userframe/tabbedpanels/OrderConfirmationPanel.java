package com.hang.gui.userframe.tabbedpanels;

import com.hang.entity.*;
import com.hang.gui.userframe.UserFrame;
import com.hang.service.ProductService;
import com.hang.service.ShoppingCartItemService;
import com.hang.service.UserBillingService;
import com.hang.service.impl.ProductServiceImpl;
import com.hang.service.impl.ShoppingCartItemServiceImpl;
import com.hang.service.impl.UserBillingServiceImpl;

import javax.swing.*;
import java.awt.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class OrderConfirmationPanel extends JPanel {
    private UserBillingService userBillingService = new UserBillingServiceImpl();
    private ProductService productService = new ProductServiceImpl();
    private ShoppingCartItemService shoppingCartItemService = new ShoppingCartItemServiceImpl();
    private static final BigDecimal SHIPPING_COST = new BigDecimal("10.00"); // example shipping cost
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public OrderConfirmationPanel(User user, List<ShoppingCartItem> items, AddressBook address, BigDecimal totalAmount, UserFrame userFrame) {
        setLayout(new BorderLayout());

        JPanel orderDetailsPanel = new JPanel();
        orderDetailsPanel.setLayout(new BoxLayout(orderDetailsPanel, BoxLayout.Y_AXIS));
        orderDetailsPanel.setBorder(BorderFactory.createTitledBorder("订单详情"));

        for (ShoppingCartItem item : items) {
            JPanel itemPanel = new JPanel(new GridLayout(0, 2));
            itemPanel.add(new JLabel("商品名称:"));
            itemPanel.add(new JLabel(productService.selectById(item.getProductId()).getName()));
            itemPanel.add(new JLabel("商品数量:"));
            itemPanel.add(new JLabel(String.valueOf(item.getNumber())));
            itemPanel.add(new JLabel("价格:"));
            ProductService productService = new ProductServiceImpl();
            Product product = productService.selectById(item.getProductId());
            BigDecimal productTotalPrice = product.getPrice().multiply(new BigDecimal(item.getNumber()));
            itemPanel.add(new JLabel(productTotalPrice.toString() + " 元"));
            orderDetailsPanel.add(itemPanel);
        }

        JPanel addressPanel = new JPanel(new GridLayout(0, 1));
        addressPanel.setBorder(BorderFactory.createTitledBorder("收货地址"));

        addressPanel.add(new JLabel("收货人: " + address.getConsignee()));
        addressPanel.add(new JLabel("电话: " + address.getPhoneNumber()));
        addressPanel.add(new JLabel("地址: " + address.getDetail()));

        orderDetailsPanel.add(addressPanel);

        JPanel shippingPanel = new JPanel(new GridLayout(0, 2));
        shippingPanel.add(new JLabel("运费:"));
        shippingPanel.add(new JLabel(SHIPPING_COST.toString() + " 元"));
        orderDetailsPanel.add(shippingPanel);

        JPanel deliveryPanel = new JPanel(new GridLayout(0, 2));
        deliveryPanel.add(new JLabel("预计送达时间:"));
        deliveryPanel.add(new JLabel(LocalDateTime.now().plusDays(3).format(formatter))); // example estimated delivery time
        orderDetailsPanel.add(deliveryPanel);

        add(orderDetailsPanel, BorderLayout.CENTER);

        JPanel summaryPanel = new JPanel(new GridLayout(1, 2));
        summaryPanel.add(new JLabel("订单总金额:"));
        BigDecimal finalAmount = totalAmount.add(SHIPPING_COST);
        summaryPanel.add(new JLabel(finalAmount.toString() + " 元"));

        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new BorderLayout());
        bottomPanel.add(summaryPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(1, 2));
        JButton submitOrderButton = new JButton("提交订单");
        JButton cancelButton = new JButton("取消");

        // Set preferred size to make buttons smaller
        Dimension buttonSize = new Dimension(100, 30);
        submitOrderButton.setPreferredSize(buttonSize);
        cancelButton.setPreferredSize(buttonSize);

        buttonPanel.add(submitOrderButton);
        buttonPanel.add(cancelButton);

        bottomPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(bottomPanel, BorderLayout.SOUTH);

        submitOrderButton.addActionListener(e -> {
            if(finalAmount.compareTo(user.getBalance()) > 0){
                JOptionPane.showMessageDialog(this, "余额不足，请先充值后再进行订单支付");
            } else{
                UserBilling userBilling = new UserBilling();
                userBilling.setChangeTime(LocalDateTime.now());
                userBilling.setUserId(user.getUserId());
                userBilling.setDescription("新帐单");
                userBilling.setChangeBalance(finalAmount);
                userBillingService.updateById(userBilling);

                Order order = new Order();
                order.setOrderCreateDatetime(LocalDateTime.now());
                order.setPaymentDatetime(LocalDateTime.now());
                order.setRemark("新订单");
                order.setUserId(user.getUserId());
                order.setAddressBookId(address.getAddressBookId());
                order.setTotalAmount(finalAmount);
                order.setDeliveryStatus("未发货");
                order.setPaymentStatus("已支付");
                for (ShoppingCartItem item : items) {
                    // Remove item from shopping cart after order is confirmed
                    shoppingCartItemService.deleteById(item.getShoppingCartItemId());
                }
                user.setBalance(user.getBalance().subtract(finalAmount));
                JOptionPane.showMessageDialog(this, "订单已支付，谢谢惠顾");
            }
            // Navigate back to the main panel
            userFrame.dispose();
            userFrame.setContentPane(new UserFrame(user));
            userFrame.revalidate();
            userFrame.repaint();
        });

        cancelButton.addActionListener(e -> {
            userFrame.dispose();
            userFrame.setContentPane(new UserFrame(user));
            userFrame.revalidate();
            userFrame.repaint();
        });
    }
}
