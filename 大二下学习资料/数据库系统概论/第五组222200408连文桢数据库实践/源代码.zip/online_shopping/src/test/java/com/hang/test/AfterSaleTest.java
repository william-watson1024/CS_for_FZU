package com.hang.test;

import com.hang.entity.AfterSale;
import com.hang.service.AfterSaleService;
import com.hang.service.impl.AfterSaleServiceImpl;
import org.junit.Test;

import java.util.List;

public class AfterSaleTest {
    AfterSaleService afterSaleService = new AfterSaleServiceImpl();
    @Test
    public void testSelectByShopId(){
        List<AfterSale> afterSales = afterSaleService.selectByShopId(1);
        for (AfterSale afterSale : afterSales) {
            System.out.println(afterSale);
        }
    }
}
