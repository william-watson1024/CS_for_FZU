package com.hang.gui.userframe.tabbedpanels;

import com.hang.entity.User;
import com.hang.entity.UserBilling;
import com.hang.service.UserBillingService;
import com.hang.service.UserService;
import com.hang.service.impl.UserBillingServiceImpl;
import com.hang.service.impl.UserServiceImpl;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class BalancePanel extends JPanel {

    private UserBillingService userBillingService = new UserBillingServiceImpl();
    private UserService userService = new UserServiceImpl();
    private DefaultTableModel model;
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private JLabel balanceLabel;
    private JLabel nameLabel;

    public BalancePanel(User user) {
        setLayout(new BorderLayout(10, 10));

        JPanel userInfoPanel = new JPanel(new GridLayout(2, 1));
        userInfoPanel.setBorder(BorderFactory.createTitledBorder("用户信息"));
        nameLabel = new JLabel("用户名: " + user.getNickname());
        balanceLabel = new JLabel();
        updateBalance(user);

        userInfoPanel.add(nameLabel);
        userInfoPanel.add(balanceLabel);

        JPanel rechargePanel = new JPanel(new GridBagLayout());
        rechargePanel.setBorder(BorderFactory.createTitledBorder("余额充值"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);

        gbc.gridx = 0;
        gbc.gridy = 0;
        JLabel amountLabel = new JLabel("充值金额:");
        rechargePanel.add(amountLabel, gbc);

        gbc.gridx = 1;
        JTextField amountField = new JTextField(30);
        rechargePanel.add(amountField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        JButton rechargeButton = new JButton("充值");
        rechargeButton.setPreferredSize(new Dimension(130, 60));
        rechargePanel.add(rechargeButton, gbc);

        rechargeButton.addActionListener(e -> {
            String amountText = amountField.getText();
            try {
                BigDecimal amount = new BigDecimal(amountText);
                UserBilling newBilling = new UserBilling();
                newBilling.setUserId(user.getUserId());
                newBilling.setChangeBalance(amount);
                newBilling.setDescription("成功充值" + amountText + "元");
                newBilling.setChangeTime(LocalDateTime.now());
                user.setBalance(user.getBalance().add(amount));
                userBillingService.insert(newBilling);
                updateBalance(user);
                userService.updateById(user);
                JOptionPane.showMessageDialog(this, "充值成功", "成功", JOptionPane.INFORMATION_MESSAGE);
                amountField.setText(""); // 清空文本框
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "请输入有效的金额", "错误", JOptionPane.ERROR_MESSAGE);
            }
        });

        JPanel billButtonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton viewBillButton = new JButton("查看账单");
        viewBillButton.setPreferredSize(new Dimension(150, 40));
        viewBillButton.addActionListener(e -> showBills(user));
        billButtonPanel.add(viewBillButton);

        // 新增刷新按钮
        JButton refreshButton = new JButton("刷新");
        refreshButton.setPreferredSize(new Dimension(150, 40));
        refreshButton.addActionListener(e -> refresh(user));
        billButtonPanel.add(refreshButton);

        add(userInfoPanel, BorderLayout.NORTH);
        add(rechargePanel, BorderLayout.CENTER);
        add(billButtonPanel, BorderLayout.SOUTH);
    }

    private void updateBalance(User user) {
        BigDecimal balance = user.getBalance();
        balanceLabel.setText("当前余额: ￥" + balance.toString());
    }

    private void showBills(User user) {
        List<UserBilling> billings = userBillingService.selectByUserId(user.getUserId());

        JFrame billFrame = new JFrame("账单详情");
        billFrame.setSize(400, 600);
        billFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        billFrame.setLayout(new BorderLayout());

        JPanel billPanel = new JPanel();
        billPanel.setLayout(new BoxLayout(billPanel, BoxLayout.Y_AXIS));

        for (UserBilling billing : billings) {
            JPanel singleBillPanel = new JPanel();
            singleBillPanel.setLayout(new BoxLayout(singleBillPanel, BoxLayout.Y_AXIS));
            singleBillPanel.setBorder(BorderFactory.createTitledBorder("账单"));

            JLabel userIdLabel = new JLabel("用户ID: " + billing.getUserId());
            JLabel timeLabel = new JLabel("时间: " + billing.getChangeTime().format(formatter));
            JLabel amountChangeLabel = new JLabel("金额变动: " + billing.getChangeBalance());
            JLabel descriptionLabel = new JLabel("描述: " + billing.getDescription());

            singleBillPanel.add(userIdLabel);
            singleBillPanel.add(timeLabel);
            singleBillPanel.add(amountChangeLabel);
            singleBillPanel.add(descriptionLabel);

            billPanel.add(singleBillPanel);
        }

        JScrollPane scrollPane = new JScrollPane(billPanel);
        billFrame.add(scrollPane, BorderLayout.CENTER);

        billFrame.setVisible(true);
    }

    private void refresh(User user) {
        user = userService.selectById(user.getUserId());
        updateBalance(user);
    }
}
