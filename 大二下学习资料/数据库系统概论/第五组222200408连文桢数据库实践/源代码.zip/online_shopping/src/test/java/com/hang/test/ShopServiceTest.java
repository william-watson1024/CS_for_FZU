package com.hang.test;

import com.hang.entity.Shop;
import com.hang.service.ShopService;
import com.hang.service.impl.ShopServiceImpl;
import org.junit.Test;

public class ShopServiceTest {
    private ShopService shopService = new ShopServiceImpl();

    @Test
    public void test(){
        Shop shop = shopService.selectById(1);
//        System.out.println(shop);

//        shop.setShopName("hello");
//        shopService.updateById(shop);
//        shopService.insert(shop);
    }
    @Test
    public void testInsert(){
        Shop shop = shopService.selectById(1);
        shop.setShopRevenue(null);
        shopService.insert(shop);
    }
}
