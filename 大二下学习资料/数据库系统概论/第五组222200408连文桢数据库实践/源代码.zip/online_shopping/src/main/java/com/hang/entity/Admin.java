package com.hang.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 管理员表
 * </p>
 *
 * @author hang
 * @since 2024-05-23
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class Admin implements Serializable {


    /**
     * 账号
     */
    @TableId(value = "admin_id", type = IdType.NONE)
    private String adminId;

    /**
     * 密码
     */
    private String password;

    /**
     * 姓名
     */
    private String name;

    /**
     * 手机号
     */
    private String phoneNumber;

    /**
     * 邮箱
     */
    private String email;


}
