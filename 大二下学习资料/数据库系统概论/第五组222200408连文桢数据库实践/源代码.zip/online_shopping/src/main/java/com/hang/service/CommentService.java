package com.hang.service;

import com.hang.entity.Comment;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface CommentService {
    List<Comment> selectAll();

    Comment selectById(Integer id);

    List<Comment> selectByProductId(Integer productId);

    void insert(Comment comment);

    void updateById(Comment comment);

    void deleteById(Integer id);
}
