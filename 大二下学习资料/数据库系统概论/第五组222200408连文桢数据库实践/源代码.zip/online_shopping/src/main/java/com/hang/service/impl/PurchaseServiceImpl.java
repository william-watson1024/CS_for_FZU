package com.hang.service.impl;

import com.hang.entity.Product;
import com.hang.entity.Purchase;
import com.hang.entity.SaleVolumn;
import com.hang.gui.shopframe.tabbedpanels.DatePicker;
import com.hang.mapper.ProductMapper;
import com.hang.mybatisplusmapper.PurchaseMybatisPlusMapper;
import com.hang.mybatisplusmapper.SaleVolumnMybatisPlusMapper;
import com.hang.service.PurchaseService;
import com.hang.utils.MybatisPlusSqlSessionFactoryUtil;
import com.hang.utils.SqlSessionFactoryUtil;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.time.LocalDate;
import java.util.List;

public class PurchaseServiceImpl implements PurchaseService {
    private SqlSessionFactory sqlSessionFactory = SqlSessionFactoryUtil.getSqlSessionFactory();
    private SqlSessionFactory mybatispulsSqlSessionFactory = MybatisPlusSqlSessionFactoryUtil.getMybatisPlusSqlSessionFactory();

    @Override
    public List<Purchase> selectByShopIdAndRange(LocalDate begin, LocalDate end, Integer shopId, String orderString, String productId) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ProductMapper mapper = sqlSession.getMapper(ProductMapper.class);
        List<Purchase> purchases = mapper.selectByShopIdAndRange(begin, end, shopId, orderString, productId);
        sqlSession.close();

        return purchases;

    }

    @Override
    public void insert(Purchase purchase) {
        SqlSession sqlSession = mybatispulsSqlSessionFactory.openSession();
        PurchaseMybatisPlusMapper mapper = sqlSession.getMapper(PurchaseMybatisPlusMapper.class);
        mapper.insert(purchase);
        sqlSession.commit();
        sqlSession.close();
    }
}

