package com.hang.gui.shopframe.tabbedpanels;

import com.hang.entity.Shop;
import com.hang.entity.Order;
import com.hang.gui.shopframe.ShopFrame;
import com.hang.service.ProductService;
import com.hang.service.UserService;
import com.hang.service.OrderService;
import com.hang.service.impl.OrderServiceImpl;
import com.hang.service.impl.ProductServiceImpl;
import com.hang.utils.TableUtils;
import com.hang.service.impl.UserServiceImpl;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Comparator;
import java.util.stream.Collectors;

public class OrderManagement extends JPanel {

    private OrderService orderService = new OrderServiceImpl();
    private UserService userService = new UserServiceImpl();
    private ProductService productService = new ProductServiceImpl();
    private DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private DefaultTableModel model;
    private JTable table;

    public OrderManagement(Shop shop, ShopFrame shopFrame) {
        setLayout(new BorderLayout());

        // 添加查询面板
        JPanel searchPanel = new JPanel();
        add(searchPanel, BorderLayout.NORTH);



        JComboBox<String> sortColumnComboBox = new JComboBox<>(new String[]{"订单号", "用户", "商品", "订单创建时间", "总价"});
        JComboBox<String> sortOrderComboBox = new JComboBox<>(new String[]{"升序", "降序"});
        searchPanel.add(sortColumnComboBox);
        searchPanel.add(sortOrderComboBox);

        JLabel orderLabel = new JLabel("订单号：");
        JTextField orderTextField = new JTextField(10);
        searchPanel.add(orderLabel);
        searchPanel.add(orderTextField);

        JButton searchButton = new JButton("搜索");
        searchPanel.add(searchButton);

        searchButton.addActionListener(e -> {
            String orderId = orderTextField.getText();
            String sortColumn = (String) sortColumnComboBox.getSelectedItem();
            String sortOrder = (String) sortOrderComboBox.getSelectedItem();
            updateTableModel(orderId, sortColumn, sortOrder, shop);
        });

        // 创建表格
        table = createTable(null, "订单号", "升序", shop);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // 添加按钮面板
        JButton enterOrderButton = new JButton("查看详情");
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(enterOrderButton);
        add(buttonPanel, BorderLayout.SOUTH);

        enterOrderButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                Order selectedOrder = orderService.selectById(Integer.parseInt(table.getValueAt(selectedRow, 0).toString()));
                JDialog dialog = createOrderDetailDialog(shopFrame, selectedOrder);
                dialog.setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "未选择任何订单！");
            }
        });
    }

    private JTable createTable(String orderId, String sortColumn, String sortOrder, Shop shop) {
        model = new DefaultTableModel();
        model.addColumn("订单号");
        model.addColumn("用户");
        model.addColumn("商品");
        model.addColumn("订单创建时间");
        model.addColumn("总价");

        List<Order> orders = filterAndSortOrders(orderId, sortColumn, sortOrder, shop);


        for (Order order : orders) {
            model.addRow(new Object[]{
                    order.getOrderId(),
                    userService.selectById(order.getUserId()).getNickname(),
                    productService.selectById(order.getProductId()).getName(),
                    order.getOrderCreateDatetime().format(formatter),
                    order.getTotalAmount()
            });
        }

        JTable table = new JTable(model);
        TableUtils.setTableStyle(table);
        table.setRowHeight(30);
        return table;
    }

    private void updateTableModel(String orderId, String sortColumn, String sortOrder, Shop shop) {
        List<Order> orders = filterAndSortOrders(orderId, sortColumn, sortOrder, shop);

        model.setRowCount(0); // Clear the existing rows

        for (Order order : orders) {
            model.addRow(new Object[]{
                    order.getOrderId(),
                    userService.selectById(order.getUserId()).getNickname(),
                    productService.selectById(order.getProductId()).getName(),
                    order.getOrderCreateDatetime().format(formatter),
                    order.getTotalAmount()
            });
        }

        model.fireTableDataChanged(); // Notify the table that the model has been updated
    }

    private List<Order> filterAndSortOrders(String orderId, String sortColumn, String sortOrder, Shop shop) {
        //List<Order> orders = orderService.selectAll();
        //TODO 查询该商店的所有订单
        List<Order> orders = orderService.selectByShopId( shop.getShopId());

        if (orderId != null && !orderId.trim().isEmpty()) {
            orders = orders.stream()
                    .filter(order -> order.getOrderId().toString().contains(orderId))
                    .collect(Collectors.toList());
        }

        Comparator<Order> comparator = getComparator(sortColumn, sortOrder);
        orders.sort(comparator);

        return orders;
    }

    private Comparator<Order> getComparator(String sortColumn, String sortOrder) {
        Comparator<Order> comparator;

        switch (sortColumn) {
            case "订单号":
                comparator = Comparator.comparing(Order::getOrderId);
                break;
            case "用户":
                comparator = Comparator.comparing(order -> userService.selectById(order.getUserId()).getNickname());
                break;
            case "商品":
                comparator = Comparator.comparing(order -> productService.selectById(order.getProductId()).getName());
                break;
            case "订单创建时间":
                comparator = Comparator.comparing(Order::getOrderCreateDatetime);
                break;
            case "总价":
                comparator = Comparator.comparing(Order::getTotalAmount);
                break;
            default:
                comparator = Comparator.comparing(Order::getOrderId);
        }

        if ("降序".equals(sortOrder)) {
            comparator = comparator.reversed();
        }

        return comparator;
    }

    private JDialog createOrderDetailDialog(ShopFrame shopFrame, Order selectedOrder) {
        JDialog dialog = new JDialog(shopFrame, "订单详情", true);
        dialog.setSize(500, 600);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new GridLayout(0, 2));

        dialog.add(new JLabel("订单号:"));
        dialog.add(new JLabel(String.valueOf(selectedOrder.getOrderId())));
        dialog.add(new JLabel("用户:"));
        dialog.add(new JLabel(userService.selectById(selectedOrder.getUserId()).getNickname()));
        dialog.add(new JLabel("账号:"));
        dialog.add(new JLabel(String.valueOf(selectedOrder.getUserId())));
        dialog.add(new JLabel("商品:"));
        dialog.add(new JLabel(productService.selectById(selectedOrder.getProductId()).getName()));
        dialog.add(new JLabel("收货地址:"));
        dialog.add(new JLabel(String.valueOf(selectedOrder.getAddressBookId())));
        dialog.add(new JLabel("商品数量:"));
        dialog.add(new JLabel(String.valueOf(selectedOrder.getProductNumber())));
        dialog.add(new JLabel("订单创建时间:"));
        dialog.add(new JLabel(selectedOrder.getOrderCreateDatetime().format(formatter)));
        dialog.add(new JLabel("支付完成时间:"));
        dialog.add(new JLabel(selectedOrder.getPaymentDatetime().format(formatter)));
        dialog.add(new JLabel("总价:"));
        dialog.add(new JLabel(String.valueOf(selectedOrder.getTotalAmount())));
        dialog.add(new JLabel("支付状态:"));
        dialog.add(new JLabel(selectedOrder.getPaymentStatus()));
        dialog.add(new JLabel("配送状态:"));
        dialog.add(new JLabel(selectedOrder.getDeliveryStatus()));
        dialog.add(new JLabel("备注:"));
        dialog.add(new JLabel(selectedOrder.getRemark()));

        return dialog;
    }
}
