package com.hang.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * <p>
 * 
 * </p>
 *
 * @author hang
 * @since 2024-06-26
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class Purchase implements Serializable {


    @TableId(value = "purchase_id", type = IdType.AUTO)
    private Integer purchaseId;

    private LocalDate purchaseDate;

    private Integer count;

    private Integer productId;


}
