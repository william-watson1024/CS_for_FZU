package com.hang.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hang.entity.Purchase;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author hang
 * @since 2024-06-26
 */
public interface PurchaseMapper{

}
