package com.hang.mybatisplusmapper;

import com.hang.entity.AddressBook;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 地址表 Mapper 接口
 * </p>
 *
 * @author hang
 * @since 2024-05-25
 */
public interface AddressBookMybatisPlusMapper extends BaseMapper<AddressBook> {

}
