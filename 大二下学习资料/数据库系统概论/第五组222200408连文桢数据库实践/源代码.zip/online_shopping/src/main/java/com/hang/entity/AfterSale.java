package com.hang.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 售后表
 * </p>
 *
 * @author hang
 * @since 2024-05-23
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class AfterSale implements Serializable {


    /**
     * 主键 自增长
     */
    @TableId(value = "after_sale_id", type = IdType.AUTO)
    private Integer afterSaleId;

    /**
     * 订单号
     */
    private Integer orderId;

    /**
     * 请求类型 (退货退款|换货|仅退款) 默认: 退货退款
     */
    private String requestType;

    /**
     * 原因
     */
    private String reason;

    /**
     * 处理状态 (待处理|已同意|已拒绝|已完成) 默认:待处理
     */
    private String status;

    /**
     * 回复信息
     */
    private String reply;

    /**
     * 请求时间
     */
    private LocalDateTime requestTime;

    /**
     * 完成时间
     */
    private LocalDateTime solvedTime;


}
