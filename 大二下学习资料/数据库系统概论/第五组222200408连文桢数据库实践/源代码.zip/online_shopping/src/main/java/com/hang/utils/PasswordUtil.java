package com.hang.utils;

import org.mindrot.jbcrypt.BCrypt;

public class PasswordUtil {

    // 加密密码
    public static String hashPassword(String plainTextPassword) {
        // 生成盐值
        String salt = BCrypt.gensalt();
        // 生成散列密码
        return BCrypt.hashpw(plainTextPassword, salt);
    }

    // 验证密码
    public static boolean checkPassword(String plainTextPassword, String hashedPassword) {
        return BCrypt.checkpw(plainTextPassword, hashedPassword);
    }

    public static void main(String[] args) {
        // 示例使用
        String password = "123456";
        String hashedPassword = hashPassword(password);

        System.out.println("Plain Password: " + password);
        System.out.println("Hashed Password: " + hashedPassword);

        // 验证密码
        boolean isPasswordCorrect = checkPassword(password, hashedPassword);
        System.out.println("Password is correct: " + isPasswordCorrect);

        // 错误密码示例
        boolean isWrongPasswordCorrect = checkPassword("123456", "$2a$10$LV0FSJ1SQjVXMpEIe5WSq.kHXymFkh5oW6.viCv1F0opc2OTa5WdG");
        System.out.println("Compare Password is correct: " + isWrongPasswordCorrect);
    }
}

