package com.hang.gui.userframe.tabbedpanels.frames;

import com.hang.entity.User;
import com.hang.service.UserService;
import com.hang.service.impl.UserServiceImpl;

import javax.swing.*;
import java.awt.*;

public class ChangePasswordFrame extends JFrame {
    private UserService userService = new UserServiceImpl();

    JLabel oldPasswordLabel =  new JLabel("旧密码");
    JPasswordField oldPasswordField = new JPasswordField(10);

    JLabel newPasswordLabel =  new JLabel("新密码");
    JPasswordField newPasswordField = new JPasswordField(10);

    JButton confirmButton = new JButton("确认修改");
    JPanel confirmPanel  = new JPanel();

    public ChangePasswordFrame(User user){
        setLayout(new GridBagLayout());

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5,5,5,5);

        // 第1行：旧密码
        c.gridy = 0;

        c.gridx = 0;
        add(oldPasswordLabel,c);

        c.gridx = 1;
        add(oldPasswordField,c);


        // 第2行：新密码
        c.gridy = 1;

        c.gridx = 0;
        add(newPasswordLabel,c);

        c.gridx = 1;
        add(newPasswordField,c);


        // 第3行：确认按钮panel
        c.gridy = 2;

        c.gridx = 0;
        c.gridwidth = 2;
        confirmPanel.add(confirmButton);
        add(confirmPanel,c);

        confirmButton.addActionListener(e->{
            if(user.getPassword().equals(oldPasswordField.getText())){
                if(newPasswordField.getText().length()<6){
                    JOptionPane.showMessageDialog(this,"新密码不少于6位");
                }else{
                    user.setPassword(newPasswordField.getText());
                    userService.updateById(user);
                    JOptionPane.showMessageDialog(this,"修改成功");
                    dispose();
                }
            }else{
                JOptionPane.showMessageDialog(this,"旧密码错误");
            }
        });

        setTitle("修改密码");
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
