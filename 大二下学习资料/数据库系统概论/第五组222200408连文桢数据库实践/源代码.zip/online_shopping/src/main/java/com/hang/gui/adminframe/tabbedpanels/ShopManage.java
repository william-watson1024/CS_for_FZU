package com.hang.gui.adminframe.tabbedpanels;

import com.hang.entity.Shop;
import com.hang.service.ShopService;
import com.hang.service.impl.ShopServiceImpl;
import com.hang.utils.TableUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ShopManage extends JPanel {
    private ShopService shopService = new ShopServiceImpl();
    List<Shop> shops;

    JTable table = new JTable();
    String[] statusOptions = {"全部","审核中","已通过","未通过"};
    JComboBox<String> statusComboBox = new JComboBox<>(statusOptions);
    JTextField searchField = new JTextField(10);
    JButton searchButton = new JButton("搜索");
    JButton passButton = new JButton("设置为已通过");
    JButton notPassedButton = new JButton("设置为未通过");

    public ShopManage(){
        setLayout(new BorderLayout());
        add(new JScrollPane(table),BorderLayout.CENTER);
        setNorthPanel();
        setSouthPanel();


        updateTable();
    }

    private void setSouthPanel() {
        JPanel southPanel = new JPanel();

        southPanel.add(passButton);
        southPanel.add(notPassedButton);

        passButton.addActionListener(e->{
            int selectedRow = table.getSelectedRow();
            if(selectedRow == -1){
                return;
            }

            Shop shop = shops.get(selectedRow);
            shop.setVerifyStatus("已通过");
            shopService.updateById(shop);
            updateTable();
            for(int i=0; i<shops.size(); i++){
                if(shops.get(i).getShopId().equals(shop.getShopId())){
                    table.setRowSelectionInterval(i,i);
                    break;
                }
            }
        });

        notPassedButton.addActionListener(e->{
            int selectedRow = table.getSelectedRow();
            if(selectedRow == -1){
                return;
            }

            Shop shop = shops.get(selectedRow);
            shop.setVerifyStatus("未通过");
            shopService.updateById(shop);
            updateTable();
            for(int i=0; i<shops.size(); i++){
                if(shops.get(i).getShopId().equals(shop.getShopId())){
                    table.setRowSelectionInterval(i,i);
                    break;
                }
            }
        });

        add(southPanel,BorderLayout.SOUTH);
    }

    private void setNorthPanel(){
        JPanel northPanel = new JPanel();
        northPanel.add(new JLabel("状态:"));
        northPanel.add(statusComboBox);
        northPanel.add(new JLabel("   店铺名|商家:"));
        northPanel.add(searchField);
        northPanel.add(searchButton);

        add(northPanel,BorderLayout.NORTH);

        statusComboBox.addItemListener(e->updateTable());
        searchButton.addActionListener(e->updateTable());


    }

    private void updateTable(){
        String status = (String) statusComboBox.getSelectedItem();
        String searchText = searchField.getText();
        shops = shopService.selectByConditions(status,searchText);

        // 创建表格模型
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("店铺名");
        model.addColumn("商家");
        model.addColumn("商业执照号");
        model.addColumn("认证状态");

        // 添加数据到表格模型
        for (Shop shop : shops) {
            model.addRow(new Object[]{shop.getShopName(),shop.getSellerId(),shop.getBusinessLicense(),shop.getVerifyStatus()});
        }

        // 创建表格
         table.setModel(model);

        // 使用工具类，设置表格样式
        TableUtils.setTableStyle(table);
    }
}
