package com.hang.gui.userframe.tabbedpanels;

import com.hang.entity.AfterSale;
import com.hang.entity.Order;
import com.hang.service.AfterSaleService;
import com.hang.service.ShopService;
import com.hang.service.impl.AfterSaleServiceImpl;
import com.hang.service.impl.ShopServiceImpl;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.time.LocalDateTime;

public class AfterSalesRequestFrame extends JDialog {
    private AfterSaleService afterSaleService = new AfterSaleServiceImpl();
    private JLabel statusLabel;

    public AfterSalesRequestFrame(JFrame owner, Order order) {
        super(owner, "申请售后", true);
        setSize(600, 500);
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout());

        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);

        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(new JLabel("订单号:"), gbc);

        gbc.gridx = 1;
        JLabel orderIdLabel = new JLabel(String.valueOf(order.getOrderId()));
        orderIdLabel.setPreferredSize(new Dimension(300, 25));
        formPanel.add(orderIdLabel, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(new JLabel("请求类型:"), gbc);

        gbc.gridx = 1;
        String[] requestTypes = {"退货退款", "换货", "仅退款"};
        JComboBox<String> requestTypeComboBox = new JComboBox<>(requestTypes);
        requestTypeComboBox.setPreferredSize(new Dimension(300, 30));
        formPanel.add(requestTypeComboBox, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(new JLabel("原因:"), gbc);

        gbc.gridx = 1;
        JTextArea reasonTextArea = new JTextArea(5, 20);
        JScrollPane reasonScrollPane = new JScrollPane(reasonTextArea);
        reasonScrollPane.setPreferredSize(new Dimension(300, 100));
        formPanel.add(reasonScrollPane, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        formPanel.add(new JLabel("上传凭证:"), gbc);

        gbc.gridx = 1;
        JButton uploadButton = new JButton("上传图片");
        uploadButton.setPreferredSize(new Dimension(150, 25));
        uploadButton.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();
            int returnValue = fileChooser.showOpenDialog(this);
            if (returnValue == JFileChooser.APPROVE_OPTION) {
                File selectedFile = fileChooser.getSelectedFile();
                JOptionPane.showMessageDialog(this, "已上传文件: " + selectedFile.getName());
            }
        });
        formPanel.add(uploadButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        formPanel.add(new JLabel("处理状态:"), gbc);

        gbc.gridx = 1;
        statusLabel = new JLabel("待处理");
        statusLabel.setPreferredSize(new Dimension(300, 25));
        formPanel.add(statusLabel, gbc);

        add(formPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton submitButton = new JButton("提交");
        submitButton.setPreferredSize(new Dimension(100, 30));
        submitButton.addActionListener(e -> {
            AfterSale afterSale = new AfterSale();
            afterSale.setRequestTime(LocalDateTime.now());
            afterSale.setReply("");
            afterSale.setReason(reasonTextArea.getText());
            afterSale.setRequestType((String) requestTypeComboBox.getSelectedItem());
            afterSale.setStatus("待处理");
            afterSale.setOrderId(order.getOrderId());
            afterSaleService.insert(afterSale);
            JOptionPane.showMessageDialog(this, "售后请求提交成功！");
            statusLabel.setText("处理中");
        });
        buttonPanel.add(submitButton);

        JButton complaintButton = new JButton("投诉与建议");
        complaintButton.setPreferredSize(new Dimension(150, 30));
        complaintButton.addActionListener(e -> {
            JTextArea complaintTextArea = new JTextArea(5, 20);
            int option = JOptionPane.showConfirmDialog(this, new JScrollPane(complaintTextArea), "请输入您对商品或服务投诉与建议", JOptionPane.OK_CANCEL_OPTION);
            if (option == JOptionPane.OK_OPTION) {
                // TODO: 处理投诉与建议
                JOptionPane.showMessageDialog(this, "感谢您的反馈！商家收到后会与您联系");
            }
        });
        buttonPanel.add(complaintButton);

        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }
}
