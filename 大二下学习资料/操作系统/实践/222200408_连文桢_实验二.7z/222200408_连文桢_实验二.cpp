#include <iostream>
#include <vector>
#include <queue>
#include <unordered_map>

#define PAGE_SIZE 4096          // ����ҳ���СΪ4KB
#define PAGE_NUM 4              // �����������̵�����ҳ֡��Ϊ4ҳ
#define VIRTURAL_SPACE 8        // ������̵������ַ�ռ��СΪ8ҳ

using namespace std;

struct PageTableEntry {
	int pa_num;    // ����ҳ֡��
	int R;         // ������ʱ�־
	int P;         // �Ƿ��������־
};

class MemoryManagement {
	private:
		vector<PageTableEntry> pageTable;
		vector<int> clock;
		int clockHand;

	public:
		MemoryManagement() : pageTable(VIRTURAL_SPACE, {
			0, 0, 0
		}), clock(PAGE_NUM, -1), clockHand(0) {}

		void printPageTable() {
			cout << "pa_num\t\tR\tP\n";
			int length = pageTable.size();
			for (int i = 0; i < length; i++) {
				cout << "|" << pageTable[i].pa_num << "\t\t|" << pageTable[i].R << "\t|" << pageTable[i].P << endl;
			}
		}

		int getPageFrame() {
			for (int i = 0; i < PAGE_NUM; i++) {
				if (clock[i] == -1) return i;
			}
			return -1;
		}

		void accessPage(int pageNum) {
			if (pageTable[pageNum].P == 1) {
				pageTable[pageNum].R = 1;
			} else {
				cout << "the page is not in the RAM!" << endl;
				int freeFrame = getPageFrame();
				if (freeFrame != -1) {
					cout << "there are free pages, we can get NO." << freeFrame << " page frame!" << endl;
					pageTable[pageNum] = {freeFrame, 1, 1};
					clock[freeFrame] = pageNum;
				} else {
					cout << "there is no free page in RAM, so we have to exchange one!" << endl;
					while (true) {
						int current = clock[clockHand];
						if (pageTable[current].R == 0) {
							cout << "NO." << clockHand << " page frame is exchanged!!" << endl;
							pageTable[current].P = 0;
							pageTable[pageNum] = {clockHand, 1, 1};
							clock[clockHand] = pageNum;
							clockHand = (clockHand + 1) % PAGE_NUM;
							break;
						} else {
							cout << "page NO." << clockHand << " is just read, we should search next one!\n";
							pageTable[current].R = 0;
							clockHand = (clockHand + 1) % PAGE_NUM;
						}
					}
				}
			}
			int length = pageTable.size();
			for (int i = 0; i < length; i++) {
				if (i != pageNum) {
					pageTable[i].R = 0;
				}
			}
			printPageTable();
		}
		bool check(int address) {
			int pageNum = address / PAGE_SIZE;
			return pageTable[pageNum].P == 1;
		}
};

int main() {
	MemoryManagement mm;
	int address;
	printf("\n\
��ʾ��������ҳ���СΪ%dB�������������̵�����ҳ֡��Ϊ%dҳ,������̵������\
ַ�ռ��СΪ%dҳ.\
	\n", PAGE_SIZE, PAGE_NUM, VIRTURAL_SPACE);
	while (true) {
		cout << "\nplease input the virtual address(end of -1): ";
		cin >> address;
		if (address == -1) break;
		int pageNum = address / PAGE_SIZE;
		if (mm.check(address)) {
			cout << "the page is in the RAM, and the physical address is " << address << endl;
		}
		mm.accessPage(pageNum);
	}

	return 0;
}
