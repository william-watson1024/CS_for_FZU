package com.hang.service;

import com.hang.entity.Shop;

import java.util.List;

public interface ShopService {
    List<Shop> selectAll();
    Shop selectById(Integer id);
    List<Shop> selectBySellerId(String sellerId);


    void insert(Shop shop);
    void updateById(Shop shop);
    void deleteById(Integer id);

    List<Shop> selectByConditions(String status, String searchText);


    List<Shop> selectLikeShopName(String shopName);
}
