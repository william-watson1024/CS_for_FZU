package com.hang.service.impl;

import com.hang.entity.Shop;
import com.hang.entity.User;
import com.hang.mapper.ShopMapper;
import com.hang.mapper.UserMapper;
import com.hang.service.UserAndShopService;
import com.hang.utils.SqlSessionFactoryUtil;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.math.BigDecimal;

public class UserAndShopServiceImpl implements UserAndShopService {
    private SqlSessionFactory sqlSessionFactory = SqlSessionFactoryUtil.getSqlSessionFactory();

    @Override
    public String balanceFromUserToShop(BigDecimal amount, String userId, Integer shopId) {
        // 开启事务
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        ShopMapper shopMapper = sqlSession.getMapper(ShopMapper.class);

        User user = userMapper.selectById(userId);
        Shop shop = shopMapper.selectById(shopId);

        if (user.getBalance().compareTo(amount) < 0) {
            return "用户余额不足。";
        }
        try {
            user.setBalance(user.getBalance().subtract(amount));
            shop.setShopRevenue(shop.getShopRevenue().add(amount));

            // 更新用户余额和店铺营业额
            userMapper.updateById(user);
            shopMapper.updateById(shop);

            // 提交事务
            sqlSession.commit();
            return "资金流转成功：从用户到店铺。";
        } catch (Exception e) {

            // 回滚事务
            sqlSession.rollback();
            return "发生异常，事务自动回滚。";
        } finally {
            sqlSession.close();
        }
    }

    @Override
    public String balanceFromShopToUser(BigDecimal amount, Integer shopId, String userId) {
        // 开启事务
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        ShopMapper shopMapper = sqlSession.getMapper(ShopMapper.class);

        User user = userMapper.selectById(userId);
        Shop shop = shopMapper.selectById(shopId);

        if (shop.getShopRevenue().compareTo(amount) < 0) {
            return "店铺营业额不足。";
        }
        try {
            shop.setShopRevenue(shop.getShopRevenue().subtract(amount));
            user.setBalance(user.getBalance().add(amount));

            // 更新用户余额和店铺营业额
            shopMapper.updateById(shop);
            userMapper.updateById(user);

            // 提交事务
            sqlSession.commit();
            return "资金流转成功：从店铺到用户。";
        } catch (Exception e) {

            // 回滚事务
            sqlSession.rollback();
            return "发生异常，事务自动回滚。";
        } finally {
            sqlSession.close();
        }
    }
}
