package com.hang.test;

import com.hang.entity.Product;
import com.hang.service.ProductService;
import com.hang.service.impl.ProductServiceImpl;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.List;

public class ProductServiceTest {
    private ProductService productService = new ProductServiceImpl();

    @Test
    public void test(){
        /*List<Product> products = productService.selectAll();
        System.out.println(products);*/
//        productService.deleteById(7);
        Product product = productService.selectById(2);
        product.setName("升级铅笔");
        productService.updateById(product);
//        product.setName("bushiqianbi");
//        productService.insert(product);
    }

    @Test
    public void testSelectByShopIdAndConditions(){
        List<Product> products = productService.selectByShopIdAndConditions("手机", BigDecimal.valueOf(0), BigDecimal.valueOf(1000), 1);
        for (Product product : products) {
            System.out.println(product);
        }
    }
}
