package com.hang.gui.sellerframe;

import com.hang.entity.Seller;
import com.hang.gui.sellerframe.tabbedpanels.*;
import com.hang.service.SellerService;
import com.hang.service.impl.SellerServiceImpl;

import javax.swing.*;
import java.awt.*;

public class SellerFrame extends JFrame {

    private SellerService sellerService = new SellerServiceImpl();
    private final Seller seller;
    // 创建选项卡面板
    private final JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.LEFT);

    public SellerFrame(Seller seller){
        setTitle("商家："+seller.getSellerId());
        this.seller = seller;

//        setSize(Config.getFrameWidth(), Config.getFrameHeight());
        setExtendedState(JFrame.MAXIMIZED_BOTH);

        tabbedPane.addTab("欢迎", null, new WelcomeSeller(seller), "欢迎");
        tabbedPane.addTab("店铺管理", null, new ShopManage(seller,this), "店铺管理");
        tabbedPane.addTab("商品浏览", null, new ProductBrowsing(seller), "商品浏览与搜索");
        tabbedPane.addTab("修改个人信息", null, new ModifyInformation(seller,this), "修改个人信息");


        // 将选项卡面板添加到框架
        add(tabbedPane, BorderLayout.CENTER);


        setLocationRelativeTo(null);
        // 显示窗口/
        setVisible(true);
    }



}
