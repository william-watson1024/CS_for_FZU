package com.hang.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 地址表
 * </p>
 *
 * @author hang
 * @since 2024-05-23
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class AddressBook implements Serializable {


    /**
     * 主键 自增长
     */
    @TableId(value = "address_book_id", type = IdType.AUTO)
    private Integer addressBookId;

    /**
     * 外键 归属用户
     */
    private String userId;

    /**
     * 收件人
     */
    private String consignee;

    /**
     * 手机号
     */
    private String phoneNumber;

    /**
     * 省级名称
     */
    private String provinceName;

    /**
     * 市级名称
     */
    private String cityName;

    /**
     * 区级名称
     */
    private String districtName;

    /**
     * 具体地址
     */
    private String detail;

    /**
     * 是否默认地址 (是|否) 默认:否
     */
    private String isDefault;


}
