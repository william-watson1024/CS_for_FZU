package com.hang.test;

import com.hang.entity.ShopBilling;
import com.hang.service.ShopBillingService;
import com.hang.service.impl.ShopBillingServiceImpl;
import org.junit.Test;

import java.time.LocalDateTime;
import java.util.List;

public class ShopBillingServiceTest {
    ShopBillingService shopBillingService = new ShopBillingServiceImpl();
    @Test
    public void testSelectByShopIdAndTimeRange(){
        List<ShopBilling> shopBillings = shopBillingService.selectByShopIdAndTimeRange(LocalDateTime.of(2000, 1, 1, 0, 0),
                LocalDateTime.of(2024, 1, 1, 0, 0),
                1
        );
        for (ShopBilling shopBilling : shopBillings) {
            System.out.println(shopBilling);
        }

    }
}
