package com.hang.mapper;


import com.hang.entity.Product;
import com.hang.entity.Purchase;
import com.hang.entity.User;
import org.apache.ibatis.annotations.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public interface ProductMapper {
    @Select("select * from product")
    List<Product> selectAll();

    @Select("select * from product where product_id=#{id}")
    Product selectById(Integer id);

    @Select("select * from product where (name like #{keyWord} or description like #{keyWord} or type like #{keyWord} or key_words like #{keyWord}) and price between #{lowestPrice} and #{highestPrice}")
    List<Product> selectByConditions(@Param("keyWord") String keyWord,@Param("lowestPrice") BigDecimal lowestPrice, @Param("highestPrice")BigDecimal highestPrice);

    @Select("select * from product where (name like #{keyWord} or description like #{keyWord} or type like #{keyWord} or key_words like #{keyWord}) and price between #{lowestPrice} and #{highestPrice} and shop_id=#{shopId}")
    List<Product> selectByShopIdAndConditions(@Param("keyWord") String keyWord,@Param("lowestPrice") BigDecimal lowestPrice, @Param("highestPrice")BigDecimal highestPrice, @Param("shopId") Integer shopId);

    @Insert("insert into product(product_id, shop_id, name, brand, description, price, type, key_words, stock, sales_volume, weight, size, photo, status) VALUES (null, #{shopId}, #{name}, #{brand}, #{description}, #{price}, #{type}, #{keyWords}, #{stock}, #{salesVolume}, #{weight}, #{size}, #{photo}, #{status})")
    void insert(Product product);

    @Update("update product set shop_id=#{shopId}, name=#{name}, brand=#{brand}, description=#{description}, price=#{price}, type=#{type}, key_words=#{keyWords}, stock=#{stock}, sales_volume=#{salesVolume}, weight=#{weight}, size=#{size}, photo=#{photo}, status=#{status} where product_id=#{productId}")
    void updateById(Product product);

    @Delete("delete from product where product_id=#{id}")
    void deleteById(Integer id);

//    @Select("select purchase.* from purchase, product  where  purchase.product_id = product.product_id and  purchase.purchase_date between #{begin} and #{end} and product.shop_id = #{shopId} and product.product_id = #{productId} order by purchase_date ")
//    List<Purchase> selectByShopIdAndRange(@Param("begin") LocalDate begin, @Param("end") LocalDate end, @Param("shopId") Integer shopId,@Param("orderString") String orderString,@Param("productId") Integer productId);

    @Select({
            "<script>",
            "SELECT purchase.* FROM purchase, product",
            "WHERE purchase.product_id = product.product_id",
            "AND purchase.purchase_date BETWEEN #{begin} AND #{end}",
            "AND product.shop_id = #{shopId}",
            "<if test='productId != null and productId != \"\"'>",
            "AND product.product_id = #{productId}",
            "</if>",
            "ORDER BY purchase.purchase_date",
            "<if test='orderString != null and orderString.toLowerCase() == \"asc\"'> ASC</if>",
            "<if test='orderString != null and orderString.toLowerCase() == \"desc\"'> DESC</if>",
            "</script>"
    })
    List<Purchase> selectByShopIdAndRange(@Param("begin") LocalDate begin,
                                          @Param("end") LocalDate end,
                                          @Param("shopId") Integer shopId,
                                          @Param("orderString") String orderString,
                                          @Param("productId") String productId);
}
