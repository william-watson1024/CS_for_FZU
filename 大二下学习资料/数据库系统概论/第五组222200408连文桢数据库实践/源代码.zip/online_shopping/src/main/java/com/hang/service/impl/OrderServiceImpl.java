package com.hang.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.hang.entity.Order;
import com.hang.mapper.CommentMapper;
import com.hang.mapper.OrderMapper;
import com.hang.mybatisplusmapper.OrderMybatisPlusMapper;
import com.hang.service.OrderService;
import com.hang.utils.MybatisPlusSqlSessionFactoryUtil;
import com.hang.utils.SqlSessionFactoryUtil;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.time.LocalDateTime;
import java.util.List;

public class OrderServiceImpl implements OrderService {
    private SqlSessionFactory sqlSessionFactory = SqlSessionFactoryUtil.getSqlSessionFactory();
    private SqlSessionFactory mybatisPlusSqlSessionFactory = MybatisPlusSqlSessionFactoryUtil.getMybatisPlusSqlSessionFactory();

    @Override
    public List<Order> selectAll() {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        OrderMapper mapper = sqlSession.getMapper(OrderMapper.class);

        List<Order> orders = mapper.selectAll();

        sqlSession.close();

        return orders;
    }

    @Override
    public Order selectById(Integer id) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        OrderMapper mapper = sqlSession.getMapper(OrderMapper.class);

        Order order = mapper.selectById(id);

        sqlSession.close();

        return order;
    }

    @Override
    public List<Order> selectBetweenDatetime(LocalDateTime begin, LocalDateTime end) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        OrderMapper mapper = sqlSession.getMapper(OrderMapper.class);

        List<Order> orders = mapper.selectBetweenDatetime(begin,end);

        sqlSession.close();

        return orders;
    }

    @Override
    public List<Order> selectByShopId(Integer shopId) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        OrderMapper mapper = sqlSession.getMapper(OrderMapper.class);

        List<Order> orders = mapper.selectByShopId(shopId);

        sqlSession.close();

        return orders;
    }

    @Override
    public List<Order> selectByUserId(String userId) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        OrderMapper mapper = sqlSession.getMapper(OrderMapper.class);

        List<Order> orders = mapper.selectByUserId(userId);

        sqlSession.close();

        return orders;
    }

    @Override
    public void insert(Order order) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        OrderMapper mapper = sqlSession.getMapper(OrderMapper.class);

        mapper.insert(order);

        sqlSession.commit();

        sqlSession.close();
    }

    @Override
    public void updateById(Order order) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        OrderMapper mapper = sqlSession.getMapper(OrderMapper.class);

        mapper.updateById(order);

        sqlSession.commit();

        sqlSession.close();
    }

    @Override
    public void deleteById(Integer id) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        OrderMapper mapper = sqlSession.getMapper(OrderMapper.class);

        mapper.deleteById(id);

        sqlSession.commit();
        sqlSession.close();
    }

    @Override
    public List<Order> selectForOrderManage(String orderedBy, String deliveryStatus, String paymentStatus) {
        SqlSession sqlSession = mybatisPlusSqlSessionFactory.openSession();
        OrderMybatisPlusMapper mapper = sqlSession.getMapper(OrderMybatisPlusMapper.class);

        LambdaQueryWrapper<Order> lambdaQueryWrapper = new LambdaQueryWrapper<>();
        if(!"全部".equals(deliveryStatus)){
            lambdaQueryWrapper.eq(Order::getDeliveryStatus,deliveryStatus);
        }
        if(!"全部".equals(paymentStatus)){
            lambdaQueryWrapper.eq(Order::getPaymentStatus,paymentStatus);
        }

        if("最近创建订单".equals(orderedBy)){
            lambdaQueryWrapper.orderByDesc(Order::getOrderCreateDatetime);
        }else if("大额订单".equals(orderedBy)){
            lambdaQueryWrapper.orderByDesc(Order::getTotalAmount);
        }

        List<Order> orders = mapper.selectList(lambdaQueryWrapper);

        sqlSession.close();

        return orders;
    }
}
