package com.hang.service.impl;

import com.hang.entity.ShopBilling;
import com.hang.entity.ShoppingCartItem;
import com.hang.mapper.ShopBillingMapper;
import com.hang.mapper.ShoppingCartItemMapper;
import com.hang.service.ShoppingCartItemService;
import com.hang.utils.SqlSessionFactoryUtil;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.List;

public class ShoppingCartItemServiceImpl implements ShoppingCartItemService {
    private SqlSessionFactory sqlSessionFactory = SqlSessionFactoryUtil.getSqlSessionFactory();

    @Override
    public List<ShoppingCartItem> selectAll() {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ShoppingCartItemMapper mapper = sqlSession.getMapper(ShoppingCartItemMapper.class);
        List<ShoppingCartItem> shoppingCartItems = mapper.selectAll();

        sqlSession.close();
        return shoppingCartItems;
    }

    @Override
    public ShoppingCartItem selectById(Integer id) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ShoppingCartItemMapper mapper = sqlSession.getMapper(ShoppingCartItemMapper.class);
        ShoppingCartItem shoppingCartItem = mapper.selectById(id);

        sqlSession.close();
        return shoppingCartItem;
    }

    @Override
    public List<ShoppingCartItem> selectByUserId(String userId) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ShoppingCartItemMapper mapper = sqlSession.getMapper(ShoppingCartItemMapper.class);
        List<ShoppingCartItem> shoppingCartItems = mapper.selectByUserId(userId);

        sqlSession.close();
        return shoppingCartItems;
    }

    @Override
    public void insert(ShoppingCartItem shoppingCartItem) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ShoppingCartItemMapper mapper = sqlSession.getMapper(ShoppingCartItemMapper.class);

        mapper.insert(shoppingCartItem);

        sqlSession.commit();

        sqlSession.close();
    }

    @Override
    public void updateById(ShoppingCartItem shoppingCartItem) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ShoppingCartItemMapper mapper = sqlSession.getMapper(ShoppingCartItemMapper.class);

        mapper.updateById(shoppingCartItem);

        sqlSession.commit();

        sqlSession.close();

    }

    @Override
    public void deleteById(Integer id) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ShoppingCartItemMapper mapper = sqlSession.getMapper(ShoppingCartItemMapper.class);

        mapper.deleteById(id);

        sqlSession.commit();
        sqlSession.close();
    }
}
