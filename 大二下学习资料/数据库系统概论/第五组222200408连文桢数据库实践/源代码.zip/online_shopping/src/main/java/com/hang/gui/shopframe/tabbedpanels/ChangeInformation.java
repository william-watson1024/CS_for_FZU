package com.hang.gui.shopframe.tabbedpanels;

import com.hang.entity.Shop;
import com.hang.gui.adminframe.tabbedpanels.frames.ChangePasswordFrame;
import com.hang.gui.adminframe.tabbedpanels.frames.DeleteAccountFrame;
import com.hang.service.ShopService;
import com.hang.service.impl.ShopServiceImpl;
import com.hang.utils.ImageUtils;

import javax.swing.*;
import java.awt.*;


public class ChangeInformation extends JPanel {

    JLabel sellerWordLabel = new JLabel("商家: ");
    JLabel sellerIdLabel = new JLabel();

    JLabel shopNameLabel = new JLabel("店铺名: ");
    JTextField shopNameField = new JTextField(12);

    JLabel shopDescriptionLabel = new JLabel("店铺描述: ");
    JTextField shopDescriptionField = new JTextField(12);

    JLabel businessLicenseLabel = new JLabel("商业执照: ");
    JTextField businessLicenseField = new JTextField(12);

    JLabel legalPersonLicenseLabel = new JLabel("法人: ");
    JTextField legalPersonLicenseField = new JTextField(12);

    JButton confirmButton = new JButton("确认修改");
    JPanel confirmButtonPanel = new JPanel();


    public ChangeInformation(Shop shop) {
        ShopService shopService = new ShopServiceImpl();

        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5, 5, 5, 5);


        // 第1行：商家
        c.gridy = 0;

        c.gridx = 0;
        add(sellerWordLabel, c);

        c.gridx = 1;
        sellerIdLabel.setText(shop.getSellerId());
        add(sellerIdLabel, c);


        // 第2行：姓名
        c.gridy = 1;

        c.gridx = 0;
        add(shopNameLabel, c);

        c.gridx = 1;
        shopNameField.setText(shop.getShopName());
        add(shopNameField, c);


        // 第3行：店铺描述
        c.gridy = 2;

        c.gridx = 0;
        add(shopDescriptionLabel, c);

        c.gridx = 1;
        shopDescriptionField.setText(shop.getShopDescription());
        add(shopDescriptionField, c);


        // 第4行：商业执照
        c.gridy = 3;

        c.gridx = 0;
        add(businessLicenseLabel, c);

        c.gridx = 1;
        businessLicenseField.setText(shop.getBusinessLicense());
        add(businessLicenseField, c);


        // 第5行：法人
        c.gridy = 4;

        c.gridx = 0;
        add(legalPersonLicenseLabel, c);

        c.gridx = 1;
        legalPersonLicenseField.setText(shop.getLegalPerson());
        add(legalPersonLicenseField, c);

        // 第5行：确认修改按钮panel
        c.gridy = 5;
        confirmButtonPanel.add(confirmButton);
        confirmButtonPanel.setOpaque(false);

        c.gridx = 0;
        c.gridwidth = 2;
        add(confirmButtonPanel, c);

        confirmButton.addActionListener(e -> {
            shop.setShopName(shopNameField.getText());
            shop.setShopDescription(shopDescriptionField.getText());
            shop.setBusinessLicense(businessLicenseField.getText());
            shop.setLegalPerson(legalPersonLicenseField.getText());
            shopService.updateById(shop);
            JOptionPane.showMessageDialog(this, "修改成功");
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        String backgroundPath = "image/background/change_information.jpg";
        ImageUtils.drawBackground(backgroundPath,g,this);
    }
}
