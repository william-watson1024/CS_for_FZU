package com.hang.test;

import com.hang.entity.User;
import com.hang.service.UserService;
import com.hang.service.impl.UserServiceImpl;
import org.junit.Test;

public class UserTest {
    private UserService userService = new UserServiceImpl();
    @Test
    public void test(){
        User user = userService.selectById("user");
        System.out.println(user.getNickname());
    }
}
